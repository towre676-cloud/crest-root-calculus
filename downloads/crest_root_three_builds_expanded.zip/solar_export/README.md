# FlexExport · Can more rooftop solar share the same wires?

Eighteen households want to export solar electricity. A limit can let each send more at some times and less at others. This experiment asks two different questions. **When does allowing export make a grid limit worse?** And **what happens when the homes themselves are added?** Some evenings require extra network capacity even when every new inverter is already exporting zero.

## Try the 18-home case

Use Python 3.11 or 3.12. In this folder run the following commands. NumPy is the only dependency for the new AC solver, offer designer, and certificate checker.

```shell
python -m pip install numpy
python -m flexexport.check receipt_new18.json stress_new18.json
python -m flexexport.stress receipt_new18.json --output my_stress18.json
```

Choose a home, season, and case in [the offline cap explorer](offers.html) to see its hourly limit.

The first command after installation rechecks 78,840 simulated operating points for each accepted offer and reproduces the counterexamples for larger offers. The second rebuilds the design and tests it on two separate synthetic years. Substitute 12 or 24 for 18 to exercise the other two feeders. Open the JSON files for individual bus voltages, overloaded assets, hour indices, per-home caps, energy lost, and all comparison results. The three uploaded `receipt_new*.json` and `summary.json` files retain their original values.

## A comparison that changes the answer

These are the 18-home results on a balanced, hypothetical 0.4 kV feeder. The left column pair uses 2012–13 half-hour readings from 50 Ausgrid study households. Their demand and observed solar output per unit of nameplate are mapped onto the example feeder and its 32 existing and 18 candidate households. The right column pair uses a separate, bright, low-demand synthetic year with seed 113. Each percentage is curtailed candidate generation divided by all available candidate generation.

| Export plan | Export-worsened hours, meter-based replay | Solar given up, meter-based replay | Export-worsened hours, simulated bright year | Solar given up, simulated bright year |
| --- | ---: | ---: | ---: | ---: |
| Unlimited | 690.5 | 0.00% | 251 | 0.00% |
| Supplied fixed | 13 | 13.99% | 184 | 3.18% |
| Supplied seasonal | 365 | 6.01% | 212 | 2.38% |
| Revised fixed | 0 | 22.00% | 0 | 6.58% |
| Revised seasonal | 95.5 | 15.58% | 0 | 6.32% |

The seasonal design passed every tested synthetic year/condition for the export-increment metric. It still produced 191 out-of-limit half-hours on measured input profiles. The worst voltage in this transfer test was 1.07134 pu at L10.3, versus the 1.06 pu ceiling. A fixed fallback passed that replay by curtailing about 41,565 kWh, compared with 29,429 kWh under the revised seasonal schedule. This is a transfer experiment on a modeled network. The actual feeders, phase assignments, voltages, and transformer loading for these households were not observed.

## Can local meter history improve the seasonal offer?

We repeated the same 17-scale search using the **earliest measured year** at nominal conditions. Both seasonal and fixed offers were frozen after the 2010–11 fit. The same 50 meter IDs appear in each replay. The panel was chosen for completeness in 2012–13. In the earlier years only dates with complete simultaneous data for those 50 IDs were retained.

| Meter period | Dates retained | Seasonal export-worsened hours | Fixed export-worsened hours | Seasonal PV curtailed | Fixed PV curtailed |
| --- | ---: | ---: | ---: | ---: | ---: |
| 2010–11, design period | 365 | 0 | 0 | 23,745 kWh | 27,981 kWh |
| 2011–12, later period | 173 | 0 | 0 | 13,209 kWh | 15,354 kWh |
| 2012–13, later period | 365 | **3.5** | **0** | 26,396 kWh | 31,039 kWh |

On the 173 complete days of 2011–12 the flexible offer recovered 2,145 kWh relative to the fixed offer, with both staying within the simulated limits. On the full later year it recovered 4,644 kWh and breached the voltage limit during seven half-hours. The worst was 1.060833 pu at the end of lateral 10 on 30 August 2012 at 13:00. A fixed fallback passed that year at 16.43% curtailment. This was a retrospective exercise. The 2012–13 transfer failure was known before the historical calibration was proposed. The procedure used no later-year observations to set cap values, and the seven failures remain visible in the released result. Missing dates for 2011–12 can affect comparisons across years; energy totals describe the observed dates only.

## How the finite search works

Each supplied offer contains 96 cells, one per season and clock hour. In one cell the program multiplies the whole vector of household caps by one factor chosen from 0, 1/16, 2/16, …, 1. It tries larger factors first. Each candidate must pass all the modeled training observations in that cell. The fixed competitor applies one shared factor to the source fixed caps across all cells. Both searches use the same operating conditions and headroom. On this finite set, the final scale is the largest passing factor for its cell. This claim assumes independent cells, fixed home-to-home shares within each original cap vector, and instantaneous application of each cap.

For each larger rejected factor, the design records the condition, day, clock hour, bus or component, and the operating and reference values at a single failing instant. The checker verifies every accepted setting against **every training observation**, requires witnesses for **all larger factors**, and tests each witness directly. Floating-point AC load flow is used throughout. This constructive upper/lower-bound pattern mirrors the Crest–Root search. It does not require or extend the theorem for plane quartics.

Training uses all 8,760 hours of synthetic seeds 31, 47, and 71. Each year is evaluated at three declared combinations of (PV multiplier, demand multiplier, source voltage): nominal (1, 1, 1.02 pu), bright/low demand (1.12, 0.88, 1.026 pu), and dim/high demand (0.88, 1.12, 1.014 pu). PV is clipped to nameplate. Seeds 113 and 127 are used only to evaluate the frozen offers. Three tested combinations do not cover the continuum between them, independent weather errors at every house, or additional operating conditions.

| Candidates | Source uncontrolled hours on original held-out days, independently reproduced | Bright year 113, source flexible → revised flexible, export-worsened hours | Bright year 127, same measure | Changed season/hour cells out of 96 |
| ---: | ---: | ---: | ---: | ---: |
| 12 | 0 | 116 → 0 | 146 → 0 | 14 |
| 18 | 47 | 212 → 0 | 255 → 0 | 16 |
| 24 | 106 | 326 → 0 | 341 → 0 | 24 |

## What counts as a breach?

The new study checks the maximum and minimum LV voltage (1.06 and 0.94 pu), each of 40 cable current loadings, and transformer current loading (100%). The lower-voltage threshold is an illustrative addition. All calendar hours count. Training bounds have 0.0008 pu voltage headroom and 0.08 percentage points of loading headroom. Evaluation uses the specified limits directly.

- **Absolute** counts every interval in which any component exceeds a limit.
- **Export-worsened** compares the same bus or asset to the same households with candidate PV serving only their own loads and zero exports. The actual value must both breach the limit and increase that component’s breach. Tiny numerical differences below 1e−8 pu or 1e−5 loading percentage points are ignored.
- **Development-worsened** compares to a feeder with the candidate households’ consumption and generation both removed. The original receipt’s label `no_new_homes` disabled only their PV, leaving their loads connected. The legacy runner now labels that comparator `same_homes_without_candidate_pv`.
- In the 18-home simulated bright year (113), the revised schedule had **0 export-worsened hours yet 46 absolute violation hours**. Those 46 also counted as development-worsened. Existing households alone had zero. An export-only result cannot qualify these 18 additional residences for a real connection.

Each interval counts at most once in a total, even if several components violate. Voltage and thermal subtotals may overlap. The legacy comparison intentionally reproduces the original selected sun-hour, maximum-voltage/aggregate-overload metric; it should be compared to the uploaded receipts on that basis.

## Power flow and independent numerical check

The balanced, fixed-topology AC solver uses a backward current sweep and a forward voltage sweep on the radial tree. For positive consumed complex power S, nodal current is conjugate(S/V). It includes the full transformer T equivalent, core losses and cable charging. On convergence it independently rebuilds the complex power mismatch from neighboring voltages and rejects runs with mismatch above 1e−8 pu. Thermal loading uses the larger terminal-current magnitude at either end of each cable and transformer. Phases are balanced, the transformer tap is neutral, PV is unity power factor, and household reactive consumption is 0.2 times gross active demand. Results cover interval-average steady states. Phase imbalance, harmonic distortion, protection, fault levels, rapid ramps, telemetry failure, and inverter dynamics require other models and measurements.

`crosscheck_new18.json` compares 54 operating points against pandapower 3.3.2’s Newton solver at every LV bus and asset. Maximum differences were 2.61e−11 pu voltage and 2.25e−8 percentage points of loading. The test compares a sample; the model assumptions and data source are shared. The source caps were published to three decimal places and fixed caps to two, so the limits of numerical reproducibility extend to those supplied values.

```shell
python -m pip install "pandapower==3.3.2" pytest
python crosscheck.py receipt_new18.json
python -m pytest -q
```

## Bring meter traces

`prepare_ausgrid.py` prepares the published research data separately. Half-hour gross consumption includes controlled load where recorded. Solar generation is divided by the original generator capacity and scaled once to the candidate nameplates. Local Southern Hemisphere seasons map to the offer’s named season. Rebuild the meter transfer study with:

```shell
python -m pip install pandas
python prepare_ausgrid.py --download --out ausgrid50.npz
python -m flexexport.metered receipt_new18.json stress_new18.json ausgrid50.npz --output my_metered18.json
```

To reproduce the three-year comparison, download the archive once and substitute its path below for `solar_home.zip`. The first extraction fixes the cohort; the flag in each earlier extraction selects exactly the same meter IDs. The final check replays all 17,520 accepted calibration intervals and the local counterexamples for all 166 larger seasonal choices and one larger fixed choice.

```shell
python prepare_ausgrid.py --zip solar_home.zip --out ausgrid50.npz
python prepare_ausgrid.py --zip solar_home.zip --period 2010-2011 --cohort ausgrid50.json --out ausgrid50_2010.npz
python prepare_ausgrid.py --zip solar_home.zip --period 2011-2012 --cohort ausgrid50.json --out ausgrid50_2011.npz
python -m flexexport.calibrate_metered receipt_new18.json ausgrid50_2010.npz ausgrid50_2011.npz ausgrid50.npz --output my_local18.json
python -m flexexport.check receipt_new18.json my_local18.json --profile ausgrid50_2010.npz
```

A custom NPZ can supply `load_kw` and `pv_unit`, both shaped (intervals, all homes). PV units are kW/kWp. Provide `hour` (0–23) and `season` (winter=0, spring=1, summer=2, autumn=3) as integer arrays, and a scalar `interval_hours` of 1, 0.5, or 0.25. Rows start at midnight. Columns follow the historical existing-house order, then New-01 through New-18. Existing solar ratings and all node placements are the benchmark’s assumptions. Other feeder topologies require a separate model; net billing data alone cannot provide the gross channels required here.

[Ausgrid study publication](https://doi.org/10.1080/14786451.2015.1100196) · [Meter data format](https://unsw-ceem.github.io/DARTH-docs/ausgrid300/) · [pandapower standard equipment data](https://pandapower.readthedocs.io/en/latest/std_types/basic.html)
