"""Prepare 50 aligned half-hour household profiles from Ausgrid's archived gross-meter study."""
import argparse
import hashlib
import io
import json
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

URL = "https://pierreh.eu/downloads/Ausgrid_solar_home_data.zip"
ZIP_SHA = "5a766f52b6c8b3b72730380f4422e478934bc94640a4b089dd0e0e3c055c5d82"
MEMBER = "Solar home 2012-2013.csv"


def prepare(archive, out, period="2012-2013", cohort=None):
    member = f"Solar home {period}.csv"
    with zipfile.ZipFile(archive) as source:
        data = source.read(member)
    frame = pd.read_csv(io.BytesIO(data), skiprows=1, keep_default_na=False)
    expected_cols = [f"{(k//2)%24}:{'30' if k%2 else '00'}" for k in range(1,49)]
    if list(frame.columns[5:53]) != expected_cols:
        raise ValueError("Unrecognized interval labels. Expected half-hour-ending meter columns.")
    yr0, yr1 = map(int, period.split("-"))
    dates = pd.date_range(f"{yr0}-07-01", f"{yr1}-06-30")
    frame["date"] = pd.to_datetime(frame["date"], format="%d-%b-%y" if yr0 == 2010 else "%d/%m/%Y")
    if cohort is not None:
        frame = frame[frame["Customer"].isin(cohort)]
    eligible = []
    keep_days = np.ones(len(dates),dtype=bool)
    for customer, group in frame.groupby("Customer", sort=True):
        if group["Generator Capacity"].nunique() != 1 or group["Generator Capacity"].iat[0] <= 0:
            continue
        channels = {}
        day_ok = np.ones(len(dates),dtype=bool)
        for channel, block in group.groupby("Consumption Category"):
            if block["date"].duplicated().any():
                raise ValueError(f"Duplicate date in channel {channel} for study meter {customer}.")
            block = block.set_index("date").reindex(dates)
            vals = block[expected_cols].apply(pd.to_numeric,errors="coerce").to_numpy(dtype=float)
            day_ok &= np.isfinite(vals).all(axis=1) & (vals>=0).all(axis=1)
            if "Row Quality" in block:
                day_ok &= block["Row Quality"].eq("").to_numpy()
            channels[channel] = vals
        if not {"GC","GG"} <= channels.keys() or not day_ok.any() or channels["GG"][day_ok].max() == 0:
            continue
        if cohort is None and not day_ok.all():
            continue
        if cohort is not None:
            keep_days &= day_ok
        gross_demand = 2.0 * (channels["GC"] + channels.get("CL",0.0))
        pv_per_kwp = 2.0 * channels["GG"] / group["Generator Capacity"].iat[0]
        eligible.append((int(customer),gross_demand,pv_per_kwp))
    if cohort is not None and [m[0] for m in eligible] != list(cohort):
        raise ValueError("An earlier period does not have all the selected meters.")
    if len(eligible)<50 or not keep_days.any():
        raise ValueError("The year has too few common complete records.")
    meters = eligible[:50]
    day_offsets = np.flatnonzero(keep_days)
    dates = dates[keep_days]
    # Each day's first 2 interval-ending columns refer to hour starting at 00:00.
    hours = np.tile(np.repeat(np.arange(24),2),len(dates))
    # Original offer season indices are winter=0, spring=1, summer=2, autumn=3.
    season_by_month = {12:2,1:2,2:2,3:3,4:3,5:3,6:0,7:0,8:0,9:1,10:1,11:1}
    seasons = np.repeat([season_by_month[d.month] for d in dates],48)
    load = np.column_stack([m[1][keep_days].ravel() for m in meters]); pv = np.column_stack([m[2][keep_days].ravel() for m in meters])
    np.savez_compressed(out,load_kw=load,pv_unit=pv,season=seasons,hour=hours,interval_hours=0.5,day_offset=np.repeat(day_offsets,48))
    panel_key = ",".join(str(m[0]) for m in meters).encode("ascii")
    meta = {"cohort_sha256": hashlib.sha256(panel_key).hexdigest(),
            "day_dates": [d.date().isoformat() for d in dates], "source":"Ausgrid Solar home electricity data, "+period,
            "publication_doi":"10.1080/14786451.2015.1100196", "archive_mirror":URL,
            "source_member": member, "member_sha256":hashlib.sha256(data).hexdigest(),
            "selection":"First 50 ascending anonymized IDs eligible before evaluating any offer. Complete 365 days for GC and GG; include CL when present, require complete CL where present. Constant positive nameplate, finite nonnegative measurements, positive annual generation, blank row-quality flags.",
            "eligible_households":len(eligible), "selected_households":len(meters),
            "selected_ids": [m[0] for m in meters], "cohort_rule": "common complete days for the specified fixed panel" if cohort is not None else "complete year",
            "days":len(dates), "intervals":len(hours), "interval_hours":0.5,
            "first_local_date":dates[0].date().isoformat(), "last_local_date":dates[-1].date().isoformat(),
            "total_gross_demand_kwh":0.5*float(load.sum()), "sum_generation_per_kwp_kwh":0.5*float(pv.sum()),
            "calendar":"Local clock labels as supplied at 48 intervals/day. Seasonal indexing follows the Southern Hemisphere. No timezone reconstruction or interpolation."}
    Path(out).with_suffix(".json").write_text(json.dumps(meta,indent=2)+"\n")
    return meta


def main():
    p = argparse.ArgumentParser(description=__doc__)
    source = p.add_mutually_exclusive_group(required=True)
    source.add_argument("--zip",type=Path,help="Archive containing "+MEMBER)
    source.add_argument("--download",action="store_true",help="Download the pinned research mirror")
    p.add_argument("--out",type=Path,default=Path("ausgrid50.npz"))
    p.add_argument("--period",choices=["2010-2011","2011-2012","2012-2013"],default="2012-2013")
    p.add_argument("--cohort",type=Path,help="JSON receipt from the 2012–13 extraction, fixing the same 50 meters")
    args = p.parse_args()
    if args.period != "2012-2013" and args.cohort is None:
        p.error("Provide --cohort with the panel metadata so the households stay the same.")
    cohort = json.loads(args.cohort.read_text())["selected_ids"] if args.cohort else None
    if args.out.suffix != ".npz":
        p.error("--out must end in .npz")
    if args.download:
        with tempfile.TemporaryFile() as tmp, urllib.request.urlopen(URL,timeout=120) as response:
            shutil.copyfileobj(response,tmp);tmp.seek(0)
            if hashlib.file_digest(tmp,"sha256").hexdigest() != ZIP_SHA:
                raise ValueError("Downloaded archive hash differs from the documented version.")
            tmp.seek(0); result = prepare(tmp,args.out,args.period,cohort)
    else:
        result = prepare(args.zip,args.out,args.period,cohort)
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    main()
