// Executed in the live page's JavaScript context by test_page.py.
(async () => {
  const get=id=>document.getElementById(id);
  const click=id=>get(id).click();
  const assert=(pred,msg)=>{if(!pred) throw Error(msg);};
  const change=(id,value,event)=>{
    get(id).value=value;
    get(id).dispatchEvent(new Event(event,{bubbles:true}));
  };
  const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  const baseline=window.__linkwrightSelfTest();
  assert(baseline.length===4 && baseline.every(v=>v.ok),'Original flap parameter cases');
  assert(get('closureText').textContent.includes('Every length combination closes'),'Default full rotation');
  assert(designRecord().workshop.roundedConfiguration.rockerPositions===2,'Exact assembly fibre');
  change('anglePick','1/0','change');
  assert(designRecord().workshop.roundedConfiguration.crankAnglePair[1]===0,'Half-turn projective coordinate');
  change('q',180,'input');click('synthFlap');change('tol',5,'input');
  assert(get('closureText').textContent.includes('cannot close'),'Tolerance obstruction');
  const below=designRecord();
  assert(below.workshop.fitScales.min>100,'Inverse scale must increase design');
  click('applyScale');
  assert(get('closureText').textContent.includes('Every length combination closes'),'Suggested scale fixes folding');
  const repaired=designRecord();
  change('layer','shared','change');
  assert(get('sweepText').textContent.includes('one layer'),'Shared-layer rendering');
  change('mat','stick','change');
  assert(get('applyScale').disabled && !designRecord().workshop.fitScales.count,'Stock too short');
  change('mat','card','change');change('tol',.5,'input');change('scale',100,'input');
  click('tabPath');click('samplePath');click('synthPath');click('tabFlap');
  await wait(200);
  assert(designRecord().mode==='flap' && !get('synthPath').disabled,'Cancelled stale search');
  click('tabPath');click('samplePath');click('synthPath');
  for(let i=0;i<1800 && get('synthPath').disabled;i++) await wait(100);
  assert(get('status').textContent.startsWith('Best fit:'),'Path synthesis did not finish');
  const path=designRecord();
  assert(path.pathGap && path.pathGap.fraction<.12 && path.workshop.closure.state==='closes','Geometric fit');
  assert(get('partsWrap').querySelector('svg').getAttribute('width').endsWith('mm'),'Scaled, printable SVG');
  assert(get('partsWrap').textContent.includes('Pin spacing'),'Parts sheet carries workshop settings');
  return {baseline,timingExample:{swingDeg:60,ratio:1.8,toleranceMm:5,
    before:below.workshop.closure.state,scalePercent:below.workshop.fitScales.min,after:repaired.workshop.closure.state},
    exampleTrace:{...path.pathGap,sweep:path.workshop.sweep.state,scaleRange:path.workshop.fitScales}};
})()
