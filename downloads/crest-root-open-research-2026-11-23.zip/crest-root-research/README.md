# Crest-Root open research, 23 November 2026

Read [the research results](research/README.md), the [57-item register](research/backlog-2026-11-23.md), or the [nine-page introductory essay](downloads/crest-root-introduction.pdf). The packet includes the canonical 148-section monograph, finite hyperelliptic map reconstruction, exact local-to-global certificates, the equal-count obstruction, three solver comparisons, the marked chart-I solver, point-free Riemann-Roch, genus-two correspondences, the genus-37 rank certificates, quartic degree spectra, the historical atlas and higher-support tower certificates.

After extracting, open a terminal in this folder. Windows commands:

```sh
py -m pip install numpy "sympy>=1.12,<2"
py research/replay.py
```

On macOS or Linux, substitute `python3` for `py`. The replay launches the 31 verification groups listed in research/replay.py. The default checks run offline. If PARI/GP is installed, the rank replay also regenerates the number-field and local arithmetic behind the upper bounds. Without GP, the Python replay checks the recorded descent matrices and every lower-bound divisor certificate.

The finite-map certificates can be checked using Python and SymPy; Singular accelerates new general eliminations. Repeating the measured solver studies requires Singular, PARI/GP and a POSIX environment. Their stored results, exact output checks, timeouts and dependency hashes are included. See [the comparison instructions](research/solver-comparison/README.md) for reproducible commands and precise limits.
