import numpy as np, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from geoassay import builtin_proxy, assemblage_posterior, Site, select, SITE_MODELS

lib = builtin_proxy(); M = lib.names

def test_noiseless_unmix_recovers_mixture():
    y = .6*lib.R[:, M.index("kaolinite")] + .4*lib.R[:, M.index("alunite")]
    h = assemblage_posterior(lib, y, 0.002, kmax=3)[0]
    assert set(h["minerals"]) == {"kaolinite", "alunite"}
    assert abs(h["fractions"][h["minerals"].index("kaolinite")] - .6) < .02

def test_posterior_normalised():
    y = lib.R[:, M.index("calcite")] + np.random.default_rng(0).normal(0, .03, len(lib.wl))
    h = assemblage_posterior(lib, y, .03, kmax=2)
    assert abs(sum(x["p"] for x in h) - 1) < 1e-9

def _site(rng, model, n=5, sig=.04):
    from geoassay.site import ZONES
    S = []
    for k in range(n):
        z = ZONES[k*3//n]; pz = SITE_MODELS[model][z]
        a = sorted(pz, key=pz.get, reverse=True)[:2]
        y = lib.R[:, [M.index(x) for x in a]] @ np.array([.5, .5]) + rng.normal(0, sig, len(lib.wl))
        h = assemblage_posterior(lib, y, sig, kmax=3, top=15); s = sum(x["p"] for x in h)
        for x in h: x["p"] /= s
        S.append({"id": str(k), "zone": z, "hyps": h})
    return S

def test_site_posterior_prefers_true_model():
    S = _site(np.random.default_rng(1), "porphyry phyllic-propylitic")
    site = Site(S, M); p = site.posterior()
    assert site.models[int(np.argmax(p))] == "porphyry phyllic-propylitic"

def test_expected_entropy_never_exceeds_current():
    # information never hurts in expectation (exact for the enumerated outcome set)
    S = _site(np.random.default_rng(2), "high-sulfidation epithermal", sig=.06)
    site = Site(S, M); ch, Hb, H0 = select(site, 2)
    assert Hb <= H0 + 1e-6 and len(ch) == 2

def test_assaying_truth_increases_belief_on_average():
    rng = np.random.default_rng(3); gains = []
    for t in range(6):
        model = list(SITE_MODELS)[t % 5]
        S = _site(rng, model, sig=.06); site = Site(S, M); ti = site.models.index(model)
        truth = {i: S[i]["hyps"][0]["minerals"] for i in range(len(S))}
        gains.append(site.posterior(truth)[ti] - site.posterior()[ti])
    assert np.mean(gains) > -0.05
