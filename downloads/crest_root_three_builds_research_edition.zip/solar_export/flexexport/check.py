"""Verify the finite-domain cap certificate without running its search."""

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import numpy as np
from .audit import CONDITIONS, Offer, WeatherYear, bad_hours, violation_masks


def check_one(model, rows, plan, conditions, years, static):
    base_caps = model.fixed if static else model.flexible
    scale = np.asarray(plan["scales"], float)
    ladder = plan["ladder"]
    if (
        scale.shape != (4, 24)
        or not np.isin(scale, ladder).all()
        or len(ladder) < 2
        or ladder[0] != 1
        or ladder[-1] != 0
        or any(a <= b for a, b in zip(ladder, ladder[1:]))
    ):
        raise ValueError("Invalid candidate scale or scale ladder.")
    if static and not np.all(scale == scale[0, 0]):
        raise ValueError("Fixed-cap comparison changes by time.")
    expected = base_caps * scale[:, :, None]
    if not np.array_equal(expected, rows):
        raise ValueError(
            "Published caps disagree with the certified scale and source table."
        )
    hours = np.arange(len(next(iter(years.values())).sun))
    margin = plan["voltage_headroom_pu"]
    if (
        not np.isfinite(margin)
        or margin < 0
        or plan["thermal_headroom_pct"] != 100 * margin
    ):
        raise ValueError("Malformed headroom.")
    for weather in years.values():
        for cond in conditions.values():
            ref = weather.run(cond, hours, np.zeros_like(expected))[0]
            actual = weather.run(cond, hours, expected)[0]
            if bad_hours(violation_masks(actual, model.limits, ref, margin)).any():
                raise ValueError("A stated cap fails on a declared training hour.")
    witnessed = 0
    groups = [scale[0, 0]] if static else list(scale.ravel())
    witnesses = plan["rejected_scales"]
    if set(witnesses) - {str(i) for i in range(len(groups))}:
        raise ValueError("Witness under an unknown cell.")
    for i, accepted in enumerate(groups):
        entries = witnesses.get(str(i), [])
        if [e["scale"] for e in entries] != [x for x in ladder if x > accepted]:
            raise ValueError("Missing, out-of-order or extra rejected scale.")
        for entry in entries:
            day, hour = entry["day_index"], entry["hour"]
            w, c = years[entry["seed"]], conditions[entry["condition"]]
            t = np.array([entry.get("interval_index", day * 24 + hour)])
            if not 0 <= t[0] < len(w.sun):
                raise ValueError("Witness targets an unknown interval.")
            when = w.clock(int(t[0]))
            if (
                when["day_index"] != day
                or when["hour"] != hour
                or ("date" in when and when["date"] != entry.get("date"))
                or (not static and w.season[t[0]] * 24 + w.hour[t[0]] != i)
            ):
                raise ValueError("Witness targets a different cell or date.")
            ref = w.run(c, t, np.zeros_like(expected))[0]
            actual = w.run(c, t, base_caps * entry["scale"])[0]
            low, high, hot = violation_masks(actual, model.limits, ref, margin)
            checks = {
                "low_voltage": (low, model.grid.lv_names, actual.voltage, ref.voltage),
                "high_voltage": (
                    high,
                    model.grid.lv_names,
                    actual.voltage,
                    ref.voltage,
                ),
                "thermal": (hot, model.grid.components, actual.loading, ref.loading),
            }
            flags, names, values, refs = checks[entry["metric"]]
            idx = names.index(entry["component"])
            if (
                not flags[0, idx]
                or max(
                    abs(values[0, idx] - entry["value"]),
                    abs(refs[0, idx] - entry["reference_value"]),
                )
                > 1e-6
            ):
                raise ValueError("Rejected scale witness fails independent replay.")
            witnessed += 1
    return witnessed


def check(source, receipt, profile=None):
    src = Path(source)
    data = json.loads(Path(receipt).read_text())
    model = Offer.read(source)
    if data["source_sha256"] != hashlib.sha256(src.read_bytes()).hexdigest():
        raise ValueError("Source receipt SHA-256 differs.")
    if profile is None:
        conditions = {c.name: c for c in CONDITIONS}
        if data["candidate_conditions"] != [asdict(c) for c in CONDITIONS] or data[
            "limits"
        ] != asdict(model.limits):
            raise ValueError("Operating conditions or limits differ.")
        years = {s: WeatherYear(model, s) for s in data["training_seeds"]}
        if not years or set(years) & set(data["evaluation_seeds"]):
            raise ValueError("Missing training years or overlapping split.")
    else:
        from .metered import Metered

        path = Path(profile)
        if (
            hashlib.sha256(path.read_bytes()).hexdigest()
            != data["calibration_file_sha256"]
        ):
            raise ValueError("Calibration profile SHA-256 differs.")
        if data.get("conditions") != ["nominal"]:
            raise ValueError("Unknown metered calibration conditions.")
        conditions = {CONDITIONS[0].name: CONDITIONS[0]}
        start = data["profile_provenance"][0]["first_local_date"]
        years = {start: Metered(model, path)}
    flexible = np.asarray(data["revised_caps_kw"])
    fixed = np.broadcast_to(np.asarray(data["revised_fixed_kw"]), model.fixed.shape)
    f = check_one(model, flexible, data["design"], conditions, years, False)
    s = check_one(model, fixed, data["static_design"], conditions, years, True)
    return {
        "training_states_per_offer": sum(len(w.sun) for w in years.values())
        * len(conditions),
        "flexible_larger_scales_refuted": f,
        "fixed_larger_scales_refuted": s,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("certificate")
    parser.add_argument(
        "--profile",
        help="NPZ of the metered calibration year for a metered certificate",
    )
    args = parser.parse_args()
    print(json.dumps(check(args.source, args.certificate, args.profile), indent=2))
