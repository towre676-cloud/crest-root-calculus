"""Run with python -m geoassay.cli plan --help or python -m geoassay.cli policy --help."""
import argparse
import csv
import json
import math
import numpy as np

from . import builtin_proxy, load_usgs_splib07, assemblage_posterior, ambiguity, Site, select, ZONES
from .policy import Planner, entropy


def prepare(wl, cols, sigma, lib, kmax=3, keep=20):
    wl = np.asarray(wl, dtype=float)
    if (wl.ndim != 1 or len(wl) < 2 or not np.all(np.isfinite(wl)) or
            not np.all(np.diff(wl) > 0) or wl[0] > lib.wl[0] or wl[-1] < lib.wl[-1]):
        raise ValueError("Scan wavelengths must increase and span the reference grid; endpoint extrapolation is disabled.")
    if int(keep) != keep or keep < 0 or not cols:
        raise ValueError("Supply at least one scan and a nonnegative support size.")
    samples, ids = [], set()
    for name, y in cols.items():
        parts = name.rsplit("@", 1)
        if len(parts) != 2 or not parts[0] or parts[0] in ids or parts[1] not in ZONES:
            raise ValueError(f"Expected a unique sample ID and known zone in {name!r}.")
        sid, zone = parts
        ids.add(sid)
        if np.shape(y) != wl.shape or not np.all(np.isfinite(y)):
            raise ValueError(f"Scan {sid!r} needs one finite reading per wavelength.")
        h = assemblage_posterior(lib, np.interp(lib.wl, wl, y), sigma, kmax=kmax, top=keep)
        retained = sum(x["p"] for x in h)
        for x in h:
            x["p"] /= retained
        samples.append({"id": sid, "zone": zone, "hyps": h, "scan_mass_retained": retained})
    return Site(samples, lib.names)


def plan(wl, cols, budget, sigma, lib, kmax=3):
    site = prepare(wl, cols, sigma, lib, kmax)
    chosen, Hb, H0 = select(site, budget)
    out = {"site_posterior": dict(zip(site.models, map(float, site.posterior()))),
           "entropy_now_nats": H0, "expected_entropy_after_nats": Hb,
           "batch_search": "exhaustive" if math.comb(len(site.samples), budget) <= 2000 else "greedy",
           "outcome_support": "all retained assemblages for each scan, up to 20",
           "send_to_lab": [site.samples[i]["id"] for i in chosen], "samples": []}
    for s in site.samples:
        out["samples"].append({"id": s["id"], "zone": s["zone"], "scan_mass_retained": s["scan_mass_retained"],
            "fits": [{"minerals": list(h["minerals"]), "fractions": [round(float(f), 3) for f in h["fractions"]],
                      "p": round(h["p"], 4)} for h in ambiguity(s["hyps"], 0.9)]})
    return out


def policy_report(site, budget, costs=None, known=None, max_leaves=2_000_000, accept_unlisted=False):
    ids = [s["id"] for s in site.samples]
    costs = costs or {}
    known = known or {}
    if (set(costs) | set(known)) - set(ids):
        raise ValueError("Unknown sample ID in a cost or lab result.")
    assayed = {}
    unlisted = []
    for name, minerals in known.items():
        i = ids.index(name)
        result = tuple(sorted(minerals))
        allowed = {tuple(sorted(a)) for a in site.tab[i][0]}
        if not result or len(set(result)) != len(result) or set(result) - set(site.allm):
            raise ValueError(f"{name}: list each observed mineral once and use names in the chosen reference.")
        if result not in allowed:
            if not accept_unlisted:
                raise ValueError(f"{name}: lab result outside the modeled scan support. Try --keep 0, or --accept-unlisted to replace this scan with the lab result.")
            unlisted.append(name)
        assayed[i] = result
    planner = Planner.from_site(site, assayed)
    out = planner.solve(budget, [costs.get(s, 1) for s in ids], assayed, max_leaves)

    def translate(node, state):
        primary = np.bincount(site.prim, weights=state, minlength=len(site.models))
        node["primary_posterior"] = primary.tolist()
        node["current_entropy_nats"] = entropy(primary)
        i = node["sample"]
        if i is None:
            return
        kernel = planner.kernels[i]
        probabilities = state @ kernel
        node["sample"] = ids[i]
        if "branches" not in node:
            # Expose the actual posterior after the final test as well as its
            # average value. Every displayed path is an attainable lab result.
            node["branches"] = [
                {"outcome": int(a), "probability": float(probabilities[a]), "next": {"sample": None}}
                for a in np.flatnonzero(probabilities > 0)]
        for branch in node["branches"]:
            a = branch["outcome"]
            child = branch["next"]
            translate(child, state * kernel[:, a] / probabilities[a])
            if "entropy_nats" not in child:
                child["entropy_nats"] = child["current_entropy_nats"]
            branch["outcome"] = list(site.tab[i][0][a])
    translate(out["adaptive"], planner.prior)
    out["primary_names"] = site.models
    out["fixed"]["samples"] = [ids[i] for i in out["fixed"]["samples"]]
    out["observations_outside_scan_support"] = unlisted
    out["known_assays"] = {ids[i]: list(a) for i, a in assayed.items()}
    out["site_posterior"] = dict(zip(site.models, map(float, site.posterior(assayed))))
    out["scope"] = "Finite retained scan assemblages, perfect lab calls, conditionally independent samples, fixed site priors. No field or deposit-value claim."
    out["support"] = {s["id"]: {"outcomes": len(s["hyps"]), "scan_mass_retained": s["scan_mass_retained"],
                                "assay_cost": costs.get(s["id"], 1)} for s in site.samples}
    return out


def read_scans(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.reader(f)
        head = next(reader, [])
        if len(head) < 2 or head[0] != "wavelength_um" or len(set(head)) != len(head):
            raise ValueError("Expected wavelength_um and unique sample columns.")
        data = np.array(list(reader), dtype=float)
    if data.ndim != 2 or data.shape[1] != len(head):
        raise ValueError("Scan rows must match the CSV header.")
    return data[:, 0], {name: data[:, j] for j, name in enumerate(head[1:], 1)}


def key_values(values, parse):
    out = {}
    for item in values:
        key, sep, value = item.partition("=")
        if not sep or not key or not value or key in out:
            raise ValueError(f"Expected a unique NAME=VALUE argument, got {item!r}.")
        out[key] = parse(value)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("plan", help="Choose a fixed batch.")
    q = sub.add_parser("policy", help="Compare an optimal fixed batch with sequential lab decisions.")
    for cmd in (p, q):
        cmd.add_argument("csv")
        cmd.add_argument("--budget", type=int, default=2 if cmd is q else 3)
        cmd.add_argument("--sigma", type=float, default=0.03)
        cmd.add_argument("--usgs-wl")
        cmd.add_argument("--usgs", nargs="*", default=[])
        cmd.add_argument("--reference", choices=["proxy", "measured"], default="proxy",
                         help="Default is the synthetic reference. Alternatively use paired --usgs-wl/--usgs.")
    q.add_argument("--accept-unlisted", action="store_true",
                   help="Treat a confirmed lab mixture missing from its scan shortlist as authoritative and replan. A listed mineral reference is required.")
    q.add_argument("--html", metavar="PATH", help="Also write a self-contained, offline decision-tree explorer.")
    q.add_argument("--keep", type=int, default=20, help="Candidate assemblages per scan; 0 retains every fitted candidate.")
    q.add_argument("--cost", action="append", default=[], metavar="ID=CREDITS")
    q.add_argument("--known", action="append", default=[], metavar="ID=MINERAL+MINERAL",
                   help="Consume an existing result; --budget means remaining credits.")
    q.add_argument("--max-leaves", type=int, default=2_000_000)
    a = ap.parse_args()
    try:
        if bool(a.usgs_wl) != bool(a.usgs) or (a.usgs and a.reference != "proxy"):
            raise ValueError("Pair --usgs-wl with --usgs; select only one reference source.")
        if a.usgs:
            lib = load_usgs_splib07(a.usgs_wl, key_values(a.usgs, str))
            source = "user-supplied USGS"
        elif a.reference == "measured":
            from .library import load_measured_reference
            lib = load_measured_reference()
            source = "bundled measured reference"
        else:
            lib = builtin_proxy()
            source = "synthetic band-position proxy"
        wl, cols = read_scans(a.csv)
        if a.cmd == "policy":
            site = prepare(wl, cols, a.sigma, lib, keep=a.keep)
            out = policy_report(site, a.budget, key_values(a.cost, int),
                                key_values(a.known, lambda v: v.split("+")), a.max_leaves, a.accept_unlisted)
        else:
            out = plan(wl, cols, a.budget, a.sigma, lib)
        out["reference"] = source
        if a.cmd == "policy" and a.html:
            from .explorer import write_html
            write_html(out, a.html)
        print(json.dumps(out, indent=2, allow_nan=False))
    except (ValueError, OSError) as e:
        ap.error(str(e))

if __name__ == "__main__":
    main()
