"""Finite-outcome assay planning. Entropies are measured in natural logarithms."""
from __future__ import annotations

from math import prod
import numpy as np
from scipy.special import xlogy


def entropy(p):
    return float(-xlogy(p, p).sum())


class SearchLimit(ValueError):
    """The requested exact search would exceed its advertised work limit."""


class Planner:
    """Prior over hidden hypotheses, primary labels, and outcome kernels by sample.

    K[i][h, a] is P(lab result a | all scans, hidden hypothesis h).
    Distinct samples' results are conditionally independent given h and the scans.
    Values are exhaustive expectations for this finite model in floating point.
    """
    def __init__(self, prior, primary, kernels):
        self.prior = np.asarray(prior, dtype=float)
        self.primary = np.asarray(primary, dtype=int)
        self.kernels = tuple(np.asarray(k, dtype=float) for k in kernels)
        if (self.prior.ndim != 1 or not self.prior.size or
                self.primary.shape != self.prior.shape or np.any(self.primary < 0) or
                np.any(~np.isfinite(self.prior)) or np.any(self.prior < 0) or
                not np.isclose(self.prior.sum(), 1, rtol=0, atol=1e-10)):
            raise ValueError("Expected normalized hypothesis probabilities and matching primary labels.")
        for k in self.kernels:
            if (k.ndim != 2 or k.shape[0] != len(self.prior) or not k.shape[1] or
                    np.any(~np.isfinite(k)) or np.any(k < 0) or
                    not np.allclose(k.sum(axis=1), 1, rtol=0, atol=1e-10)):
                raise ValueError("Each hypothesis needs a normalized assay-outcome row.")
        self.groups = np.unique(self.primary)
        self.group_indices = [np.flatnonzero(self.primary == label) for label in self.groups]

    @classmethod
    def from_site(cls, site, assayed=None):
        kernels = []
        for _, likelihood, log_assemblage in site.tab:
            scores = log_assemblage + likelihood
            kernels.append(np.exp(scores - np.logaddexp.reduce(scores, axis=1)[:, None]))
        return cls(site._hpost(assayed or {}), site.prim, kernels)

    def _leaf_entropies(self, joint):
        # Sum of P(outcomes)*H(primary | outcomes), independent of outcome ordering.
        groups = np.stack([joint[indices].sum(axis=0) for indices in self.group_indices])
        mass = groups.sum(axis=0)
        return float(xlogy(mass, mass).sum() - xlogy(groups, groups).sum())

    def fixed_value(self, prior, chosen):
        # Chunk on early outcomes so a large support does not allocate a full
        # hypotheses x joint-outcomes array. Zero-mass branches contribute zero.
        sizes = [self.kernels[i].shape[1] for i in chosen]
        if len(chosen) >= 2 and len(prior) * prod(sizes) > 1_000_000:
            first = self.kernels[chosen[0]]
            return sum(self.fixed_value(prior * col, chosen[1:]) for col in first.T)
        joint = prior[:, None]
        for i in chosen:
            joint = (joint[:, :, None] * self.kernels[i][:, None, :]).reshape(len(prior), -1)
        return max(0.0, self._leaf_entropies(joint))

    def solve(self, budget, costs=None, excluded=(), max_leaves=2_000_000):
        """Find the best fixed set and the best policy that branches on lab results.

        Positive integer costs and budget use a single caller-defined unit.
        max_leaves bounds the number of evaluated outcome leaves in BOTH searches.
        A SearchLimit always discards the partial search; no optimum is claimed.
        """
        n = len(self.kernels)
        costs = [1] * n if costs is None else list(costs)
        if (not isinstance(budget, (int, np.integer)) or budget < 0 or len(costs) != n or
                any(not isinstance(c, (int, np.integer)) or c < 1 for c in costs) or
                not isinstance(max_leaves, (int, np.integer)) or max_leaves < 1):
            raise ValueError("Use a nonnegative integer budget, positive integer costs, and a positive work limit.")
        omitted = set(excluded)
        if any(not isinstance(i, (int, np.integer)) or not 0 <= i < n for i in omitted):
            raise ValueError("Unknown excluded sample index.")
        available = tuple(i for i in range(n) if i not in omitted and costs[i] <= budget)
        leaves = 0
        batch_sets = 0

        def debit(count):
            nonlocal leaves
            if leaves + count > max_leaves:
                raise SearchLimit(f"Exact search exceeds {max_leaves:,} outcome leaves. Reduce the budget or use fewer candidate samples, or increase --max-leaves.")
            leaves += count

        def fixed_sets(start, selected, left):
            # Traverse feasible sets only; skip supersets with unaffordable costs.
            yield selected
            for pos in range(start, len(available)):
                i = available[pos]
                if costs[i] <= left:
                    yield from fixed_sets(pos + 1, selected + (i,), left - costs[i])

        initial = self.fixed_value(self.prior, ())
        best_batch, batch_value = (), initial
        for selected in fixed_sets(0, (), budget):
            batch_sets += 1
            debit(prod(self.kernels[i].shape[1] for i in selected))
            v = self.fixed_value(self.prior, selected)
            if v < batch_value - 1e-13:
                best_batch, batch_value = selected, v

        def adaptive(prior, available, left):
            best = {"sample": None, "entropy_nats": self.fixed_value(prior, ())}
            for i in available:
                if costs[i] > left:
                    continue
                k = self.kernels[i]
                prob = prior @ k
                next_candidates = tuple(j for j in available if j != i and costs[j] <= left-costs[i])
                if not next_candidates:
                    debit(len(prob))
                    value = self.fixed_value(prior, (i,))
                    branches = None
                else:
                    value = 0.0
                    branches = []
                    for a in np.flatnonzero(prob > 0):
                        child = adaptive(prior * k[:, a] / prob[a], next_candidates, left-costs[i])
                        value += float(prob[a]) * child["entropy_nats"]
                        branches.append({"outcome": int(a), "probability": float(prob[a]), "next": child})
                if value < best["entropy_nats"] - 1e-13:
                    best = {"sample": i, "entropy_nats": value}
                    if branches is not None:
                        best["branches"] = branches
            return best

        tree = adaptive(self.prior, available, budget)
        return {
            "objective": "minimum expected Shannon entropy of primary system, nats",
            "budget": int(budget),
            "initial_entropy_nats": initial,
            "fixed": {"samples": list(best_batch), "entropy_nats": batch_value},
            "adaptive": tree,
            "adaptive_saving_over_fixed_nats": max(0.0, batch_value - tree["entropy_nats"]),
            "search": {"feasible_fixed_sets": batch_sets, "evaluated_outcome_leaves": leaves,
                       "max_leaves": int(max_leaves), "tie_tolerance_nats": 1e-13},
        }
