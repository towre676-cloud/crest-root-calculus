# Crest–Root · Three working experiments

**Extract the entire ZIP, then double-click [index.html](index.html).** The mechanism builder, measured-spectrum explorer, assay decision tree and solar offer explorer work offline. On Windows, right-click the ZIP, choose **Extract All**, and open the extracted folder. All the links and calculations in the browser examples are local.

| What do you want to know? | Where to begin | Change one thing |
| --- | --- | --- |
| Will a wing turn if I cut the pin holes a little off? | [Linkwright](motion_builder/index.html) · [Printable wing kit](motion_builder/wing-kit.pdf) | Request a 60° swing at a 1.8× timing ratio with a 70 mm rocker. Increase the pin-spacing error to ±5 mm, then search the available cardboard sizes. |
| Which mineral mixtures could give this scan? | [Measured spectra](assay_selector/mixtures.html) | Keep the 60/40 example and ±0.005 tolerance. Switch from one band to three. Then select a physical powder blend and use all bands. |
| Which rock should go to the lab next? | [Assay decision tree](assay_selector/policy.html) | Start with S07. Try two different lab results and compare where the second assay goes. |
| Does a tighter solar offer hold up in another year? | [FlexExport](solar_export/offers.html) | Choose 18 candidate homes. Inspect an individual roof and compare flexible and fixed caps on real household profiles mapped onto the same simulated feeder. |

## What the mathematics changes

**Linkwright can reject a build that looks fine throughout a 720-frame check.** For the rigid planar four-bar, the crank-to-pivot distance sweeps a known interval. Testing triangle closure at the appropriate extrema covers the continuous revolution, including combinations of independent pin-spacing errors. One regression passes every one of 720 sampled poses yet fails at 180.25°. A cut-tolerance search finds 159% is the smallest passing whole-percent cardboard scale for the worked wing. The pin-center limits and the assessed pairs of moving bars are explicit; friction, play, the mounted wing and the physical material need a build test. The projective configuration equation gives exact integer assembly counts, and smooth cases give a genus-one curve, an exact rational j-invariant and point counts at good primes. The PDF is an actual-size parts sheet with a 50 mm print check. [Geometry, material assumptions and build instructions](motion_builder/README.md)

**GeoAssay separates spectral identification from the decision to buy another assay.** The package includes measured USGS spectra for fifteen reference minerals, fifteen different challenge specimens and four physical powder blends. On the 15 challenge specimens, the measured reference identifies 5 with raw spectral angle and 14 after removing the smooth background. On all four powder blends, every one of the 105 two-mineral pairs fails the ±0.005 linear-mixture tolerance. Correctly ranking a label and adequately fitting a measurement are different tests. On the constructed 60/40 blend, exact rational intersection reduces 50 possible pairs at one wavelength to one pair at three. On the independent **synthetic site** exercise, fixed and sequential assay planning both identify 91 primary systems out of 100; fifteen first lab results lie outside the shortlist. The release records those outcomes and supports replanning after a confirmed lab result. [Measured inputs, specimens and checksums](assay_selector/data/SOURCES.md) · [Planning methods and validation](assay_selector/README.md)

**FlexExport tests where an offer fails as well as how much energy it saves.** An independent radial AC calculation reproduces the original 0, 47 and 106 uncapped violation-hour counts at 12, 18 and 24 new homes under the original scoring rules. The new calculation checks all hours, all modeled buses and thermal limits. It also distinguishes removing the new houses entirely, retaining their loads without solar, and allowing self-consumption with zero net export. That distinction matters on hot evenings.

The 18-home counterfactual uses **50 actual Ausgrid household profiles** mapped to a hypothetical feeder and panel sizes. On the full 2012–13 meter year the original flexible schedule allowed 365 modeled violation hours. A schedule tightened using synthetic scenarios still had 95.5 hours. A separate pair of flexible and fixed offers was fitted once on 2010–11 meter data and frozen for the following comparison.

| Later meter period | Included days | Flexible violation hours | Fixed violation hours | Additional energy the flexible offer exports |
| --- | ---: | ---: | ---: | ---: |
| 2011–12 | 173 | 0 | 0 | 2,145 kWh |
| 2012–13 | 365 | 3.5 | 0 | 4,644 kWh |

The second period had already been inspected during the earlier transfer test. This is a retrospective repeat-year comparison. The 173 days represent complete simultaneous readings for the same 50 meters. The real measurements are customer demand and solar generation. Feeder topology, panel sizes, source voltage, voltages at the houses and line loadings are modeled. No network operator has approved these offers. [Full comparisons, dated failures, finite search and reproducible commands](solar_export/README.md)

## Reproduce the results

The browser pages and PDF require no installation. To run the scientific tests, use Python 3.11 or 3.12 and Node.js. From this extracted folder:

```shell
python -m pip install -r requirements.txt
python verify.py
```

The distribution includes the original scientific inputs for the USGS experiments. To replay the Ausgrid study from raw readings, use the pinned public archive and the extraction commands in the FlexExport guide. For the optional Linkwright browser regression, install Python's `playwright`, run `python -m playwright install chromium`, then run `python verify.py --browser`. The new spectral and solar browser tables can be regenerated with `python guide/build_tables.py`.

The [input ZIP](original/three_builds.zip) is a byte-for-byte copy of the upload. Its README and receipts document the original results and definitions. The separate [Crest–Root mathematical control](https://github.com/towre676-cloud/crest-root-calculus) remains the reference for the plane-quartic discovery problem. This release adds different calculations for mechanisms, optical mixtures and power flow.
