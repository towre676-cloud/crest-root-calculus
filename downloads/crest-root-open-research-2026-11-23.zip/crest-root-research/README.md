# Crest-Root open research, 23 November 2026

Read [the research results](research/README.md) or the [57-item register](research/backlog-2026-11-23.md). The packet includes the canonical 148-section monograph, the marked chart-I solver, point-free Riemann-Roch, genus-two correspondences, the genus-37 rank certificates, the quartic degree spectra, the historical atlas and higher-support tower certificates.

After extracting, open a terminal in this folder. Windows commands:

```sh
py -m pip install numpy "sympy>=1.12,<2"
py research/replay.py
```

On macOS or Linux, substitute `python3` for `py`. The replay launches the research verifications listed in research/replay.py. These 28 verification groups run offline. If PARI/GP is installed, the rank replay also regenerates the number-field and local arithmetic behind the upper bounds. Without GP, the Python replay checks the recorded descent matrices and every lower-bound divisor certificate.
