import hashlib
import json
from fractions import Fraction
from pathlib import Path

import numpy as np

from geoassay.library import _resample_common, measured_specimens
from geoassay.pair_bounds import all_pairs, interval_for_pair

ROOT=Path(__file__).resolve().parents[1]

def test_source_checksums_and_reference_grid():
    base=ROOT/'data'/'usgs_v7'
    manifest=json.loads((base/'manifest.json').read_text())
    for name,v in manifest['members'].items():
        assert hashlib.sha256((base/name).read_bytes()).hexdigest()==v['sha256']
    a,b=measured_specimens()
    assert a.R.shape == b.R.shape == (204,15)
    assert np.all(np.isfinite(a.R))
    for specimens in manifest['specimens'].values():
        assert specimens['reference'] != specimens['challenge']


def test_no_bridging_masked_channels_or_extrapolation():
    x=np.arange(5.)
    grid,vals=_resample_common(x,[np.array([0.,1.,-1.2e34,3.,4.])],np.arange(-1,6,.5))
    assert list(grid)==[0,.5,1,3,3.5,4]
    assert np.array_equal(vals[:,0],grid)


def test_negative_slopes_and_flat_bands_and_closed_boundary():
    r=interval_for_pair([('a',1,0,Fraction(1,2)),('b',0,1,Fraction(1,2))],0)
    assert r['possible'] and r['lower']==r['upper']=='1/2'
    assert not interval_for_pair([('flat',1,1,0)],0)['possible']
    conflict=interval_for_pair([('a',1,0,Fraction(1,3)),('b',1,0,Fraction(2,3))],0)
    assert not conflict['possible'] and {conflict['upper_from'],conflict['lower_from']}=={'a','b'}


def test_measured_references_exact_example():
    ref,_=measured_specimens()
    obs={Fraction(f'{wl:.3f}'):Fraction(f'{(.6*r[0]+.4*r[1]):.6f}') for wl,r in zip(ref.wl,ref.R)}
    pairs=all_pairs(ref,obs,Fraction('0.005'))
    fits=[p for p in pairs if p['possible']]
    assert len(pairs)==105 and len(fits)==1
    r=fits[0]
    assert Fraction(r['lower']) <= Fraction(3,5) <= Fraction(r['upper'])
    assert (r['lower'],r['upper'])==('220775/376292','230775/376292')
