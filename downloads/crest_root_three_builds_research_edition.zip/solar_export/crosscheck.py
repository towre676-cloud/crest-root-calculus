"""Compare every LV bus, cable terminal loading and transformer against pandapower Newton AC."""

import argparse
import json
from pathlib import Path
import numpy as np
import pandapower as pp
from flexexport import build_feeder
from flexexport.audit import Offer, WeatherYear, CONDITIONS


def crosscheck(receipt):
    model = Offer.read(receipt)
    network, _ = build_feeder(
        n_new=model.flexible.shape[-1],
        n_existing=model.n_existing,
        seed=json.loads(Path(receipt).read_text()).get("feeder_seed", 0),
    )
    weather = WeatherYear(model, 113)
    hours = np.array(
        [0, 54 * 24 + 6, 112 * 24 + 12, 192 * 24 + 12, 208 * 24 + 18, 209 * 24 + 20]
    )
    worst_v = worst_i = 0.0
    for cond in CONDITIONS:
        network.ext_grid.loc[:, "vm_pu"] = cond.source
        for cap in (None, model.flexible, np.zeros_like(model.flexible)):
            p, q, _, _ = weather.powers(cond, hours, cap)
            independent = model.grid.solve(p, q, cond.source)
            for k, hour in enumerate(hours):
                # Constant PQ injection; negative demand represents net generation.
                network.load.loc[:, "p_mw"] = p[k] / 1000
                network.load.loc[:, "q_mvar"] = q[k] / 1000
                pp.runpp(network, algorithm="nr", numba=False, tolerance_mva=1e-11)
                volts = network.res_bus.vm_pu.values[1:]
                loads = np.r_[
                    network.res_trafo.loading_percent.values,
                    network.res_line.loading_percent.values,
                ]
                worst_v = max(
                    worst_v, float(np.max(abs(volts - independent.voltage[k])))
                )
                worst_i = max(
                    worst_i, float(np.max(abs(loads - independent.loading[k])))
                )
    if worst_v > 1e-7 or worst_i > 1e-4:
        raise ArithmeticError("The independent solver disagrees with pandapower.")
    return {
        "source": Path(receipt).name,
        "pandapower_version": pp.__version__,
        "profile_seed": 113,
        "hour_indices": hours.tolist(),
        "operating_states": len(hours) * len(CONDITIONS) * 3,
        "max_abs_voltage_error_pu": worst_v,
        "max_abs_loading_error_pct_points": worst_i,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipt", nargs="?", default="receipt_new18.json")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = json.dumps(crosscheck(args.receipt), indent=2) + "\n"
    if args.output:
        if args.output.resolve() == Path(args.receipt).resolve():
            parser.error("Output must differ from the input.")
        args.output.write_text(result)
    print(result, end="")
