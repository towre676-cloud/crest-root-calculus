# Crest–Root periodic spectra, 23 November 2026

This standalone packet contains the exact periodic Jacobi-ring challenge,
proofs, source code, complete measurements, frozen protocols and references,
the compiled-PARI follow-up, and independent verification.

Read [the study guide](research/periodic-spectra/README.md),
[the original results](research/periodic-spectra/results.md), and
[the compiled-PARI comparison](research/periodic-spectra/native-results.md).
The [spectral-curve companion](research/periodic-spectra/spectral-curve.md)
proves and checks the classical normalization identity for repeated cells.

After extracting, open a terminal in this folder. Windows commands:

```sh
py -m pip install "sympy>=1.12,<2"
py research/periodic-spectra/audit_native.py
py research/periodic-spectra/spectral_curve.py
```

On macOS or Linux, substitute `python3` for `py`. The stored study audit runs
offline and independently recomputes every output coefficient. No compiled
solver binary is needed to check the stored mathematics and measurements.
New timing runs require the documented C/C++ compilers, GMP, PARI/GP and a
POSIX environment; use the study guide for exact build and run commands.

The archive's MANIFEST.json records the size and SHA-256 of every other file.
The complete research packet additionally contains all 32 research
verification groups and the introductory PDF.
