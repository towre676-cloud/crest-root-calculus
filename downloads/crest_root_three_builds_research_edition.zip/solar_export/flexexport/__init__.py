"""The AC replay and stress audit need only NumPy. The legacy designer also needs pandapower."""

from .calendar import SEASON, SEASON_NAMES, SUN_HOURS
from .profiles import year

__version__ = "0.2.0"
__all__ = [
    "build_feeder",
    "year",
    "Grid",
    "design_offers",
    "verify",
    "SEASON",
    "SEASON_NAMES",
    "SUN_HOURS",
]


def __getattr__(name):
    if name == "build_feeder":
        from .feeder import build_feeder

        return build_feeder
    if name in {"Grid", "design_offers", "verify"}:
        from . import engine

        return getattr(engine, name)
    raise AttributeError(name)
