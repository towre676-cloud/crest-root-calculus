"""Monte-Carlo validation: does value-of-information selection beat simple rules at fixing the site interpretation?"""
import json, sys, time, numpy as np
from geoassay import builtin_proxy, assemblage_posterior, Site, select, SITE_MODELS, ZONES
lib = builtin_proxy(); M = lib.names; import os
SIG = float(os.environ.get('SIG', 0.03)); NS = int(os.environ.get('NS', 6)); OVER = float(os.environ.get('OVER', 0.35))

OTHER = {}
OPW = tuple(float(x) for x in os.environ.get('OPW', '0,0.2,0.4').split(','))
def make_site(rng, model, n=None):
    n = n or NS
    samples, truth = [], []
    for k in range(n):
        zone = ZONES[k*len(ZONES)//n]
        pz = dict(SITE_MODELS[model][zone])
        # overprinting / misspecification: blend in another system's zone probabilities
        if OVER > 0:
            other = SITE_MODELS[OTHER[model]][zone]
            pz = {m: (1-OVER)*pz.get(m, .02) + OVER*other.get(m, .02) for m in set(pz) | set(other)}
        a = [m for m in M if rng.random() < pz.get(m, 0.02)]
        if not a: a = [max(sorted(pz), key=pz.get)]
        if len(a) > 3: a = list(rng.choice(a, 3, replace=False))
        f = rng.dirichlet(np.ones(len(a))*2)
        y = lib.R[:, [M.index(x) for x in a]] @ f + rng.normal(0, .02) + rng.normal(0, SIG, len(lib.wl))
        hyps = assemblage_posterior(lib, y, SIG, kmax=3, top=20)
        s = sum(h["p"] for h in hyps); [h.__setitem__("p", h["p"]/s) for h in hyps]
        samples.append({"id": f"S{k+1:02d}", "zone": zone, "hyps": hyps}); truth.append(tuple(sorted(a)))
    return samples, truth

def H(p): return float(-(p*np.log(p+1e-300)).sum())

def run(trials, budget, seed):
    rng = np.random.default_rng(seed); res = {k: [] for k in ("none","voi","ambiguous","random")}
    models = list(SITE_MODELS); scan_hit = 0; t0 = time.time()
    # each system is overprinted by its most similar neighbour (the hard case)
    OTHER.update({"high-sulfidation epithermal": "supergene oxidation cap", "supergene oxidation cap": "high-sulfidation epithermal",
                  "porphyry phyllic-propylitic": "intermediate argillic (low-sulfidation)", "intermediate argillic (low-sulfidation)": "porphyry phyllic-propylitic",
                  "carbonate-hosted / skarn margin": "porphyry phyllic-propylitic"})
    for t in range(trials):
        true = models[t % len(models)]
        samples, truth = make_site(rng, true)
        scan_hit += np.mean([tuple(sorted(s["hyps"][0]["minerals"])) == tr for s, tr in zip(samples, truth)])
        site = Site(samples, M, overprint_weights=OPW); ti = models.index(true)
        picks = {"none": [],
                 "voi": select(site, budget, exhaustive_limit=0)[0],
                 "ambiguous": list(np.argsort([-H(np.array([h["p"] for h in s["hyps"]])) for s in samples])[:budget]),
                 "random": list(rng.choice(len(samples), budget, replace=False))}
        for k, ch in picks.items():
            p = site.posterior({int(i): truth[int(i)] for i in ch})
            res[k].append({"p_true": float(p[ti]), "map_ok": int(np.argmax(p) == ti), "H": H(p),
                           "confident_wrong": bool(np.argmax(p) != ti and p.max() > 0.9)})
    summ = {k: {"mean_p_true": round(float(np.mean([r["p_true"] for r in v])), 4),
                "map_accuracy": round(float(np.mean([r["map_ok"] for r in v])), 4),
                "mean_entropy_nats": round(float(np.mean([r["H"] for r in v])), 4),
                "wrong_with_p>0.9": int(sum(r["confident_wrong"] for r in v))} for k, v in res.items()}
    import math
    for k in ("voi","ambiguous","none"):
        d = np.array([a["p_true"]-b["p_true"] for a, b in zip(res[k], res["random"])])
        summ[k]["p_true_minus_random"] = round(float(d.mean()), 4); summ[k]["se"] = round(float(d.std(ddof=1)/math.sqrt(len(d))), 4)
        e = np.array([a["H"]-b["H"] for a, b in zip(res[k], res["random"])])
        summ[k]["entropy_minus_random"] = round(float(e.mean()), 4); summ[k]["entropy_se"] = round(float(e.std(ddof=1)/math.sqrt(len(e))), 4)
    return {"trials": trials, "budget": budget, "samples_per_site": NS, "noise_sigma": SIG, "overprint": OVER, "inference_overprint_weights": OPW, "seed": seed,
            "scan_top_assemblage_exact_rate": round(scan_hit/trials, 4), "strategies": summ, "seconds": round(time.time()-t0, 1)}

if __name__ == "__main__":
    out = run(int(sys.argv[1]) if len(sys.argv) > 1 else 40, int(os.environ.get('B', 2)), 7)
    print(json.dumps(out, indent=1)); json.dump(out, open("validation_receipt.json", "w"), indent=1)
