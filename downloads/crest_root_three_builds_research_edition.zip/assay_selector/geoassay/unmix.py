"""Linear unmixing and enumeration of near-equivalent mixtures.

For every mineral subset of size <= kmax a non-negative least-squares fit with an additive offset is
made.  Each subset is scored by an approximate marginal likelihood (Laplace/BIC form with known
noise sigma); the normalised scores are a posterior over assemblages for that scan.  "Ambiguous"
means two or more assemblages share the top posterior mass with different mineral content.
"""
from __future__ import annotations
import itertools, numpy as np
from scipy.optimize import nnls

def fit_subset(lib, idx, y):
    # Analytically profile out a free intercept instead of fitting duplicate
    # positive/negative constant columns, which form a singular NNLS subproblem.
    A = lib.R[:, list(idx)]
    centred = A - A.mean(axis=0)
    x, rn = nnls(centred, y - y.mean())
    return x, rn**2

def assemblage_posterior(lib, y, sigma, kmax=3, prior_per_mineral=0.35, top=None):
    y = np.asarray(y, dtype=float)
    if y.shape != (len(lib.wl),) or not np.all(np.isfinite(y)):
        raise ValueError("Scan must have one finite reading per reference wavelength.")
    if not np.isfinite(sigma) or sigma <= 0 or not 0 < prior_per_mineral < 1 or kmax < 1:
        raise ValueError("Invalid noise scale, mineral prior or mixture size.")
    n, m = len(y), len(lib.names)
    hyps = []
    for k in range(1, kmax+1):
        for idx in itertools.combinations(range(m), k):
            ab, rss = fit_subset(lib, idx, y)
            if np.any(ab < 1e-3):       # a member with ~0 abundance is the smaller subset; skip duplicate
                continue
            logL = -rss/(2*sigma**2) - 0.5*(k+2)*np.log(n)     # BIC-style penalty
            logP = k*np.log(prior_per_mineral) + (m-k)*np.log(1-prior_per_mineral)
            frac = ab/ab.sum()
            hyps.append({"minerals": tuple(lib.names[i] for i in idx), "fractions": frac, "rss": rss, "score": logL+logP, "log_scan_prior": logP})
    if not hyps:
        raise ValueError("No assemblage has positive fitted abundance. Check the reference, scan and wavelength range.")
    s = np.array([h["score"] for h in hyps]); p = np.exp(s - s.max()); p /= p.sum()
    for h, pi in zip(hyps, p): h["p"] = float(pi)
    hyps.sort(key=lambda h: -h["p"])
    return hyps[:top] if top else hyps

def ambiguity(hyps, mass=0.9):
    """Distinct assemblages needed to reach `mass` posterior; >1 means the scan does not decide."""
    acc, out = 0.0, []
    for h in hyps:
        out.append(h); acc += h["p"]
        if acc >= mass: break
    return out
