"""Rebuild the two browser data tables from the scientific release inputs."""
import json
import sys
import numpy as np
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/"assay_selector"))
from measured_benchmark import benchmark
from geoassay.library import _resample_common


def write_js(path, name, value):
    path.write_text("window."+name+"="+json.dumps(value,separators=(",",":"),allow_nan=False)+";\n")


def build():
    _, ref, test, example = benchmark()
    fixed = lambda xs: (xs*1_000_000).round().astype(int).tolist()
    data = BASE/"assay_selector"/"data"
    meta = json.loads((data/"usgs_v7"/"manifest.json").read_text())
    native = np.loadtxt(data/"usgs_v7"/meta["wavelengths"],skiprows=1)
    physical = []
    for m in json.loads((data/"physical_mixtures"/"manifest.json").read_text())["records"]:
        raw = np.loadtxt(data/"physical_mixtures"/m["file"],skiprows=1)
        wl,values = _resample_common(native,[raw],ref.wl)
        available = {round(float(w),3):int(round(float(v)*1e6)) for w,v in zip(wl,values[:,0])}
        physical.append({"id":m["id"], "label":" + ".join(f"{n} ({q:.0%})" for n,q in m["minerals_by_weight"].items()),
                         "spectrum":[available.get(round(float(w),3)) for w in ref.wl]})
    write_js(data/"reference_curves.js","measuredCurves",
             dict(names=ref.names,wl=ref.wl.tolist(),refs=fixed(ref.R.T),tests=fixed(test.R.T),mix=fixed(example),physical=physical))
    solar = BASE/"solar_export"
    tables = {}
    for n in (12,18,24):
        old = json.loads((solar/f"receipt_new{n}.json").read_text())
        new = json.loads((solar/f"stress_new{n}.json").read_text())
        tables[n] = dict(people=[{k:p[k] for k in ("home","where","pv_kw","static_cap_kw")} for p in old["per_home"]],
                         original=old["flex_caps_kw"],revised=new["revised_caps_kw"],eval=new["evaluation"])
    metered = json.loads((solar/"metered_18.json").read_text())
    tables[18]["metered"] = metered["evaluation"]["nominal"]
    calibrated = json.loads((solar/"metered_calibration_18.json").read_text())
    tables[18]["calibration"] = calibrated["evaluation"]
    tables[18]["calibrated_caps"] = calibrated["revised_caps_kw"]
    write_js(solar/"offer_curves.js","offers",tables)

if __name__ == "__main__":
    build()
