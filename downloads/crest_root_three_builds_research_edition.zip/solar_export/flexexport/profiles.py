"""Synthetic but physically structured hourly year: clear-sky PV at 41.7 N with a day-type cloud
Markov chain, temperature with seasonal cycle and heat waves, and residential load with lighting,
cooking peaks and air-conditioning above 24 C.  For measured-profile replay use flexexport.metered."""
from __future__ import annotations
import numpy as np

LAT = np.deg2rad(41.7)
HOURS = np.arange(24)

def clear_sky(doy, hour):
    decl = np.deg2rad(23.45)*np.sin(2*np.pi*(284+doy)/365)
    ha = np.deg2rad(15*(hour + 0.5 - 12))
    cosz = np.sin(LAT)*np.sin(decl) + np.cos(LAT)*np.cos(decl)*np.cos(ha)
    cosz = np.maximum(cosz, 0)
    return cosz * 0.75**(1/np.maximum(cosz, 0.05))**0.678 * (cosz > 0.02)  # Meinel-type attenuation, ~kW/kWp

def year(n_homes, seed=0):
    rng = np.random.default_rng(seed)
    D = 365
    # cloud day types: 0 clear, 1 partly, 2 overcast; seasonal persistence
    state = np.zeros(D, int); P = np.array([[.6, .3, .1], [.35, .4, .25], [.2, .35, .45]])
    for d in range(1, D): state[d] = rng.choice(3, p=P[state[d-1]])
    kday = np.array([1.0, 0.65, 0.22])[state] * rng.uniform(.9, 1.0, D)
    T_mean = 10.5 - 13*np.cos(2*np.pi*(np.arange(D)-15)/365) + np.cumsum(rng.normal(0, 1.2, D))*0.0
    anomaly = np.zeros(D)
    for d in range(1, D): anomaly[d] = .75*anomaly[d-1] + rng.normal(0, 2.2)
    for start in rng.choice(np.arange(170, 235), 3, replace=False):   # three summer heat waves
        anomaly[start:start+4] += rng.uniform(6, 9)
    T = (T_mean + anomaly)[:, None] + 5*np.sin(2*np.pi*(HOURS-9)/24)[None, :]
    cs = np.array([[clear_sky(d+1, h) for h in HOURS] for d in range(D)])
    pv_unit = cs * kday[:, None] * np.clip(1 + rng.normal(0, .08, (D, 24)) * (state[:, None] == 1) * 3, .2, 1.15)
    pv_unit *= (1 - 0.004*np.maximum(T - 25, 0))          # temperature derating
    # residential load (kW) per home
    base = .35 + .25*np.exp(-0.5*((HOURS-7.5)/1.2)**2) + .9*np.exp(-0.5*((HOURS-18.5)/2.0)**2)
    winter_light = .25*np.exp(-0.5*((HOURS-17.5)/1.5)**2)
    seasonal = (1 + 0.25*np.cos(2*np.pi*(np.arange(D)-15)/365))[:, None]
    load = np.empty((n_homes, D, 24)); orient = rng.uniform(.82, 1.0, n_homes)
    weekend = (np.arange(D) % 7 >= 5)[:, None]
    for i in range(n_homes):
        scale = rng.uniform(.6, 1.6)
        ac = rng.uniform(.25, .55)*np.maximum(T - 24, 0) * (rng.random() < .8)
        occ = 1 + .35*weekend*np.exp(-0.5*((HOURS-13)/3)**2)[None, :]
        load[i] = scale*(base[None, :]*seasonal*occ + winter_light[None, :]*(seasonal-0.9).clip(0)*3) + ac + rng.gamma(2, .06, (D, 24))
    return {"pv_unit": pv_unit, "orient": orient, "load_kw": load, "T": T, "cloud_state": state}
