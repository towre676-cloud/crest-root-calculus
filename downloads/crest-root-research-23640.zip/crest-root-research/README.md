# Crest-Root research packet, 23 November 2026

Read [the 57-item research register](research/backlog-2026-11-23.md) or [the proof for row 23640 and its infinite family](research/elliptic-quotients/row-23640/README.md).

To reproduce the new certificate on Windows, extract this ZIP, open a terminal in its folder and run:

```sh
py -m pip install "sympy>=1.12,<2"
py research/elliptic-quotients/row-23640/verify.py
```

On macOS or Linux, use `python3` in place of `py`. The verifier recomputes the JSON in `receipt.json`. The original twelve-row input and historical bounded run are included for comparison.
