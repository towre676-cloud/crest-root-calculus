"""Can N additional PV homes connect if they accept flexible export limits?  Full experiment + receipt."""
import json, sys, time, warnings, numpy as np
warnings.filterwarnings("ignore")
from flexexport import build_feeder, year, Grid, design_offers, verify, SEASON, SEASON_NAMES, SUN_HOURS

def experiment(n_new, n_existing, seed=0, log=print):
    t0 = time.time()
    net, homes = build_feeder(n_existing=n_existing, n_new=n_new, seed=seed)
    prof = year(len(homes), seed=seed); g = Grid(net, homes, prof)
    D = 365; rng = np.random.default_rng(seed + 100)
    # held-out stress days, chosen before any training: 12 highest feeder peak load, 12 highest midday surplus
    tot_load = prof["load_kw"][:len(homes)].sum(0)
    pv_tot = sum(h["pv_kw"] for h in homes) * prof["pv_unit"]
    peak_load = np.argsort(-tot_load.max(1))[:12]
    surplus = np.argsort(-(pv_tot - tot_load)[:, 10:15].max(1))
    peak_surplus = [d for d in surplus if d not in peak_load][:12]
    stress = set(map(int, peak_load)) | set(map(int, peak_surplus))
    rest = np.array([d for d in range(D) if d not in stress]); rng.shuffle(rest)
    train = sorted(rest[:int(.7*len(rest))].tolist()); test = sorted(rest[int(.7*len(rest)):].tolist())
    log(f"N_new={n_new}: train {len(train)} days, random test {len(test)}, stress {len(stress)}")
    flex = design_offers(g, train, log=log)
    stat = design_offers(g, train, static=True, log=log)
    res = {}
    for name, days in (("test_random", test), ("test_peak_load", sorted(map(int, peak_load))), ("test_peak_surplus", sorted(map(int, peak_surplus)))):
        res[name] = {}
        for scen, kw in (("same_homes_without_candidate_pv", dict(connect_new=False, unlimited=True)), ("unlimited_export", dict(unlimited=True)),
                         ("static_cap", {}), ("flexible_offer", {})):
            caps = flex if scen == "flexible_offer" else stat
            v = verify(g, caps, days, **kw)
            res[name][scen] = {"violation_hours": v["violations"], "preexisting_import_overload_hours": v["preexisting_import_overloads"], "worst_v_pu": round(v["worst_v"], 4), "worst_loading_pct": round(v["worst_loading"], 1)}
    # energy given up over the whole year (deterministic given caps)
    ann = {s: verify(g, c, range(D)) for s, c in (("static_cap", stat), ("flexible_offer", flex))}
    per_home = []
    for k, i in enumerate(g.new):
        hm = homes[i]; pv = ann["flexible_offer"]["pv_kwh"][k]; sur = ann["flexible_offer"]["surplus_kwh"][k]
        lost_f = sur - ann["flexible_offer"]["exported_kwh"][k]; lost_s = sur - ann["static_cap"]["exported_kwh"][k]
        crowded = [(SEASON_NAMES[s], h, round(float(flex[s, h, k]), 2)) for s in range(4) for h in SUN_HOURS if flex[s, h, k] < hm["pv_kw"] - 0.05]
        per_home.append({"home": hm["name"], "where": hm["where"], "pv_kw": hm["pv_kw"], "pv_kwh_year": round(float(pv)),
                         "export_surplus_kwh_year": round(float(sur)),
                         "flexible_gives_up_kwh": round(float(lost_f)), "flexible_gives_up_pct_of_pv": round(100*float(lost_f/pv), 2),
                         "static_cap_kw": round(float(stat[0, 12, k]), 2),
                         "static_gives_up_kwh": round(float(lost_s)), "static_gives_up_pct_of_pv": round(100*float(lost_s/pv), 2),
                         "limited_hours": len(crowded), "limits": crowded})
    return {"feeder_seed": seed, "profile_seed": seed, "legacy_evaluation": "sun-hour, aggregate overload attribution", "n_new": n_new, "n_existing": n_existing, "existing_pv_kw": sum(h["pv_kw"] for h in homes if not h["new"]),
            "vmax_pu": g.vmax, "line_limit_pct": g.lmax, "days": {"train": len(train), "test_random": len(test), "peak_load": sorted(map(int, peak_load)), "peak_surplus": sorted(map(int, peak_surplus))},
            "evaluation": res, "per_home": per_home, "flex_caps_kw": flex.round(3).tolist(), "seconds": round(time.time()-t0, 1)}

if __name__ == "__main__":
    out = []
    for nn, ne in [(int(a.split(':')[0]), int(a.split(':')[1])) for a in (sys.argv[1:] or ["18:32"])]:
        r = experiment(nn, ne); out.append(r)
        json.dump(r, open(f"receipt_new{nn}.json", "w"), indent=1)
        print(json.dumps({k: r[k] for k in ("n_new", "evaluation", "seconds")}, indent=1)); sys.stdout.flush()
