"""Run product regressions from the distribution root. Browser tests are optional."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def run(args, directory):
    print(f"\n[{directory}] " + " ".join(str(a) for a in args), flush=True)
    subprocess.run(args, cwd=ROOT/directory, check=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--browser", action="store_true", help="Also exercise Linkwright in Playwright Chromium")
    p.add_argument("--chromium",help="Existing Chromium executable for the optional browser test")
    args = p.parse_args()
    for directory in ("assay_selector", "solar_export"):
        run([sys.executable,"-m","pytest","-q","tests"],directory)
    run([sys.executable,"verify.py"],"research/configuration-and-certificates")
    node = shutil.which("node")
    if node is None:
        p.exit(1,"Python checks passed. Install Node.js to run the motion geometry suite.\n")
    run([node,"test_geometry.cjs"],"motion_builder")
    if args.browser or args.chromium:
        extra = ["--chromium",args.chromium] if args.chromium else []
        run([sys.executable,"test_page.py",*extra],"motion_builder")
    print("\nAll requested checks passed.")

if __name__ == "__main__":
    main()
