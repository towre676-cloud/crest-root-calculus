"""Render the front page using geometry, spectra and offer caps from working examples."""
from math import sqrt
from pathlib import Path
import json
import sys
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'assay_selector'))
from geoassay.library import load_measured_reference

def sketch(title, marks):
    return f'<svg viewBox="0 0 210 88" role="img" aria-label="{title}" xmlns="http://www.w3.org/2000/svg"><title>{title}</title>{marks}</svg>'
def path(points,color):
    d=' '.join(('M' if i==0 else 'L')+f'{x:.2f},{y:.2f}' for i,(x,y) in enumerate(points))
    return f'<path d="{d}" fill="none" stroke="{color}" stroke-width="2.5" stroke-linejoin="round"/>'
def draw():
    # Four-bar with ground 100, crank 30, coupler 75 and rocker 55.4, input at 90 degrees.
    a=(32,67); b=(32,46); d=(102,67)
    dx=d[0]-b[0];dy=d[1]-b[1]; span=sqrt(dx*dx+dy*dy)
    along=((75*.7)**2-(55.4*.7)**2+span*span)/(2*span)
    perp=sqrt((75*.7)**2-along**2)
    c=(b[0]+(along*dx+perp*dy)/span,b[1]+(along*dy-perp*dx)/span)
    motion=sketch('Four links joined at pins',path([a,d],'#89998e')+path([a,b,c,d],'#00675e')+''.join(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="3.9" fill="#faf8ef" stroke="#182c2b" stroke-width="2"/>' for x,y in [a,b,c,d])+ '<text x="118" y="68" fill="#485d55" font-size="11">100 mm base</text>')
    ref=load_measured_reference()
    bands=ref.wl>=2.1
    spec=sketch('Measured kaolinite and dickite from 2.1 to 2.5 micrometres',''.join(path([(10+460*(float(w)-2.1),80-float(v)*74) for w,v in zip(ref.wl[bands],ref.R[bands,i])],color) for i,color in [(0,'#00675e'),(1,'#99511d')])+'<text x="9" y="85" fill="#485d55" font-size="11">2.10 µm</text><text x="154" y="85" fill="#485d55" font-size="11">2.50 µm</text>')
    receipts=json.loads((BASE/'solar_export'/'stress_new18.json').read_text())
    old=json.loads((BASE/'solar_export'/'receipt_new18.json').read_text())
    season=2
    def step(vals):return [(10+t*7.7,74-7*v) for j,v in enumerate(vals) for t in (j,j+1)]
    solar=sketch('Summer export limits for the first of 18 homes',path(step([r[0] for r in old['flex_caps_kw'][season]]),'#00675e')+path(step([r[0] for r in receipts['revised_caps_kw'][season]]),'#99511d')+'<text x="9" y="86" fill="#485d55" font-size="11">00:00</text><text x="163" y="86" fill="#485d55" font-size="11">24:00</text>')
    sections=[(motion,'Linkwright','Can I cut this mechanism?','Change how far the wing swings. Check what happens if the holes are off by a millimetre. Find a size that works within the stated tolerance and print the parts at actual size.',[('Open the motion builder','motion_builder/index.html')]),(spec,'GeoAssay','Which minerals could give this reading?','Start with one wavelength. Add two more and watch a field of possible mixtures narrow. Then follow the lab result that decides which sample to assay next.',[('Compare measured spectra','assay_selector/mixtures.html'),('Explore the assay tree','assay_selector/policy.html')]),(solar,'FlexExport','How much solar can my street export?','Pick a home and see its hourly offer. Compare the energy it gives up with the hours when the feeder crosses a limit, including a replay with measured household profiles.',[('Explore the solar offers','solar_export/offers.html')])]
    blocks=''.join('<article>'+img+'<div><small>'+name+'</small><h2>'+question+'</h2><p>'+note+'</p><nav>'+''.join('<a href="'+url+'">'+label+'</a>' for label,url in links)+'</nav></div></article>' for img,name,question,note,links in sections)
    html='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Crest–Root · Three working experiments</title><link rel="stylesheet" href="guide/style.css"><header><strong>Crest–Root Calculus</strong></header><main><h1>What can the measurements settle?</h1><p class="intro">A moving wing, a mineral scan and a neighbourhood of solar roofs pose the same question. Which possibilities survive once all the constraints are checked together?</p>'''+blocks+'''</main><footer><a href="README.md">Release notes, reproducible runs and limits</a></footer></html>'''
    (BASE/'index.html').write_text(html)
if __name__=='__main__':draw()
