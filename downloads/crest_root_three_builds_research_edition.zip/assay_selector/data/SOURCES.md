# The measured mineral spectra

The 31 files in `usgs_v7/` ending in `.txt` are unaltered copies of 30 laboratory specimen spectra and one Beckman wavelength axis. Each of the 15 minerals has one reference specimen and a different challenge specimen. They come from Kokaly et al. (2017), *USGS Spectral Library Version 7 Data*, DOI **10.5066/F7RR1WDJ**. USGS marks the release CC0 1.0 Universal. [Original release](https://www.usgs.gov/data/usgs-spectral-library-version-7-data) · [ASCII collection](https://data.usgs.gov/datacatalog/data/USGS%3A586e8c88e4b0f5ce109fccae)

The full downloaded `ASCIIdata_splib07a.zip` is 21,812,828 bytes. Its MD5 agrees with the ScienceBase file record, `bfe74068d85811e52e5e07d017720a17`. The local SHA-256 is `d232645740869a82aafcad5839448c50b1dc72965ce042d1374f29b7a798a91c`. The [manifest](usgs_v7/manifest.json) gives each role, original member path and per-file SHA-256. The selection includes variations within a mineral label, such as different kaolinite specimens and sodium- and potassium-bearing jarosite specimens.

## From instrument readings to common bands

The code linearly interpolates onto a 10 nm grid between 0.4 and 2.5 µm. A band is retained only when both surrounding instrument channels are valid in every spectrum. This leaves 204 bands. Values are rounded to six decimals for the shared scientific and browser tables. Input reflectance is dimensionless. See `geoassay/library.py` for the exact operation.

## Compare two libraries on real specimens

In the included spectral-angle baseline each mineral has one candidate reference. For each of the 15 challenge specimens, rank candidates by the cosine between the entire reference and challenge spectrum. The synthetic proxies identify **4/15** as the top match. The single measured reference per class identifies **5/15** on the same challenge set. This is a descriptive cross-specimen test in one instrument collection. It does not measure assay-planning performance. A single reference can miss substantial within-species variation. [All predictions, including misses](measured_benchmark.json)

## Intersect exact mixture constraints

For each pair, the allowed fraction of the first mineral lies between 0 and 1. If A and B are their reflectances, y the observation and e the per-band tolerance, require `-e ≤ (A-B)f + B-y ≤ e` at **every** selected wavelength. Each nonconstant band restricts f to a closed interval. Two conflicting bounds, or a single constant band outside tolerance, suffice to exclude a pair. All 105 pairs are enumerated. Exactness refers to rational arithmetic on the six-decimal table within this two-reference linear areal-mixture model.

Try the constructed 60% kaolinite and 40% dickite sample with an absolute error budget of 0.005. At 2.20 µm there are **50** possible pairs. At 1.40, 2.17 and 2.20 µm only the planted pair survives. The latter wavelengths illustrate the mechanism on this example; they were not selected by a prospective field trial. With all 204 bands the admissible kaolinite interval is **220775/376292 to 230775/376292** (about **58.67%–61.33%**). The true 60% lies inside it.

From `assay_selector/`, run:

```shell
python measured_benchmark.py
python -m geoassay.pair_bounds data/reference_challenges.csv --column constructed_60_40 --error 0.005 --bands 1.40,2.17,2.20 --all
```

Replace `constructed_60_40` with a mineral column such as `kaolinite` to test a separate laboratory specimen. No physical mixture or field-site success is implied by the constructed example. The measured BIC-site planner, where used, has separate likelihood, shortlist and site-prior assumptions.
