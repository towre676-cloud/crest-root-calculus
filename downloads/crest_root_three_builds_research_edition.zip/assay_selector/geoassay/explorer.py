"""Render a completed finite assay policy into a network-free report."""
import json
from pathlib import Path


def write_html(report, destination):
    template = Path(__file__).with_name("policy_template.html").read_text(encoding="utf-8")
    # HTML parsers end script elements at a literal </script>, even in JSON.
    data = json.dumps(report, ensure_ascii=True, allow_nan=False, separators=(",",":")).replace("<","\\u003c")
    Path(destination).write_text(template.replace("POLICY_JSON_HERE", data), encoding="utf-8")
