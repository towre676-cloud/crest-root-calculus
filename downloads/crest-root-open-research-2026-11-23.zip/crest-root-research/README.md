# Crest-Root open research, 23 November 2026

Read [the research results](research/README.md) or the [57-item register](research/backlog-2026-11-23.md). The packet includes the quartic equations, executable certificates, exact receipts, the historical atlas solver, the new degree classifiers and the cubic tower study.

After extracting, open a terminal in this folder. Windows commands:

```sh
py -m pip install numpy "sympy>=1.12,<2"
py research/replay.py
```

On macOS or Linux, substitute `python3` for `py`. The replay launches the nine research verifications. No downloads are needed once NumPy and SymPy are installed.
