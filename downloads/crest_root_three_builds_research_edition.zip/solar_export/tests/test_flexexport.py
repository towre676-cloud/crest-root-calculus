import sys, os, warnings, numpy as np
warnings.filterwarnings("ignore"); sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from flexexport import build_feeder, year, Grid
from flexexport.engine import _lp

def test_feeder_counts():
    net, homes = build_feeder(n_existing=20, n_new=6)
    assert sum(h["new"] for h in homes) == 6 and len(homes) == 26

def test_profiles_physical():
    p = year(4)
    assert p["pv_unit"].min() >= 0 and p["pv_unit"][:, 0].max() == 0 and p["pv_unit"][150:200, 12].max() > 0.6
    assert p["load_kw"].min() > 0

def test_lp_maxmin_then_sum():
    Sv = np.array([[1.0, 2.0]]); c = _lp([(Sv, np.array([3.0]))], np.array([5.0, 5.0]))
    assert abs(c[0] - 1) < 1e-4 and abs(c[1] - 1) < 1e-4          # max-min: both 1, sum then fixed by the constraint
    c = _lp([(np.array([[1.0, 0.0]]), np.array([1.0]))], np.array([5.0, 5.0]))
    assert abs(c[0] - 1) < 1e-4 and abs(c[1] - 5) < 1e-4          # unconstrained home goes to its rating

def test_curtailment_reduces_voltage():
    net, homes = build_feeder(n_existing=30, n_new=24); g = Grid(net, homes, year(len(homes)))
    d = 192
    v_free = g.run(d, 12, None)[0]; v_cap = g.run(d, 12, np.zeros(24))[0]
    assert v_cap < v_free and v_free > 1.06
