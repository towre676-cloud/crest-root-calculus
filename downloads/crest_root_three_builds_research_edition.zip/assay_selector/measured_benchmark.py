"""A reproducible reference-library comparison and exact two-mineral example."""
import argparse
import csv
from fractions import Fraction
import hashlib
import json
from pathlib import Path

import numpy as np

from geoassay.library import builtin_proxy, measured_specimens
from geoassay.pair_bounds import all_pairs

ROOT = Path(__file__).resolve().parent


def neighbors(lib, observed):
    # Spectral-angle ordering, invariant to a positive multiplicative gain.
    directions = lib.R / np.linalg.norm(lib.R, axis=0)
    cosines = directions.T @ (observed / np.linalg.norm(observed))
    order = np.argsort(-cosines, kind="stable")
    return [lib.names[i] for i in order]


def benchmark():
    ref, test = measured_specimens()
    proxy = builtin_proxy(ref.wl).subset(ref.names)
    kaol, dick = (ref.names.index(k) for k in ("kaolinite", "dickite"))
    example = (0.6 * ref.R[:, kaol] + 0.4 * ref.R[:, dick]).round(6)
    experiments = []
    for subset in (["2.20"], ["1.40", "2.17", "2.20"], None):
        indices = range(len(ref.wl)) if subset is None else [np.argmin(abs(ref.wl-float(b))) for b in subset]
        obs = {Fraction(f"{ref.wl[i]:.3f}"): Fraction(f"{example[i]:.6f}") for i in indices}
        pairs = all_pairs(ref, obs, Fraction("0.005"))
        fits = [p for p in pairs if p["possible"]]
        experiments.append({"band_count": len(obs), "pairs_possible": len(fits), "pairs_tested": len(pairs),
                            "kaolinite_dickite": next(p for p in fits if p["first"]=="kaolinite" and p["second"]=="dickite")})
    predictions = []
    for i, name in enumerate(ref.names):
        baseline = neighbors(proxy, test.R[:, i])
        measured = neighbors(ref, test.R[:, i])
        predictions.append({"known_label": name, "proxy_top": baseline[0], "measured_top": measured[0],
                            "proxy_rank": baseline.index(name)+1, "measured_rank": measured.index(name)+1})
    return {"method": "highest cosine similarity; one reference per class; one disjoint lab specimen per class",
            "wavelengths": len(ref.wl), "specimens": len(predictions),
            "proxy_correct": sum(x["proxy_rank"] == 1 for x in predictions),
            "measured_correct": sum(x["measured_rank"] == 1 for x in predictions),
            "predictions": predictions, "synthetic_mixture": experiments}, ref, test, example


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--write", action="store_true", help="Regenerate the accompanying receipt and scans")
    args = ap.parse_args()
    rec, ref, test, example = benchmark()
    if args.write:
        out = ROOT / "data"
        with (out/"reference_challenges.csv").open("w", newline="") as stream:
            w = csv.writer(stream)
            w.writerow(["wavelength_um", "constructed_60_40", *test.names])
            for wl, value, row in zip(ref.wl, example, test.R):
                w.writerow([f"{wl:.3f}", f"{value:.6f}", *[f"{x:.6f}" for x in row]])
        (out/"measured_benchmark.json").write_text(json.dumps(rec,indent=2)+"\n")
    print(json.dumps(rec, indent=2))


if __name__ == "__main__":
    main()
