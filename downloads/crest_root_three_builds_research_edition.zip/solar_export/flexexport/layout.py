"""The original benchmark's household locations and deterministic PV nameplates."""

from __future__ import annotations
import numpy as np


def home_layout(n_existing=36, existing_pv_share=0.45, n_new=12, seed=0):
    if not 0 <= n_new <= 30 or not 0 <= n_existing <= 60 - n_new:
        raise ValueError(
            "This feeder supports at most 30 candidate homes and 60 total homes."
        )
    if not 0 <= existing_pv_share <= 1:
        raise ValueError("Existing PV share must be between zero and one.")
    rng = np.random.default_rng(seed)
    slots = [(k, j) for k in range(10) for j in range(3) for _ in range(2)]
    candidate = list(range(59, -1, -2))[:n_new]
    existing = [i for i in range(60) if i not in candidate][:n_existing]
    homes = []
    for i in existing:
        k, j = slots[i]
        pv = (
            float(rng.choice([4.0, 5.0, 6.0]))
            if rng.random() < existing_pv_share
            else 0.0
        )
        homes.append(
            dict(
                main=k + 1,
                lateral=j + 1,
                new=False,
                pv_kw=pv,
                where=f"M{k + 1} lateral node {j + 1}",
            )
        )
    for n, i in enumerate(candidate):
        k, j = slots[i]
        homes.append(
            dict(
                main=k + 1,
                lateral=j + 1,
                new=True,
                pv_kw=float(rng.choice([7.0, 8.0, 10.0])),
                where=f"M{k + 1} lateral node {j + 1}",
                name=f"New-{n + 1:02d}",
            )
        )
    return homes
