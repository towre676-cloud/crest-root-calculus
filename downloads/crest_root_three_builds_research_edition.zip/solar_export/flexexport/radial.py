"""Balanced AC power flow on the supplied radial network, vectorized over operating hours.

The explicit transformer core node models the midpoint shunt of the T equivalent.
Phasors on both sides are in their local reference frames; only magnitudes are compared.
Power base is 250 kVA; LV voltage base is 0.4 kV (line to line).
"""

from dataclasses import dataclass
import numpy as np


@dataclass
class Flow:
    voltage: np.ndarray  # [hour, LV bus], from LV0 onwards
    loading: np.ndarray  # [hour, component], transformer then cables
    residual: float  # max nodal complex power mismatch, pu
    iterations: int

    def take(self, rows):
        return Flow(
            self.voltage[rows], self.loading[rows], self.residual, self.iterations
        )


class Feeder:
    def __init__(self, homes):
        self.homes = homes
        self.parent = [0]
        self.impedance = [0j]
        self.end_shunt = [0j]
        self.bus_names = ["MV"]
        self.branch_names = ["slack"]
        self.ampacity = [np.inf]
        self.home_bus = []
        self.load_base_kw = 250.0
        half_z = (0.0144 + 1j * np.sqrt(0.06**2 - 0.0144**2)) / 2
        self._branch(0, "core", "transformer high", half_z, 0j, 1.0)
        self._branch(1, "LV0", "transformer low", half_z, 0j, 1.0)
        prev_main = 2
        location = {}
        for k in range(1, 11):
            main = self._cable(
                prev_main, f"M{k}", f"main{k}", 0.045, (0.208, 0.08, 261.0, 0.27)
            )
            parent = main
            for j in range(1, 4):
                parent = self._cable(
                    parent,
                    f"L{k}.{j}",
                    f"lat{k}.{j}",
                    0.030,
                    (0.642, 0.083, 210.0, 0.142),
                )
                location[k, j] = parent
            prev_main = main
        self.home_bus = np.array(
            [location[h["main"], h["lateral"]] for h in homes], dtype=int
        )
        self.parent = np.asarray(self.parent)
        self.impedance = np.array(self.impedance)
        self.end_shunt = np.array(self.end_shunt)
        self.ampacity = np.array(self.ampacity)
        self.shunt = self.end_shunt.copy()
        np.add.at(self.shunt, self.parent[1:], self.end_shunt[1:])
        self.shunt[1] += 0.8 / self.load_base_kw
        self.components = ["transformer"] + self.branch_names[3:]
        self.lv_names = self.bus_names[2:]

    def _branch(self, parent, bus, name, z, shunt, ampacity):
        self.parent.append(parent)
        self.impedance.append(z)
        self.end_shunt.append(shunt)
        self.ampacity.append(ampacity)
        self.branch_names.append(name)
        self.bus_names.append(bus)
        return len(self.parent) - 1

    def _cable(self, parent, bus, name, km, data):
        r, x, c_nf, i_ka = data
        z0 = 0.4**2 / 0.25
        i0 = 0.25 / (np.sqrt(3) * 0.4)
        y_half = 1j * np.pi * 50 * c_nf * 1e-9 * km * z0
        return self._branch(
            parent, bus, name, km * (r + 1j * x) / z0, y_half, i_ka / i0
        )

    def solve(self, demand_kw, demand_kvar, source=1.02):
        """Positive power is consumed. Reject nonconvergence rather than classifying the hour."""
        demand = np.asarray(demand_kw) + 1j * np.asarray(demand_kvar)
        if demand.ndim != 2 or demand.shape[1] != len(self.homes):
            raise ValueError("Expected an [hour, home] array of powers.")
        if not np.isfinite(demand).all() or not np.isfinite(source) or source <= 0:
            raise ValueError("Powers must be finite and source voltage positive.")
        # Internal orientation [bus, hour] keeps all sweeps contiguous along time.
        s = np.zeros((len(self.parent), len(demand)), complex)
        np.add.at(s, self.home_bus, demand.T / self.load_base_kw)
        v = np.full_like(s, source)
        for it in range(1, 101):
            current = np.conj(s / v) + self.shunt[:, None] * v
            for i in range(len(v) - 1, 0, -1):
                current[self.parent[i]] += current[i]
            vn = v.copy()
            for i in range(1, len(v)):
                vn[i] = vn[self.parent[i]] - self.impedance[i] * current[i]
            err = np.max(np.abs(vn - v))
            v = vn
            if err < 2e-11:
                break
        else:
            raise ArithmeticError("Radial AC load flow did not converge.")
        # Recompute Kirchhoff residual from final voltages, independently of accumulated currents.
        series = (v[self.parent[1:]] - v[1:]) / self.impedance[1:, None]
        mismatch = np.conj(s / v) + self.shunt[:, None] * v
        mismatch[1:] -= series
        for i in range(1, len(v)):
            mismatch[self.parent[i]] += series[i - 1]
        residual = float(np.max(np.abs(v[1:] * np.conj(mismatch[1:]))))
        if residual > 1e-8:
            raise ArithmeticError(
                f"Power-balance residual {residual:g} pu exceeds tolerance."
            )
        sending = series + self.end_shunt[1:, None] * v[self.parent[1:]]
        receiving = -series + self.end_shunt[1:, None] * v[1:]
        currents = (
            100 * np.maximum(abs(sending), abs(receiving)) / self.ampacity[1:, None]
        )
        loading = np.vstack([np.maximum(currents[0], currents[1]), currents[2:]])
        return Flow(abs(v[2:]).T, loading.T, residual, it)
