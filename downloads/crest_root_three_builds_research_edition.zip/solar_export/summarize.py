import json, glob
rows = []
for f in sorted(glob.glob("receipt_new*.json"), key=lambda x: int(x[11:-5])):
    r = json.load(open(f)); ev = r["evaluation"]
    v = lambda s: sum(ev[t][s]["violation_hours"] for t in ev)
    pv = sum(h["pv_kwh_year"] for h in r["per_home"]); F = sum(h["flexible_gives_up_kwh"] for h in r["per_home"]); S = sum(h["static_gives_up_kwh"] for h in r["per_home"])
    rows.append({"n_new": r["n_new"], "unlimited_violation_hours_unseen": v("unlimited_export"), "static_violation_hours_unseen": v("static_cap"),
                 "flex_violation_hours_unseen": v("flexible_offer"), "static_cap_kw": sorted({h["static_cap_kw"] for h in r["per_home"]}),
                 "pv_kwh": pv, "flex_gives_up_kwh": F, "static_gives_up_kwh": S, "flex_pct": round(100*F/pv, 2), "static_pct": round(100*S/pv, 2),
                 "worst_home_flex_pct": max(h["flexible_gives_up_pct_of_pv"] for h in r["per_home"]), "worst_home_static_pct": max(h["static_gives_up_pct_of_pv"] for h in r["per_home"]),
                 "median_limited_cells": sorted(h["limited_hours"] for h in r["per_home"])[len(r["per_home"])//2],
                 "worst_v_unseen_flex": max(ev[t]["flexible_offer"]["worst_v_pu"] for t in ev), "worst_v_unseen_unlimited": max(ev[t]["unlimited_export"]["worst_v_pu"] for t in ev)})
json.dump(rows, open("summary.json", "w"), indent=1); [print(x) for x in rows]
