"""Site interpretation model and value-of-information assay selection.

Site hypotheses are alteration-system models; each assigns, to every sample position (distal ->
proximal zone index), a probability for each mineral being present.  A sample's assemblage
posterior from the scan is converted into a likelihood over site models.  A lab assay (XRD/QEMSCAN)
is modelled as revealing the true assemblage of that sample without lab error.

select() checks all fixed batches when their number fits its search limit; otherwise it uses greedy
selection. Its default objective includes every retained lab outcome.
"""
from __future__ import annotations
import itertools, functools, numpy as np

ZONES = ("distal", "intermediate", "proximal")
SITE_MODELS = {
  "high-sulfidation epithermal": {
     "distal": {"montmorillonite":.5,"kaolinite":.5,"chlorite":.2,"quartz":.6},
     "intermediate": {"kaolinite":.7,"dickite":.4,"alunite":.4,"quartz":.6},
     "proximal": {"alunite":.8,"pyrophyllite":.5,"dickite":.5,"quartz":.8}},
  "porphyry phyllic-propylitic": {
     "distal": {"chlorite":.7,"epidote":.6,"calcite":.5,"quartz":.3},
     "intermediate": {"muscovite":.7,"chlorite":.4,"quartz":.5},
     "proximal": {"muscovite":.85,"quartz":.7,"pyrophyllite":.1}},
  "supergene oxidation cap": {
     "distal": {"goethite":.6,"kaolinite":.5,"montmorillonite":.3,"quartz":.5},
     "intermediate": {"jarosite":.6,"goethite":.5,"kaolinite":.5,"quartz":.5},
     "proximal": {"jarosite":.7,"hematite":.6,"alunite":.3,"quartz":.6}},
  "intermediate argillic (low-sulfidation)": {
     "distal": {"chlorite":.5,"montmorillonite":.5,"calcite":.3,"quartz":.4},
     "intermediate": {"montmorillonite":.6,"kaolinite":.5,"muscovite":.4,"quartz":.5},
     "proximal": {"muscovite":.6,"kaolinite":.5,"montmorillonite":.3,"quartz":.7}},
  "carbonate-hosted / skarn margin": {
     "distal": {"calcite":.8,"dolomite":.5,"quartz":.2},
     "intermediate": {"calcite":.5,"epidote":.6,"chlorite":.5},
     "proximal": {"epidote":.7,"chlorite":.5,"calcite":.3,"gypsum":.2}},
}
EPS = 0.02   # background probability of any unlisted mineral

def _zone_probs(hyp, zone):
    prim, sec, w = hyp
    p1 = SITE_MODELS[prim][zone]
    if w == 0 or sec is None: return p1
    p2 = SITE_MODELS[sec][zone]
    return {m: (1-w)*p1.get(m, EPS) + w*p2.get(m, EPS) for m in set(p1) | set(p2)}

def assemblage_prob(hyp, zone, minerals, all_minerals):
    if isinstance(hyp, str): hyp = (hyp, None, 0.0)
    return _ap(hyp, zone, tuple(sorted(minerals)), tuple(all_minerals))

@functools.lru_cache(maxsize=400000)
def _ap(hyp, zone, minerals, all_minerals):
    pz = _zone_probs(hyp, zone)
    S = set(minerals); lp = 0.0
    for m in all_minerals:
        q = pz.get(m, EPS)
        lp += np.log(q if m in S else 1-q)
    return lp

class Site:
    """Site interpretation = which primary alteration system produced the samples.

    Internally each hypothesis is (primary, overprinting system, blend weight w); a real site is
    rarely one textbook system.  Posteriors and entropies are reported for the primary system,
    marginalised over overprint and w.  overprint_weights=(0,) recovers the pure-system model.
    """
    def __init__(self, samples, all_minerals, prior=None, overprint_weights=(0.0, 0.2, 0.4)):
        self.samples, self.allm = list(samples), list(all_minerals)
        if not self.allm or len(set(self.allm)) != len(self.allm):
            raise ValueError("Provide distinct mineral names in the reference.")
        overprint_weights = tuple(overprint_weights)
        if (not overprint_weights or len(set(overprint_weights)) != len(overprint_weights)
                or not all(0 <= w <= 1 for w in overprint_weights)):
            raise ValueError("Provide distinct overprint weights between zero and one.")
        self.models = list(SITE_MODELS)
        H = []
        for p in self.models:
            for w in overprint_weights:
                if w == 0: H.append((p, None, 0.0))
                else: H += [(p, q, w) for q in self.models if q != p]
        self.hyps = H
        self.prim = np.array([self.models.index(h[0]) for h in H])
        base = np.full(len(self.models), 1/len(self.models)) if prior is None else np.asarray(prior, float)
        if (base.shape != (len(self.models),) or not np.all(np.isfinite(base))
                or np.any(base < 0) or base.sum() <= 0):
            raise ValueError("Primary prior needs one nonnegative weight per site model and positive total mass.")
        base = base / base.sum()
        # prior: primary prior split evenly over its (overprint, w) variants
        cnt = np.bincount(self.prim, minlength=len(self.models))
        self.hprior = base[self.prim] / cnt[self.prim]
        self.tab = []
        m = len(self.allm)
        for s in self.samples:
            if s["zone"] not in ZONES or not s["hyps"]:
                raise ValueError("Each sample needs a known zone and at least one scan assemblage.")
            A = [h["minerals"] for h in s["hyps"]]
            ps = np.array([h["p"] for h in s["hyps"]])
            k = np.array([len(a) for a in A])
            if not np.all(np.isfinite(ps)) or np.any(ps < 0) or not np.any(ps > 0):
                raise ValueError("Each scan needs finite nonnegative weights and positive total weight.")
            baseline = k*np.log(.35) + (m-k)*np.log(.65)
            log_prior = np.array([h.get("log_scan_prior", default) for h, default in zip(s["hyps"], baseline)])
            with np.errstate(divide="ignore"):
                lik = np.log(ps) - log_prior  # P(scan | assemblage) up to one scan-wide constant
            lpa = np.array([[assemblage_prob(h, s["zone"], a, self.allm) for a in A] for h in H])
            self.tab.append((A, lik, lpa))

    def _hpost(self, assayed):
        with np.errstate(divide="ignore"):
            lp = np.log(self.hprior).copy()
        for i, (A, lik, lpa) in enumerate(self.tab):
            if i in assayed:
                lp += np.array([assemblage_prob(h, self.samples[i]["zone"], assayed[i], self.allm) for h in self.hyps])
            else:
                lp += np.logaddexp.reduce(lpa + lik[None, :], axis=1)
        p = np.exp(lp-lp.max()); return p/p.sum()

    def posterior(self, assayed=None):
        """Posterior over primary systems. assayed: {sample_index: lab assemblage tuple}"""
        return np.bincount(self.prim, weights=self._hpost(assayed or {}), minlength=len(self.models))

    def outcome_dist(self, i, assayed):
        A, lik, lpa = self.tab[i]
        hp = self._hpost(assayed)
        base = np.log(hp+1e-300) - np.logaddexp.reduce(lpa + lik[None, :], axis=1)
        joint = base[:, None] + lpa + lik[None, :]
        Z = np.logaddexp.reduce(joint.ravel())
        pa = np.exp(np.logaddexp.reduce(joint, axis=0) - Z)
        return A, pa

    def expected_entropy(self, chosen, assayed=None, max_outcomes=None):
        """Exact on retained scan support by default; an explicit cap gives the legacy approximation."""
        if max_outcomes is None:
            from .policy import Planner
            planner = Planner.from_site(self, assayed)
            return planner.fixed_value(planner.prior, chosen)
        if not isinstance(max_outcomes, (int, np.integer)) or max_outcomes < 1:
            raise ValueError("max_outcomes must be positive or None.")
        assayed = dict(assayed or {})
        if not chosen:
            p = self.posterior(assayed); return float(-(p*np.log(p+1e-300)).sum())
        i, rest = chosen[0], chosen[1:]
        A, pa = self.outcome_dist(i, assayed)
        order = np.argsort(-pa)[:max_outcomes]; w = pa[order]/pa[order].sum()
        return sum(wj*self.expected_entropy(rest, {**assayed, i: A[j]}, max_outcomes) for j, wj in zip(order, w))

def select(site, budget, assayed=None, exhaustive_limit=2000):
    """Return (chosen indices, expected posterior entropy, current entropy). Exhaustive if feasible, else greedy."""
    n = len(site.samples); cand = [i for i in range(n) if not assayed or i not in assayed]
    if not isinstance(budget, (int, np.integer)) or not 0 <= budget <= len(cand):
        raise ValueError(f"Budget must be an integer from zero through {len(cand)} available samples.")
    from math import comb
    from .policy import Planner
    planner = Planner.from_site(site, assayed)
    def value(chosen):
        return planner.fixed_value(planner.prior, chosen)
    H0 = value(())
    if comb(len(cand), budget) <= exhaustive_limit:
        best = min(itertools.combinations(cand, budget), key=value)
        return list(best), value(best), H0
    chosen = []
    for _ in range(budget):
        j = min((c for c in cand if c not in chosen), key=lambda c: value(chosen + [c]))
        chosen.append(j)
    return chosen, value(chosen), H0
