'use strict';
const el=id=>document.getElementById(id);
const names={metered:'Metered replay · 2012–13 (18 homes)',nominal:'Nominal conditions',bright_low_demand:'Brighter sun, lighter demand',dim_high_demand:'Dimmer sun, heavier demand'};
Object.entries(names).forEach(([k,n])=>el('condition').add(new Option(n,k)));
el('condition').value='metered';
function chooseHomes(){
  const data=window.offers[el('homes').value], previous=el('house').selectedIndex;
  const measuredOption=el('condition').querySelector('[value="metered"]');
  measuredOption.disabled=!data.metered;
  if(!data.metered && el('condition').value==='metered')el('condition').value='bright_low_demand';
  el('house').options.length=0;
  data.people.forEach((p,i)=>el('house').add(new Option(p.home,i)));
  el('house').selectedIndex=Math.max(0,Math.min(data.people.length-1,previous));
  draw();
}
function draw(){
  const x=window.offers[el('homes').value],season=el('season').selectedIndex;
  const i=el('house').selectedIndex, person=x.people[i];
  el('where').textContent=person.home+' · '+person.where+' · '+person.pv_kw+' kW installed solar';
  const steps=values=>values.flatMap((v,j)=>[[j,v],[j+1,v]]);
  const flex=x.original[season].map(row=>row[i]), revised=x.revised[season].map(row=>row[i]);
  renderScientificPlot(el('chart'),{lines:[
    {points:steps(flex),color:'#00675e',width:3.6},
    {points:steps(revised),color:'#99511d',width:2,dash:'7 3'},
    {points:[[0,person.static_cap_kw],[24,person.static_cap_kw]],color:'#182c2b',dash:'2 4'}],
    xMin:0,xMax:24,yMin:0,yMax:10.5,xTicks:[0,4,8,12,16,20,24],yTicks:[0,2,4,6,8,10],
    yLabel:'Maximum net export (kW)',xLabel:'Local hour',description:'Seasonal and fixed export limits for '+person.home});
  const measured=el('condition').value==='metered';
  el('year').disabled=measured;
  const rows=measured?x.metered:x.eval[el('year').value][el('condition').value];
  const tbody=el('results');tbody.textContent='';
  for(const [key,title] of Object.entries({unlimited:'Uncapped',fixed:'Original fixed',supplied:'Original flexible',revised_fixed:'Revised fixed',revised:'Revised flexible'})){
    const r=rows[key], tr=tbody.insertRow(), th=document.createElement('th');th.scope='row';th.textContent=title;tr.append(th);
    for(const value of [r.export_worsened_hours,r.absolute_violation_hours,r.curtailed_pct.toFixed(2)+'%'])tr.insertCell().textContent=value;
  }
  el('calibration').hidden=!x.calibration;
  const cs=el('calYears');cs.textContent='';
  if(x.calibration){
    for(const [key,label] of [['2011-07-01','2011–12 · 173 complete days'],['2012-07-01','2012–13 · 365 days']]){
      const e=x.calibration[key], tr=cs.insertRow(),head=document.createElement('th');head.scope='row';head.textContent=label;tr.append(head);
      tr.insertCell().textContent=e.revised.absolute_violation_hours+' / '+e.revised_fixed.absolute_violation_hours+' h';
      tr.insertCell().textContent=Math.round(e.revised_fixed.curtailed_kwh-e.revised.curtailed_kwh).toLocaleString('en-US')+' kWh';
    }
    el('calWitness').textContent='On the full final year the extra export came with seven half-hours over a modeled limit. The fixed offer stayed within the modeled limits on every replayed half-hour in both evaluation periods.';
  }
  const w=rows.supplied.export_counterexample;
  if(measured){
    el('story').textContent='These are modeled outcomes under real meter readings. The uncapped offer, original fixed cap and revised fixed cap are shown alongside both flexible offers because tighter limits trade exported energy for headroom.';
    return;
  }
  el('story').textContent=w?'One original-offer counterexample occurred on simulation day '+(w.day_index+1)+' at '+String(w.hour).padStart(2,'0')+':00, at '+w.component+'. The recorded '+w.metric.split('_').join(' ')+' value was '+w.value.toFixed(4)+(w.metric.includes('voltage')?' pu':'%')+'.':'The original flexible offer produced zero export-worsened violations in this simulated year and scenario.';
}
for(const id of ['house','season','condition','year'])el(id).addEventListener('change',draw);
el('homes').addEventListener('change',chooseHomes);
chooseHomes();redrawOnWidthChange(document.querySelector('main'),draw);
