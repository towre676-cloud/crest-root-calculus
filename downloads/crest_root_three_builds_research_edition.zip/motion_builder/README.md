# Linkwright

Open **index.html** in a desktop or phone browser. Work offline, using the controls on the page. **Flap a wing** starts with an angle and a timing ratio. **Trace a path** fits a moving point to a drawing. The design supplies moving links, fixed pivots, assembly instructions and a life-size SVG with a 50 mm print check.

## Try a build that needs a different size

1. Select **Flap a wing**. Set the swing to **60°**, the down/up ratio to **1.80×** and the rocker to **70 mm**. Leave the material at cardboard. Press **Design the mechanism**.
2. Under **Before you cut**, set the error in each pin spacing to **±5 mm**. The ideal drawing turns, but some allowed combinations of cut lengths fold or fail to close.
3. Press **Use the smallest fitting scale**. The site checks every whole-percent choice from 50% through 200%. The suggested size is **159%**. Inspect the new pin lengths and compare them with the 100% drawing.
4. Switch to **craft sticks**. At this hole-placement error, the length of the sticks rules out every available scale for this example. Try a smaller error if your tools can achieve it.
5. Choose **Save parts SVG**, open the file and print at **actual size**. Use poster/tiling settings if the sheet exceeds one page. Measure the 50 mm bar on the paper before making any holes. The design JSON also records the assumed tolerance, limiting geometry, feasible scales and projected clearance. Copy buttons remain available in restricted viewers.

The tolerance is an error in the **distance between two pin centres**. If each hole centre can miss its mark by at most 0.5 mm in the plane, two errors pointing in opposite directions can change a pin spacing by up to 1 mm.

The single-page [wing cut-and-build sheet](wing-kit.pdf), [vector parts](wing-parts.svg) and [design record](wing-design.json) are the 159% cardboard example above. The SVG stores its width and height in millimetres. Confirm the real print scale before using it.

## Full-turn geometry

Let the ground spacing, crank, coupler and rocker lengths be \(g,a,b,c\), in millimetres. As the crank turns, the distance from the free crank pin to the fixed rocker pin takes every value from \(|g-a|\) to \(g+a\). The other two links can form a strict triangle at every angle precisely when both margins are positive.

\[
m_{\rm fold}=|g-a|-|b-c|,\qquad m_{\rm reach}=b+c-g-a.
\]

Give each of the four positive lengths an independent error interval of radius \(t\). The worst margins over **all allowed lengths and all angles** are

\[
M_{\rm fold}=\max(0,|g-a|-2t)-(|b-c|+2t),\qquad
M_{\rm reach}=b+c-g-a-4t.
\]

The independent extrema can be reached together. The JSON includes a length tuple and crank angle that attain the smaller margin. For a passing nominal design the critical tolerance is the least of the two nominal margins divided by four and the four nominal lengths. Strictly smaller errors retain positive lengths and a nonsingular full turn. The formulas are analytic. The page evaluates them in double precision and labels values inside a length-scaled guard band **at limit**.

For the stock search, each candidate scale must also keep the moving cut pieces within the stated stock length and leave distinct holes on each two-pin link, including the allowed spacing error. A coupler plate with an off-axis tracing point requires sheet stock or a built-up plate. A separate board carries the fixed pivots. These stock checks measure length and overlap; a material's actual strength depends on fabrication.

**Why scanning misses real failures.** A 100 mm ground, 30 mm crank, 75 mm coupler and 54.99994 mm rocker pass all 720 sampled poses when the base makes a 0.25° angle with the horizontal. At crank angle 180.25° the two free links fall short by 0.00006 mm. This deliberately tiny example tests the logic. The 60° classroom build above demonstrates a millimetre-scale manufacturing decision.

## The algebraic curve of a four-bar linkage

The panel **Two ways to pin the same drawing** uses the rounded pin spacings from the cut list. Express those distances as integers in tenths of a millimetre. Rotate the ground to point along the positive horizontal axis; let \(t=\tan(\theta/2)\) and \(u=\tan(\phi/2)\) encode crank and rocker directions from that axis. The squared distance between their free ends must equal \(b^2\). Clearing denominators gives an explicit curve

\[
 (C_{02}+C_{22}t^2)u^2+C_{11}tu+C_{00}+C_{20}t^2=0.
\]

Its five integer coefficients are

\[
\begin{aligned}
 C_{00}&=(g+c-a)^2-b^2, & C_{20}&=(g+c+a)^2-b^2,\\
 C_{02}&=(g-c-a)^2-b^2, & C_{22}&=(g-c+a)^2-b^2, & C_{11}&=-8ac.
\end{aligned}
\]

For a rational angle coordinate \(t=n/d\), the panel computes the discriminant of the **homogeneous** quadratic in the rocker direction using exact integers. This includes \(d=0\), a half-turn; a rocker pointing backward is counted as a root at infinity. A positive discriminant gives two real pin positions, zero gives one repeated position, and negative gives none. If all three coefficients vanish, every rocker angle fits. At ground 100 mm, crank 30 mm and coupler 75 mm, change the rocker from 55.4 to 55.0 to 54.9 mm. At a half-turn the counts go **2 → 1 → 0**. The example is in the geometry test receipt.

Over varying crank directions the discriminant is an even quartic \(D_0+D_2 t^2+D_4t^4\). Completing the square gives a double cover \(Y^2=D_0+D_2t^2+D_4t^4\) on the usual affine chart. If \(D_0D_4\ne0\) and \(D_2^2\ne4D_0D_4\), this quartic has four distinct complex roots and the smooth completion has genus one. The JSON includes all coefficients and this squarefreeness check. This is a direct algebraic configuration curve for the mechanism; the plane-quartic degree-three quotient solver in the Crest–Root monograph addresses a different map problem.

For the smooth even quartic write \(A=D_0, B=D_2, C=D_4\). The panel exports the exact reduced rational invariant of its Jacobian,

\[
j=\frac{16(B^2+12AC)^3}{AC(B^2-4AC)^2}.
\]

This number describes the geometric isomorphism class of the associated elliptic curve. Different builds or rational twists can share it. A singular quartic has no elliptic invariant here. The panel also counts points modulo up to three good odd primes. After removing common content from the closure equation, it counts square roots of the quartic above each finite input plus roots of the leading coefficient at infinity. The tests compare these totals with direct enumeration of the original closure equation on both projective angle lines, verify invariance under uniform length scaling, and compare a four-rational-root example with its independent Legendre invariant.

## Crank and rocker clearance

The two nonadjacent moving strips are rounded capsules of the material width shown on the parts sheet. At a given pose, their signed gap is the distance between their two centre segments minus the strip width. A negative gap witnesses overlap if both pieces occupy one layer. A positive lower bound over the full turn means the **nominal planar outlines** stay apart at every angle.

Let \(\mu\) be the coupler–rocker transmission angle. Its minimum sine over a revolution occurs at an endpoint of the crank-tip distance interval. Differentiating the fixed coupler-length constraint bounds the rocker-pin speed per radian by \(a/\min\sin\mu\). Any point on a strip moves no faster than its fastest endpoint. The signed gap therefore changes at most \(a(1+1/\min\sin\mu)\) millimetres per radian. On a subinterval of half-width \(h\), a midpoint gap \(z\) gives the lower bound \(z-h\,a(1+1/\min\sin\mu)\). Subdivision tightens this bound and keeps an actual close-approach pose. A depth cap limits runtime; the page shows the achieved bracket and allows an unresolved outcome. Numerical padding is included. This is an analytic envelope evaluated numerically, without a directed-rounding interval library.

The layout drawing shows the nominal top view. Keep the base, coupler and wing on their indicated levels and check real spacers, fasteners, material flex, axial play and friction on the assembled mechanism. The closure tolerance box applies to pin-centre closure only. The clearance check uses the nominal lengths and one assembly branch.

## Trace quality and reproducibility

The fitter still uses differential evolution and local polishing. The search now uses a fixed seed and keeps the polished dimensions within its search bounds. The displayed error is a separate geometric measurement. It averages distances in both directions between the target and fitted closed polylines, using 192 equal-arclength samples on each and a 720-pose fitted curve. The percentage uses the width of the sampled target. The largest sampled miss is also reported. The original objective included a transmission penalty and divided by a radius-like size. Its historical “7.9%” and this geometric percentage measure different quantities. Shape fit does not establish the order or timing along a self-intersecting path.

## Repeat the checks

Node.js runs the geometry checks without packages, including the near-miss, the printed-size example, independently sampled cut errors, and close-approach bounds compared against 8,192 independent poses per example.

```sh
node test_geometry.cjs
```

The optional browser tests require Python with Playwright and a local Chromium browser. In this directory run:

```sh
python -m pip install playwright
python -m playwright install chromium
python test_page.py
```

Pass `--chromium /path/to/chromium` to use an existing executable. The numerical and browser receipts contain the measured parameters. The electronic tests cover the software. A physical prototype is the next validation for cut accuracy, bearing play, friction and the finished wing.
