import numpy as np

from physical_benchmark import absorption, minimax, study


def test_upper_continuum_and_unknown_featureless_signal():
    w=np.arange(5,dtype=float)
    roof=np.array([2,3,4,3.5,3])
    observed=roof.copy()
    observed[1]=1.5
    np.testing.assert_allclose(absorption(w,observed),[0,.5,0,0,0])
    np.testing.assert_allclose(absorption(w,observed),absorption(w,observed*.7))
    np.testing.assert_allclose(absorption(w,np.ones(5)),np.zeros(5))


def test_minimax_envelope_includes_a_known_symmetric_residual():
    a=np.array([1.,1.]);b=np.array([0.,0.])
    r,f=minimax(a,b,np.array([.1,.7]))
    np.testing.assert_allclose([r,f],[.3,.4],atol=1e-12)


def test_real_specimen_receipt_replays():
    result=study()
    scores=result['pure_specimens']['comparison']
    assert scores['raw_measured']['correct_top1']==5
    assert scores['continuum_measured']['correct_top1']==14
    mixture=result['physical_mixtures']
    assert [m['id'] for m in mixture]==['GDS212','GDS213','GDS222','GDS240']
    assert all(m['exact_feasible_pairs_at_0.005']==0 for m in mixture)
    assert [m['true_pair_rank'] for m in mixture]==[5,1,1,6]
