"""Radial suburban LV feeder (pandapower) with existing homes and candidate PV homes."""
from __future__ import annotations
import pandapower as pp
from .layout import home_layout

def build_feeder(n_existing=36, existing_pv_share=0.45, n_new=12, seed=0, v_source=1.02):
    """Main: 10 x 45 m NAYY 4x150 from a 250 kVA 20/0.4 kV transformer; at each main node a
    lateral of 3 x 30 m NAYY 4x50 with one home per lateral node.  Existing homes fill laterals
    first; candidate new homes are placed toward the feeder end (the hard case for voltage rise)."""
    net = pp.create_empty_network(sn_mva=1.0)
    mv = pp.create_bus(net, 20.0, name="MV")
    pp.create_ext_grid(net, mv, vm_pu=v_source)
    lv0 = pp.create_bus(net, 0.4, name="LV0")
    pp.create_transformer(net, mv, lv0, std_type="0.25 MVA 20/0.4 kV")
    main, slots = [lv0], []
    for k in range(10):
        b = pp.create_bus(net, 0.4, name=f"M{k+1}")
        pp.create_line(net, main[-1], b, 0.045, "NAYY 4x150 SE", name=f"main{k+1}")
        main.append(b); prev = b
        for j in range(3):
            lb = pp.create_bus(net, 0.4, name=f"L{k+1}.{j+1}")
            pp.create_line(net, prev, lb, 0.030, "NAYY 4x50 SE", name=f"lat{k+1}.{j+1}")
            prev = lb; slots.append((k, j, lb))
    homes = home_layout(n_existing, existing_pv_share, n_new, seed)
    buses = {(k + 1, j + 1): bus for k, j, bus in slots}
    for h in homes:
        h["bus"] = buses[h["main"], h["lateral"]]
    for h in homes:
        h["load_el"] = pp.create_load(net, h["bus"], p_mw=0.0, q_mvar=0.0)
        h["pv_el"] = pp.create_sgen(net, h["bus"], p_mw=0.0)
    return net, homes
