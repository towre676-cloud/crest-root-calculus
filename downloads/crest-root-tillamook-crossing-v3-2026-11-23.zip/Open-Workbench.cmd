@echo off
start "" "%~dp0v3\workbench.html"
