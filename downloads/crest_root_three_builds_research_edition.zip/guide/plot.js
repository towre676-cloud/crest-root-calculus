'use strict';
// Direct SVG marks keep the numerical axes legible when the window changes.
function renderScientificPlot(svg, options) {
  const {lines, xMin, xMax, yMin, yMax, xTicks, yTicks, xLabel, yLabel, description}=options;
  const width=Math.max(260,svg.getBoundingClientRect().width || 640);
  const height=width<430?245:290, left=47, right=14, top=34, bottom=49;
  const chartW=width-left-right, chartH=height-top-bottom;
  const x=v=>left+(v-xMin)*chartW/(xMax-xMin), y=v=>top+(yMax-v)*chartH/(yMax-yMin);
  const ns='http://www.w3.org/2000/svg';
  svg.textContent=""; svg.setAttribute('viewBox','0 0 '+width+' '+height);
  function el(tag,attrs={},label=''){
    const node=document.createElementNS(ns,tag);
    for(const [k,v] of Object.entries(attrs))node.setAttribute(k,v);
    node.textContent=label;svg.append(node);return node;
  }
  el('title',{},description);
  function label(px,py,word,anchor='start'){el('text',{x:px,y:py,'text-anchor':anchor,'font-size':12,fill:'#374c48'},word)}
  label(3,18,yLabel);label(left+chartW/2,height-6,xLabel,'middle');
  for(const v of yTicks){el('line',{x1:left,x2:width-right,y1:y(v),y2:y(v),stroke:'#d5ded7'});label(left-7,y(v)+4,String(v),'end')}
  for(const [i,v] of xTicks.entries()){
    if(width<430 && i%2 && i!==xTicks.length-1)continue;
    label(x(v),height-27,String(v),i===xTicks.length-1?'end':i===0?'start':'middle');
  }
  el('line',{x1:left,x2:left,y1:top,y2:height-bottom,stroke:'#82988c'});
  for(const line of lines){
    let path='', prev=null;
    for(const [px,py] of line.points){
      if(!Number.isFinite(py)){prev=null;continue}
      path+=(prev===null || (line.maxGap && px-prev>line.maxGap)?' M':' L')+x(px).toFixed(2)+' '+y(py).toFixed(2);
      prev=px;
    }
    el('path',{d:path,fill:'none',stroke:line.color,'stroke-width':line.width||2.2,'stroke-dasharray':line.dash||'none','stroke-linejoin':'round'});
  }
  for(const pt of options.markers||[]) el('circle',{cx:x(pt[0]),cy:y(pt[1]),r:4,fill:'#182c2b',stroke:'#fffef9','stroke-width':1.3});
}

function redrawOnWidthChange(element, draw) {
  let width=element.clientWidth;
  new ResizeObserver(() => {
    if(element.clientWidth!==width){
      width=element.clientWidth;
      requestAnimationFrame(draw);
    }
  }).observe(element);
}
