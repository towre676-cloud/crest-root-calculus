"""Four physical USGS mixtures and a fixed continuum baseline on fifteen separate specimens."""
import argparse
import csv
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path

import numpy as np
from scipy.optimize import linprog

from geoassay.library import Library, builtin_proxy, measured_specimens, _resample_common
from geoassay.pair_bounds import all_pairs


ROOT = Path(__file__).resolve().parent
MIX_DIR = ROOT / 'data' / 'physical_mixtures'
REF_DIR = ROOT / 'data' / 'usgs_v7'


def absorption(w, spectrum):
    """1 - R/C, with C the piecewise-linear least concave majorant across the grid."""
    if len(w) != len(spectrum) or len(w) < 2 or np.any(np.diff(w) <= 0) or np.any(spectrum <= 0):
        raise ValueError('A continuum needs increasing wavelengths and positive reflectance.')
    hull = []
    for i in range(len(w)):
        while len(hull) >= 2:
            a,b = hull[-2:]
            # Upper hull slopes decrease; remove a low/collinear interior point.
            if ((spectrum[b]-spectrum[a])*(w[i]-w[b]) >
                    (spectrum[i]-spectrum[b])*(w[b]-w[a])):
                break
            hull.pop()
        hull.append(i)
    continuum = np.interp(w, w[hull], spectrum[hull])
    return np.maximum(0, 1 - spectrum/continuum)


def ranked(lib, observed, processed):
    refs = lib.R
    y = np.asarray(observed, dtype=float)
    if processed:
        refs = np.column_stack([absorption(lib.wl, r) for r in refs.T])
        y = absorption(lib.wl, y)
    # A flat or featureless observation does not define a direction in band depth space.
    if np.linalg.norm(y) <= 1e-12:
        return []
    denom = np.linalg.norm(refs, axis=0)*np.linalg.norm(y)
    cosines = np.divide(refs.T @ y, denom, out=np.full(len(denom), -np.inf), where=denom>1e-12)
    order = np.argsort(-cosines, kind='stable')
    return [{"mineral":lib.names[i], "cosine": float(np.clip(cosines[i],-1,1))}
            for i in order if np.isfinite(cosines[i])]


def angles(lib, test, processed):
    ranks = []
    for i, y in enumerate(test.R.T):
        order = [v["mineral"] for v in ranked(lib, y, processed)]
        label = test.names[i]
        ranks.append({"label":label, "first":order[0] if order else None,
                      "true_rank":order.index(label)+1 if label in order else None})
    return {"correct_top1": sum(r["true_rank"] == 1 for r in ranks),
            "correct_top3": sum(r["true_rank"] in (1,2,3) for r in ranks), "results": ranks}


def identify(path, column):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        rows = csv.DictReader(stream)
        if not rows.fieldnames or rows.fieldnames[0] != 'wavelength_um' or column not in rows.fieldnames[1:]:
            raise ValueError('Provide a CSV with wavelength_um first and a named sample column.')
        samples = [(float(r['wavelength_um']),float(r[column])) for r in rows]
    if len(samples) < 2:
        raise ValueError('Provide at least two wavelength rows.')
    w,y = np.array(samples).T
    ref,_ = measured_specimens()
    if (not np.isfinite(w).all() or np.any(np.diff(w)<=0) or w[0] > ref.wl[0] or w[-1] < ref.wl[-1]
            or not np.isfinite(y).all() or np.any(y<=0)):
        raise ValueError('Use positive finite reflectances and increasing wavelengths spanning the reference range.')
    y = np.interp(ref.wl,w,y)
    return {"sample":column,"bands":len(ref.wl),"method":"nearest pure reference by cosine; scores are not probabilities",
            "raw":ranked(ref,y,False),"continuum":ranked(ref,y,True)}


def minimax(a, b, y):
    # min e with -e <= b+f(a-b)-y <= e, 0<=f<=1.
    d = a-b
    bounds = np.vstack((np.column_stack((d, -np.ones(len(y)))),
                        np.column_stack((-d, -np.ones(len(y))))))
    opt = linprog([0,1], A_ub=bounds, b_ub=np.r_[y-b, b-y],
                  bounds=[(0,1),(0,None)], method='highs')
    if not opt.success:
        raise RuntimeError(opt.message)
    f = opt.x[0]
    return float(np.max(np.abs((b+f*d)-y))), float(f)


def load_mixture(ref, row, native):
    path = MIX_DIR/row['file']
    if sha256(path.read_bytes()).hexdigest() != row['sha256']:
        raise ValueError('Mixture checksum mismatch: '+row['id'])
    w, matrix = _resample_common(native, [np.loadtxt(path, skiprows=1)], ref.wl)
    return Library(ref.names, w, ref.R[np.searchsorted(ref.wl, w)]), matrix[:,0].round(6)


def study():
    ref, held_out = measured_specimens()
    proxy = builtin_proxy(ref.wl).subset(ref.names)
    singles = {label: angles(reference, held_out, processing) for label, reference, processing in
               [('raw_proxy', proxy, False), ('raw_measured', ref, False),
                ('continuum_proxy', proxy, True), ('continuum_measured', ref, True)]}
    ref_manifest = json.loads((REF_DIR/'manifest.json').read_text())
    native = np.loadtxt(REF_DIR/ref_manifest['wavelengths'], skiprows=1)
    manifest = json.loads((MIX_DIR/'manifest.json').read_text())
    cases = []
    for row in manifest['records']:
        reference, y = load_mixture(ref, row, native)
        w = reference.wl
        actual = sorted(row['minerals_by_weight'])
        fits = []
        for i,j in combinations(range(len(ref.names)), 2):
            err,f = minimax(reference.R[:,i],reference.R[:,j],y)
            fits.append((err,[ref.names[i],ref.names[j]],f))
        fits.sort(key=lambda v:v[0])
        rank = next(k for k,f in enumerate(fits) if sorted(f[1])==actual)
        actual_error, names, fraction = fits[rank]
        obs = {Fraction(f'{band:.3f}'): Fraction(f'{value:.6f}') for band,value in zip(w,y)}
        matches = all_pairs(reference, obs, Fraction('0.005'))
        reported_prior = row['minerals_by_weight'][names[0]]
        cases.append({'id':row['id'], 'true_pair':names, 'lab_weight_fractions':row['minerals_by_weight'],
                      'bands':len(w), 'candidates':len(fits), 'best_pair':fits[0][1],
                      'best_pair_min_max_abs_error':fits[0][0],'true_pair_rank':rank+1,
                      'true_pair_min_max_abs_error':actual_error,
                      'affine_fit_fraction_first':fraction,'lab_weight_fraction_first':reported_prior,
                      'exact_feasible_pairs_at_0.005': sum(x['possible'] for x in matches)})
    return {'pure_specimens':{'count':len(ref.names),'bands':len(ref.wl),'comparison':singles},
            'physical_mixtures':cases,'measurement_units':'Absolute reflectance fractions on the six-decimal table.',
            'objective':'Every one of 105 two-mineral convex segments is fitted in maximum absolute error by a linear program. The tolerance-0.005 exhaustive feasible count uses the separate rational interval checker.',
            'continuum_method':'One upper hull over every available common-grid wavelength, no fitted windows, no parameter sweep; cosine of 1 - reflectance / upper hull.',
            'interpretation':'Laboratory weight fractions are independent labels. Affine spectral coefficients are optical model parameters. The same reference minerals may come from different specimens, grain sizes or compositions.'}


def draw_example(path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    ref, _ = measured_specimens()
    mix_manifest = json.loads((MIX_DIR/'manifest.json').read_text())
    row = next(r for r in mix_manifest["records"] if r["id"]=="GDS222")
    ref_manifest = json.loads((REF_DIR/'manifest.json').read_text())
    native = np.loadtxt(REF_DIR/ref_manifest["wavelengths"], skiprows=1)
    reference, observed = load_mixture(ref, row, native)
    w=reference.wl
    a,b = (reference.R[:,reference.names.index(m)] for m in ("alunite", "pyrophyllite"))
    err,f = minimax(a,b,observed)
    predicted = f*a+(1-f)*b
    with plt.rc_context({"font.size":10,"axes.spines.right":False,"axes.spines.top":False,
                         "svg.fonttype":"none","svg.hashsalt":"geoassay-gds222"}):
        fig,(ax,diff)=plt.subplots(2,1,figsize=(8,5.4),height_ratios=(2.2,1.2),sharex=True,
                                   layout="constrained",gridspec_kw={"hspace":.1})
        fig.suptitle("A weighed mineral mixture challenges the optical model",x=.02,ha="left",
                     fontsize=16,fontweight="bold")
        ax.set_title("GDS222  ·  Physical powder: 50% alunite, 50% pyrophyllite by weight",loc="left",fontsize=11)
        ax.plot(w,observed,color="#075c55",lw=2.3,label="Measured mixed powder")
        ax.plot(w,predicted,color="#a54721",ls="--",lw=1.8,label="Best straight mixture of pure spectra")
        ax.set_ylabel("Absolute reflectance")
        ax.legend(frameon=False,loc="lower left",fontsize=9)
        diff.axhspan(-.005,.005,color="#e0e2c9",label="Allowed range ±0.005")
        diff.axhline(0,color="#777f70",lw=.8)
        diff.plot(w,predicted-observed,color="#923717",lw=1.6)
        diff.set_ylabel("Model − measured")
        diff.set_xlabel("Wavelength (µm)")
        diff.set_ylim(-.14,.14)
        diff.legend(frameon=False,loc="lower left",fontsize=9)
        diff.set_title(f"Best optical fraction: {f:.3f} alunite     Largest mismatch: {err:.4f}",loc="left",fontsize=10)
        for axis in (ax,diff):
            axis.grid(axis="y", color="#daded8",lw=.6)
            axis.set_axisbelow(True)
            axis.margins(x=.01)
        fig.savefig(path,metadata={"Title":"USGS GDS222 physical spectrum and best affine mixture",
            "Description":"Measured powder, fitted mixture and signed residual on the shared valid wavelength grid.",
            "Date":None})
        plt.close(fig)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write',action='store_true',help='Regenerate the bundled receipt.')
    parser.add_argument('--identify',type=Path,metavar='CSV',help='Rank measured pure reference minerals for a scan.')
    parser.add_argument('--sample',metavar='COLUMN',help='Name of a reflectance column in --identify CSV.')
    parser.add_argument('--figure',type=Path,metavar='SVG',help='Also draw the physical GDS222 example (requires matplotlib).')
    args=parser.parse_args()
    if bool(args.identify) != bool(args.sample) or (args.identify and (args.write or args.figure)):
        parser.error('Use --identify CSV with --sample COLUMN, or run the benchmark with optional --write.')
    try:
        result = identify(args.identify, args.sample) if args.identify else study()
    except (ValueError,OSError) as e:
        parser.error(str(e))
    data=json.dumps(result,indent=2,allow_nan=False)+'\n'
    if args.write: (ROOT/'data'/'physical_benchmark.json').write_text(data)
    if args.figure: draw_example(args.figure)
    print(data,end='')
