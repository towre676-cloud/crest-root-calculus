# Crest–Root open research, 23 November 2026

Read [the research guide](research/README.md), the
[57-item register](research/backlog-2026-11-23.md), or the
[nine-page introductory essay](downloads/crest-root-introduction.pdf).
This packet preserves the earlier research content and adds the
[periodic spectral challenge](research/periodic-spectra/README.md), its exact
proofs, original and compiled-PARI comparisons, and normalization examples.
The [branch reconciliation](research/branch-reconciliation-2026-11-23.md)
records the integration of all research branches and publication source.

It includes the canonical 148-section monograph, finite hyperelliptic map
reconstruction, local-to-global certificates, the equal-count obstruction,
earlier solver comparisons, the marked chart-I solver, point-free
Riemann–Roch, genus-two correspondences, genus-37 rank certificates, quartic
degree spectra, the historical atlas and higher-support tower certificates.

After extracting, open a terminal in this folder. Windows commands:

```sh
py -m pip install numpy "sympy>=1.12,<2"
py research/replay.py --workers 4
```

On macOS or Linux, substitute `python3` for `py`. The replay launches the
**32 verification groups** listed in research/replay.py. Default checks
run offline. With PARI/GP installed, the rank replay also regenerates the
number-field and local arithmetic behind the upper bounds. Without GP, it
checks the recorded descent matrices and lower-bound divisor certificates.

The periodic study can be audited separately:

```sh
py research/periodic-spectra/audit_native.py
py research/periodic-spectra/spectral_curve.py
```

The finite-map certificates require Python and SymPy; Singular accelerates
new general eliminations. Repeating measured studies requires their stated
tools and a POSIX environment. All recorded outcomes, exact output checks,
resource limits, dependency hashes and timing provenance remain included.
See the [earlier solver instructions](research/solver-comparison/README.md)
and [periodic study guide](research/periodic-spectra/README.md).

The archive's MANIFEST.json records the size and SHA-256 of every other file.
The repository-native builder is included. To rebuild both packets from
this extracted source or a repository checkout:

```sh
py research/build_packet.py --list
py research/build_packet.py
py research/build_packet.py --check
```

Fixed entry ordering, timestamps, permissions and compression settings make
the output deterministic for unchanged inputs and the same Python/zlib
toolchain. The builder verifies every member against its source bytes and
an extracted copy. It excludes caches, executables, logs and archive
recursion. Existing historical download exports and the source PDF are
left untouched.
