"""Evaluate AC operating points and compare each bus/asset against the same physical baseline."""

from dataclasses import dataclass
import json
from pathlib import Path
import numpy as np
from .calendar import SEASON
from .layout import home_layout
from .profiles import year
from .radial import Feeder, Flow


@dataclass(frozen=True)
class Condition:
    name: str
    solar: float
    demand: float
    source: float


CONDITIONS = (
    Condition("nominal", 1.0, 1.0, 1.02),
    Condition("bright_low_demand", 1.12, 0.88, 1.026),
    Condition("dim_high_demand", 0.88, 1.12, 1.014),
)


@dataclass(frozen=True)
class Limits:
    lower: float = 0.94
    upper: float = 1.06
    thermal: float = 100.0


@dataclass
class Offer:
    grid: Feeder
    flexible: np.ndarray
    fixed: np.ndarray
    n_existing: int
    limits: Limits

    @classmethod
    def read(cls, path):
        data = json.loads(Path(path).read_text())
        homes = home_layout(
            data["n_existing"], n_new=data["n_new"], seed=data.get("feeder_seed", 0)
        )
        new = [h for h in homes if h["new"]]
        if not new or len(data["per_home"]) != len(new):
            raise ValueError("Receipt has inconsistent candidate-home counts.")
        for h, logged in zip(new, data["per_home"]):
            if any(
                h[key] != logged[k]
                for key, k in (("name", "home"), ("where", "where"), ("pv_kw", "pv_kw"))
            ):
                raise ValueError(
                    "Receipt home IDs, locations or nameplates disagree with the feeder."
                )
        caps = np.asarray(data["flex_caps_kw"], float)
        fixed = np.asarray([h["static_cap_kw"] for h in data["per_home"]], float)
        ratings = np.array([h["pv_kw"] for h in new])
        if (
            caps.shape != (4, 24, len(new))
            or not np.isfinite(caps).all()
            or np.any((caps < 0) | (caps > ratings))
        ):
            raise ValueError(
                "Invalid flexible cap table; expected finite (4,24,homes) kW."
            )
        if not np.isfinite(fixed).all() or np.any((fixed < 0) | (fixed > ratings)):
            raise ValueError("Invalid static caps.")
        return cls(
            Feeder(homes),
            caps,
            np.broadcast_to(fixed, caps.shape),
            data["n_existing"],
            Limits(upper=float(data["vmax_pu"]), thermal=float(data["line_limit_pct"])),
        )


class WeatherYear:
    def __init__(self, model, seed):
        self.model = model
        self.seed = seed
        homes = model.grid.homes
        self.n_existing = model.n_existing
        self.rated = np.array([h["pv_kw"] for h in homes])
        self.profiles = year(len(homes), seed)
        self.sun = self.profiles["pv_unit"].reshape(-1, 1) * self.profiles["orient"]
        self.demand = self.profiles["load_kw"].reshape(len(homes), -1).T
        self.season = SEASON[np.arange(8760) // 24]
        self.hour = np.arange(8760) % 24
        self.interval_hours = 1.0

    def clock(self, t):
        return {
            "day_index": int(t * self.interval_hours // 24),
            "hour": int(self.hour[t]),
            "minute": int(round(((t * self.interval_hours) % 1) * 60)),
            "interval_index": int(t),
        }

    def powers(self, condition, hours, caps=None, mode="connected"):
        """Three baselines distinguish adding households, PV and capped export."""
        new = slice(self.n_existing, None)
        pv = np.minimum(self.sun[hours] * condition.solar, 1.0) * self.rated
        available = pv[:, new].copy()
        load = self.demand[hours] * condition.demand
        if mode == "no_new_homes":
            pv[:, new] = 0.0
            load[:, new] = 0.0
        elif mode == "new_without_pv":
            pv[:, new] = 0.0
        elif mode == "connected" and caps is not None:
            pv[:, new] = np.minimum(
                pv[:, new], load[:, new] + caps[self.season[hours], self.hour[hours]]
            )
        elif mode != "connected":
            raise ValueError("Unknown connection mode.")
        return load - pv, 0.2 * load, available - pv[:, new], available

    def run(self, condition, hours, caps=None, mode="connected"):
        pieces = []
        lost, available = [], []
        for start in range(0, len(hours), 336):
            index = hours[start : start + 336]
            p, q, curtailed, produced = self.powers(condition, index, caps, mode)
            pieces.append(self.model.grid.solve(p, q, condition.source))
            lost.append(curtailed)
            available.append(produced)
        flow = Flow(
            np.vstack([f.voltage for f in pieces]),
            np.vstack([f.loading for f in pieces]),
            max(f.residual for f in pieces),
            max(f.iterations for f in pieces),
        )
        return flow, np.vstack(lost), np.vstack(available)


def violation_masks(flow, limits, baseline=None, margin=0.0):
    """Absolute, or exceeding the limit and worse than that same component in the reference.

    margin adds pu voltage headroom in training; thermal headroom in percent is 100*margin.
    """
    eps_v, eps_i = 1e-8, 1e-5
    low = flow.voltage < limits.lower + margin - eps_v
    high = flow.voltage > limits.upper - margin + eps_v
    hot = flow.loading > limits.thermal - 100 * margin + eps_i
    if baseline is not None:
        low &= flow.voltage < baseline.voltage - eps_v
        high &= flow.voltage > baseline.voltage + eps_v
        hot &= flow.loading > baseline.loading + eps_i
    return low, high, hot


def bad_hours(masks):
    return np.logical_or.reduce([m.any(axis=1) for m in masks])


def report(flow, limits, hours, grid, zero=None, absent=None, clock=None):
    if clock is None:
        clock = lambda t: {"day_index": int(t // 24), "hour": int(t % 24)}
    strict_masks = violation_masks(flow, limits)
    absolute = bad_hours(strict_masks)
    result = {
        "hours": len(hours),
        "absolute_violation_hours": int(absolute.sum()),
        "low_voltage_hours": int(strict_masks[0].any(axis=1).sum()),
        "high_voltage_hours": int(strict_masks[1].any(axis=1).sum()),
        "thermal_hours": int(strict_masks[2].any(axis=1).sum()),
        "max_kcl_residual_pu": float(flow.residual),
    }
    for label, matrix, names, fn in (
        ("high_voltage", flow.voltage, grid.lv_names, np.argmax),
        ("low_voltage", flow.voltage, grid.lv_names, np.argmin),
        ("thermal", flow.loading, grid.components, np.argmax),
    ):
        t, component = np.unravel_index(fn(matrix), matrix.shape)
        result[label + "_witness"] = {
            **clock(hours[t]),
            "component": names[component],
            "value": float(matrix[t, component]),
        }
    for key, base in (("export", zero), ("development", absent)):
        if base is None:
            continue
        masks = violation_masks(flow, limits, base)
        mask = bad_hours(masks)
        result[key + "_worsened_hours"] = int(mask.sum())
        if mask.any():
            t = int(np.flatnonzero(mask)[0])
            for tag, components, values, old, hit in (
                ("low_voltage", grid.lv_names, flow.voltage, base.voltage, masks[0]),
                ("high_voltage", grid.lv_names, flow.voltage, base.voltage, masks[1]),
                ("thermal", grid.components, flow.loading, base.loading, masks[2]),
            ):
                if hit[t].any():
                    j = int(np.flatnonzero(hit[t])[0])
                    result[key + "_counterexample"] = {
                        **clock(hours[t]),
                        "metric": tag,
                        "component": components[j],
                        "value": float(values[t, j]),
                        "reference_value": float(old[t, j]),
                    }
                    break
    return result


def finite_design(
    model, training, hours, factors, margin=0.0008, static=False, conditions=CONDITIONS
):
    """Largest permitted scalar per season/hour from an explicit finite ladder.
    A failed scale carries a day/hour/asset witness. Cells do not constrain one another.
    """
    factors = tuple(factors)
    if (
        not factors
        or factors[0] != 1
        or factors[-1] != 0
        or any(a <= b for a, b in zip(factors, factors[1:]))
    ):
        raise ValueError("Use a strictly decreasing ladder from one to zero.")
    if not training or not conditions:
        raise ValueError("Specify at least one training profile and condition.")
    cell = training[0].season[hours] * 24 + training[0].hour[hours]
    for other in training[1:]:
        if not np.array_equal(cell, other.season[hours] * 24 + other.hour[hours]):
            raise ValueError(
                "Training calendars must agree within a joint qualification."
            )
    if set(map(int, np.unique(cell))) != set(range(96)):
        raise ValueError("Design hours must cover all 96 season/hour cells.")
    if static:
        cell = np.zeros_like(cell)
    base_offer = model.fixed if static else model.flexible
    pending = set(map(int, np.unique(cell)))
    scale = np.ones(1 if static else 96)
    cells_tested = sorted(pending)
    zeros = np.zeros_like(model.flexible)
    cases = [(weather, cond) for weather in training for cond in conditions]
    reference = {(w.seed, c.name): w.run(c, hours, zeros)[0] for w, c in cases}
    rejections = {}
    for factor in factors:
        if not pending:
            break
        sel = np.flatnonzero(np.isin(cell, list(pending)))
        failed = set()
        for w, cond in cases:
            state = w.run(cond, hours[sel], base_offer * factor)[0]
            base = reference[w.seed, cond.name].take(sel)
            masks = violation_masks(state, model.limits, base, margin)
            bad = bad_hours(masks)
            for k in np.unique(cell[sel[bad]]):
                k = int(k)
                if k in failed:
                    continue
                failed.add(k)
                r = int(np.flatnonzero(bad & (cell[sel] == k))[0])
                source_hour = int(hours[sel[r]])
                for metric, names, flags, vals, ref in (
                    (
                        "low_voltage",
                        model.grid.lv_names,
                        masks[0],
                        state.voltage,
                        base.voltage,
                    ),
                    (
                        "high_voltage",
                        model.grid.lv_names,
                        masks[1],
                        state.voltage,
                        base.voltage,
                    ),
                    (
                        "thermal",
                        model.grid.components,
                        masks[2],
                        state.loading,
                        base.loading,
                    ),
                ):
                    if flags[r].any():
                        i = int(np.flatnonzero(flags[r])[0])
                        rejections.setdefault(str(k), []).append(
                            dict(
                                scale=factor,
                                condition=cond.name,
                                seed=w.seed,
                                **w.clock(source_hour),
                                metric=metric,
                                component=names[i],
                                value=float(vals[r, i]),
                                reference_value=float(ref[r, i]),
                            )
                        )
                        break
        for k in pending - failed:
            scale[k] = factor
        pending = failed
    if pending:
        raise ArithmeticError("Zero-export reference was not reproduced.")
    scales = np.full((4, 24), scale[0]) if static else scale.reshape(4, 24)
    return scales, {
        "scales": scales.tolist(),
        "base_offer": "fixed" if static else "flexible",
        "ladder": list(factors),
        "rejected_scales": rejections,
        "voltage_headroom_pu": margin,
        "thermal_headroom_pct": 100 * margin,
        "tested_cells": len(cells_tested),
        "training_hours_per_year_per_condition": len(hours),
    }
