"""Paired, held-out synthetic comparisons on a fixed seed and a strict adaptivity witness."""
from itertools import combinations
import json
import numpy as np
from geoassay import SITE_MODELS, Site
from geoassay.policy import Planner, entropy
import validate as generator


def truncated_pair(planner, pair):
    # Reconstruct the original six-outcome, renormalized approximation, preserving
    # its order dependence. This evaluates the legacy objective with matched priors.
    first, second = [planner.kernels[i] for i in pair]
    mass = planner.prior @ first
    most = np.argsort(-mass)[:6]
    value = 0.0
    for a in most:
        p = planner.prior * first[:, a] / mass[a]
        prob = p @ second
        keep = np.argsort(-prob)[:6]
        terminals = p[:, None] * second[:, keep]
        value += mass[a] * planner._leaf_entropies(terminals) / prob[keep].sum()
    return value / mass[most].sum()


def decision_witness():
    k = [np.eye(2)[v] for v in [[0,0,1,1], [0,1,1,1], [1,1,0,1]]]
    return Planner(np.full(4, .25), np.arange(4), k).solve(2)


def run(trials=100, seed=841092):
    rng = np.random.default_rng(seed)
    models = list(SITE_MODELS)
    # Same synthetic family as the earlier study. No fitting or tuning on these sites.
    generator.SIG, generator.NS, generator.OVER = .05, 8, .25
    generator.OTHER.update({models[i]: models[j] for i,j in enumerate([2,3,0,1,1])})
    results = {k: [] for k in ("adaptive", "adaptive_replan", "fixed", "legacy_six", "ambiguous", "random")}
    expected_savings = []
    outside_first = 0

    for trial in range(trials):
        target = trial % len(models)
        samples, truth = generator.make_site(rng, models[target])
        site = Site(samples, generator.M)
        planner = Planner.from_site(site)
        opt = planner.solve(2)
        root = opt["adaptive"]
        first = root["sample"]
        adaptive = []
        outside = False
        if first is not None:
            adaptive.append(first)
            outcomes = [tuple(sorted(a)) for a in site.tab[first][0]]
            if truth[first] in outcomes:
                branches = {b["outcome"]: b["next"]["sample"] for b in root.get("branches", [])}
                second = branches.get(outcomes.index(truth[first]))
                if second is not None:
                    adaptive.append(second)
            else:
                outside = True
        outside_first += int(outside)
        batch = opt["fixed"]["samples"]
        old = min(combinations(range(len(samples)), 2), key=lambda pair: truncated_pair(planner, pair))
        ambiguous = sorted(range(len(samples)),
                           key=lambda i: -entropy(np.array([x["p"] for x in samples[i]["hyps"]])))[:2]
        adaptive_replan = list(adaptive)
        if outside:
            observed = {first: truth[first]}
            revised = Planner.from_site(site, observed).solve(1, excluded=observed)
            if revised["adaptive"]["sample"] is not None:
                adaptive_replan.append(revised["adaptive"]["sample"])
        picks = {"adaptive": adaptive, "adaptive_replan": adaptive_replan, "fixed": batch, "legacy_six": old, "ambiguous": ambiguous,
                 "random": rng.choice(len(samples), 2, replace=False)}
        for method, selected in picks.items():
            # A signed, out-of-support lab result still supersedes that scan in
            # the original site's posterior; the adaptive policy stops asking.
            post = site.posterior({i: truth[i] for i in selected})
            results[method].append([post[target], float(np.argmax(post) == target), entropy(post), len(selected)])
        expected_savings.append(opt["adaptive_saving_over_fixed_nats"])

    report = {}
    for method, scores in results.items():
        data = np.array(scores)
        diff = data[:,0] - np.array(results["fixed"])[:,0]
        report[method] = {
            **dict(zip(["mean_p_true", "map_accuracy", "mean_posterior_entropy_nats", "mean_assays"],
                       data.mean(axis=0).tolist())),
            "paired_p_true_minus_fixed": float(diff.mean()),
            "paired_standard_error": float(diff.std(ddof=1)/np.sqrt(trials)),
        }
    return {"synthetic_only": True, "seed": seed, "sites": trials, "samples_per_site": 8,
            "budget": 2, "scan_noise_sigma": .05, "true_overprint": .25, "keep_per_scan": 20,
            "site_overprint_weights": [0,.2,.4], "strategies": report,
            "mean_model_conditional_adaptive_saving_nats": float(np.mean(expected_savings)),
            "adaptive_outside_first_support": outside_first,
            "outside_first_protocol": "Adaptive stops after one unsupported result. Adaptive_replan replaces the scan with the confirmed lab result and plans the remaining credit. Both include all cases.",
            "witness_four_equiprobable_hidden_types": decision_witness()}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
