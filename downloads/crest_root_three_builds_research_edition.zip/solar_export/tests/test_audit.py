import json
from pathlib import Path
import numpy as np
import pytest
from flexexport.audit import (
    CONDITIONS,
    Limits,
    Offer,
    WeatherYear,
    bad_hours,
    violation_masks,
)
from flexexport.check import check
from flexexport.layout import home_layout
from flexexport.metered import Metered, counts_to_durations
from flexexport.radial import Flow
from flexexport.stress import evaluate, replay

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "receipt_new18.json"


def test_changing_reference_element_matters():
    base = Flow(np.array([[1.01, 1.03]]), np.array([[117.0, 95.0]]), 0, 1)
    after = Flow(np.array([[1.01, 1.03]]), np.array([[106.0, 108.0]]), 0, 1)
    # The old global maximum improved, while the second component began to overload.
    masks = violation_masks(after, Limits(), base)
    assert masks[2].tolist() == [[False, True]]
    assert bad_hours(masks).tolist() == [True]


def test_all_candidate_load_is_absent_only_for_no_new_home_counterfactual():
    g = Offer.read(SOURCE)
    w = WeatherYear(g, 0)
    t = np.array([0])
    actual, q, _, _ = w.powers(CONDITIONS[0], t, mode="new_without_pv")
    absent, q0, _, _ = w.powers(CONDITIONS[0], t, mode="no_new_homes")
    assert np.all(actual[0, g.n_existing :] > 0) and np.all(q[0, g.n_existing :] > 0)
    assert not absent[0, g.n_existing :].any() and not q0[0, g.n_existing :].any()
    np.testing.assert_allclose(actual[0, : g.n_existing], absent[0, : g.n_existing])


def test_legacy_split_replayed_with_independent_ac():
    model = Offer.read(SOURCE)
    summarized = replay(json.loads(SOURCE.read_text()), model)
    assert (
        sum(s["unlimited_export"]["independent_hours"] for s in summarized.values())
        == 47
    )
    assert all(
        r["independent_hours"] == r["reference_hours"]
        for s in summarized.values()
        for r in s.values()
    )


def test_portable_pointwise_ac_against_archived_values():
    g = Offer.read(SOURCE)
    w = WeatherYear(g, 0)
    f = w.run(CONDITIONS[0], np.array([192 * 24 + 12]), g.flexible)[0]
    assert abs(f.voltage.max() - 1.0576147799) < 1e-8
    assert abs(f.loading[0, 0] - 34.3979663) < 1e-4
    assert f.residual < 1e-8


def test_invalid_caps_and_topology(tmp_path):
    with pytest.raises(ValueError):
        home_layout(36, n_new=30)
    raw = json.loads(SOURCE.read_text())
    raw["flex_caps_kw"][0][0][0] = -1
    p = tmp_path / "bad.json"
    p.write_text(json.dumps(raw))
    with pytest.raises(ValueError):
        Offer.read(p)


def test_mismatch_source_hash_rejected(tmp_path):
    d = json.loads((ROOT / "stress_new18.json").read_text())
    d["source_sha256"] = "0" * 64
    p = tmp_path / "bad-stress.json"
    p.write_text(json.dumps(d))
    with pytest.raises(ValueError, match="SHA-256"):
        check(SOURCE, p)


def test_meter_intervals_preserve_energy_and_season(tmp_path):
    model = Offer.read(SOURCE)
    n = len(model.grid.homes)
    p = tmp_path / "test.npz"
    args = dict(
        load_kw=np.full((48, n), 0.4),
        pv_unit=np.full((48, n), 0.5),
        season=np.full(48, 2),
        hour=np.arange(48) // 2,
        interval_hours=0.5,
    )
    np.savez(p, **args)
    m = Metered(model, p)
    assert m.clock(25) == {
        "day_index": 0,
        "hour": 12,
        "minute": 30,
        "interval_index": 25,
    }
    caps = model.flexible.copy()
    caps[2, 12] = 0
    _, _, lost, pv = m.powers(CONDITIONS[0], np.array([25]), caps)
    assert np.allclose(lost, pv - 0.4)
    res = evaluate(model, m, CONDITIONS[0], np.arange(48), caps, caps)
    r = res["revised"]
    assert r["new_pv_available_kwh"] == 24 * 0.5 * m.rated[model.n_existing :].sum()
    counts_to_durations(r, 0.5)
    assert r["hours"] == 24 and r["intervals"] == 48
    args["hour"] = np.full(48, 8)
    np.savez(p, **args)
    with pytest.raises(ValueError, match="regular"):
        Metered(model, p)
