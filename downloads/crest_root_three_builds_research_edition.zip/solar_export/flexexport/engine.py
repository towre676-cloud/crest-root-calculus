"""Flexible export offers (dynamic operating envelopes) for candidate PV homes.

Offer = per home, per (season, hour) export cap in kW.  Computed from training days by a linear
program on power-flow sensitivities (maximise the smallest cap, then the total), then verified
with full AC power flows on every training hour and tightened where needed.  Baseline = a static
per-home export cap that must hold in every hour (today's usual connection offer).
Evaluation runs full power flows on held-out days, including the highest-load and highest
net-export days of the year, which never appear in training.
"""
from __future__ import annotations
import numpy as np, pandapower as pp
from scipy.optimize import linprog

from .calendar import SEASON, SEASON_NAMES, SUN_HOURS

class Grid:
    def __init__(self, net, homes, prof, vmax=1.06, load_max=100.0, trafo_max=100.0):
        self.net, self.homes, self.p = net, homes, prof
        self.vmax, self.lmax, self.tmax = vmax, load_max, trafo_max
        self.new = [i for i, h in enumerate(homes) if h["new"]]
        self.lv_buses = net.bus.index[net.bus.vn_kv < 1].values

    def avail(self, d, h):
        """Per-home available PV generation and gross demand, both in kW."""
        pv = np.array([hm["pv_kw"] for hm in self.homes]) * self.p["pv_unit"][d, h] * self.p["orient"][:len(self.homes)]
        ld = self.p["load_kw"][:len(self.homes), d, h]
        return pv, ld

    def run(self, d, h, caps=None, connect_new=True):
        """Return (max voltage, min voltage, peak line %, transformer %, per-home exports).
        connect_new=False turns off candidate PV and leaves those households' loads connected.
        """
        pv, ld = self.avail(d, h)
        exp_new = np.zeros(len(self.new))
        for i, hm in enumerate(self.homes):
            p_pv = pv[i]
            if hm["new"]:
                k = self.new.index(i)
                if not connect_new: p_pv = 0.0
                else:
                    surplus = max(p_pv - ld[i], 0.0)
                    allowed = surplus if caps is None else min(surplus, caps[k])
                    exp_new[k] = allowed
                    p_pv = min(p_pv, ld[i]) + allowed          # curtail inverter to load + allowed export
            self.net.sgen.at[hm["pv_el"], "p_mw"] = p_pv/1000
            self.net.load.at[hm["load_el"], "p_mw"] = ld[i]/1000
            self.net.load.at[hm["load_el"], "q_mvar"] = ld[i]/1000*0.2
        pp.runpp(self.net, numba=True, init="results" if self.net.get("converged") else "auto")
        return (float(self.net.res_bus.vm_pu.values[self.lv_buses].max()), float(self.net.res_bus.vm_pu.values[self.lv_buses].min()),
                float(self.net.res_line.loading_percent.max()), float(self.net.res_trafo.loading_percent.max()), exp_new)

    def ok(self, r, margin_v=0.0):
        vmax, vmin, ll, tl, _ = r
        return vmax <= self.vmax - margin_v + 1e-9 and ll <= self.lmax and tl <= self.tmax

    def sensitivities(self, d, h, step_kw=2.0):
        """d(Vmax-bus voltages)/dE and d(line loading)/dE for each new home, by finite differences around exports=0."""
        caps0 = np.zeros(len(self.new))
        base = self._state(d, h, caps0)
        Sv, Sl = [], []
        for k in range(len(self.new)):
            c = caps0.copy(); c[k] = step_kw
            st = self._state(d, h, c, force=True)
            Sv.append((st[0]-base[0])/step_kw); Sl.append((st[1]-base[1])/step_kw)
        return base, np.array(Sv).T, np.array(Sl).T

    def _state(self, d, h, caps, force=False):
        """Bus voltages and line loadings with new homes exporting exactly caps (forced, if force) on top of self-consumption."""
        pv, ld = self.avail(d, h)
        for i, hm in enumerate(self.homes):
            p = pv[i]
            if hm["new"]:
                k = self.new.index(i); p = min(pv[i], ld[i]) + caps[k]
            self.net.sgen.at[hm["pv_el"], "p_mw"] = p/1000
            self.net.load.at[hm["load_el"], "p_mw"] = ld[i]/1000
            self.net.load.at[hm["load_el"], "q_mvar"] = ld[i]/1000*0.2
        pp.runpp(self.net, numba=True)
        return self.net.res_bus.vm_pu.values[self.lv_buses].copy(), self.net.res_line.loading_percent.values.copy()

def _lp(blocks, ub):
    """blocks: list of (A, b) meaning A c <= b.  max t, then max sum c, s.t. t <= c <= ub."""
    n = len(ub)
    A = np.vstack([x[0] for x in blocks]); b = np.concatenate([x[1] for x in blocks])
    A1 = np.hstack([A, np.zeros((A.shape[0], 1))]); T = np.hstack([-np.eye(n), np.ones((n, 1))])
    r = linprog(np.r_[np.zeros(n), -1], A_ub=np.vstack([A1, T]), b_ub=np.r_[b, np.zeros(n)],
                bounds=[(0, u) for u in ub] + [(0, None)], method="highs")
    if r.status != 0: return np.zeros(n)
    tstar = r.x[-1]*(1-1e-6)
    r2 = linprog(-np.ones(n), A_ub=A, b_ub=b, bounds=[(min(tstar, u), u) for u in ub], method="highs")
    return r2.x if r2.status == 0 else r.x[:n]

def _blocks(g, key, rows, sens, margin):
    Sv, Sl = sens[key]; out = []
    for (_, _, V0, L0) in rows[key]:
        out.append((Sv, g.vmax - margin - V0)); out.append((np.abs(Sl), g.lmax*0.97 - L0))
    return out

def design_offers(g: Grid, train_days, margin0=0.002, max_rounds=8, static=False, log=print):
    """Return caps[season, hour, k] (kW).  static=True gives one cap per home for all hours."""
    ub = np.array([g.homes[i]["pv_kw"] for i in g.new])
    caps = np.tile(ub, (4, 24, 1)).astype(float)
    cells = {}
    for d in train_days:
        for h in SUN_HOURS:
            if g.p["pv_unit"][d, h] > 0.03: cells.setdefault((SEASON[d], h), []).append(d)
    # base states at zero new export, worst few per cell for the LP rows
    rows = {}
    for key, ds in cells.items():
        s, h = key
        scored = []
        for d in ds:
            V, L = g._state(d, h, np.zeros(len(g.new)))
            scored.append((V.max(), d, V, L))
        scored.sort(key=lambda x: -x[0])
        rows[key] = scored[:4]
    sens = {}
    for key, rr in rows.items():
        d = rr[0][1]; base, Sv, Sl = g.sensitivities(d, key[1]); sens[key] = (Sv, Sl)
    margin = {key: margin0 for key in cells}
    # most export each home could physically attempt in each cell (training data)
    amax = {}
    for key, ds in cells.items():
        A = np.zeros(len(g.new))
        for d in ds:
            pv, ld = g.avail(d, key[1]); A = np.maximum(A, [max(pv[i]-ld[i], 0) for i in g.new])
        amax[key] = np.minimum(A*1.10, ub)      # 10% headroom for unseen sunnier hours
    def solve(key):
        bl = _blocks(g, key, rows, sens, margin[key])
        if all(np.all(Ab[0] @ amax[key] <= Ab[1]) for Ab in bl): return ub.copy()      # cell never binds
        c = _lp(bl, amax[key])
        return np.where(c >= amax[key] - 1e-6, ub, c)
    if static:
        gm = margin0
        for rnd in range(max_rounds):
            am = np.max([amax[k] for k in cells], axis=0)
            c = _lp([blk for k in cells for blk in _blocks(g, k, rows, sens, gm)], am)
            c = np.where(c >= am - 1e-6, ub, c)
            caps[:] = c[None, None, :]
            bad = verify(g, caps, train_days)
            log(f"  static round {rnd}: caps {np.round(c,2).tolist()}  training violations {bad['violations']}")
            if bad["violations"] == 0: break
            gm += 0.002
        return caps
    for key in cells: caps[key[0], key[1]] = solve(key)
    for rnd in range(max_rounds):
        bad = verify(g, caps, train_days)
        log(f"  flexible round {rnd}: training violations {bad['violations']} in cells {sorted(bad['cells'])[:8]}")
        if bad["violations"] == 0: break
        for key in bad["cells"]:
            margin[key] += 0.002; caps[key[0], key[1]] = solve(key)
    return caps

def verify(g, caps, days, connect_new=True, unlimited=False):
    viol, preexisting, cells, worst_v, worst_l = 0, 0, set(), 0.0, 0.0
    exported = np.zeros(len(g.new)); possible = np.zeros(len(g.new)); pvgen = np.zeros(len(g.new))
    for d in days:
        for h in SUN_HOURS:
            if g.p["pv_unit"][d, h] <= 0.0: continue
            c = None if unlimited else caps[SEASON[d], h]
            r = g.run(d, h, c, connect_new)
            pv, ld = g.avail(d, h)
            sur = np.array([max(pv[i]-ld[i], 0) for i in g.new]); possible += sur; exported += r[4]; pvgen += pv[g.new]
            worst_v = max(worst_v, r[0]); worst_l = max(worst_l, r[2], r[3])
            if not g.ok(r):
                if r[0] > g.vmax + 1e-9: viol += 1; cells.add((SEASON[d], h)); continue
                b = g.run(d, h, None, connect_new=False)        # legacy comparator: same households, candidate PV disabled
                if r[2] > max(b[2], g.lmax) + 0.5 or r[3] > max(b[3], g.tmax) + 0.5:
                    viol += 1; cells.add((SEASON[d], h))
                else: preexisting += 1
    return {"violations": viol, "preexisting_import_overloads": preexisting, "cells": cells, "worst_v": worst_v, "worst_loading": worst_l,
            "exported_kwh": exported, "surplus_kwh": possible, "pv_kwh": pvgen}
