'use strict';
const mineralData=window.measuredCurves;
const byId=id=>document.getElementById(id);
const mineralNames=mineralData.names;
const pairs=[];
for(let a=0;a<mineralNames.length;a++)for(let b=a+1;b<mineralNames.length;b++)pairs.push([a,b]);
const addOption=(field,text,value)=>field.add(new Option(text,value));
addOption(byId('sample'),'Constructed 60% kaolinite + 40% dickite','mix');
mineralData.physical.forEach((m,i)=>addOption(byId('sample'),'USGS physical blend · '+m.id+' · '+m.label,'powder'+i));
mineralNames.forEach((n,i)=>addOption(byId('sample'),'USGS challenge · '+n,String(i)));
pairs.forEach(([a,b],i)=>addOption(byId('pair'),mineralNames[a]+' + '+mineralNames[b],String(i)));
function compare(a,b){const p=a.n*b.d-b.n*a.d;return p<0n?-1:p>0n?1:0}
function rational(n,d,at){return d<0n?{n:-n,d:-d,at}:{n,d,at}}
function bounds(a,b,obs,indices,eps){
  let lo=rational(0n,1n,'the physical minimum'),hi=rational(1n,1n,'the physical maximum');
  for(const i of indices){
    const label=mineralData.wl[i]+' µm', base=BigInt(mineralData.refs[b][i]);
    const diff=BigInt(mineralData.refs[a][i])-base, shift=BigInt(obs[i])-base;
    if(diff===0n){if(shift < -eps || shift>eps)return {ok:false,flat:label};continue}
    let l=rational(shift-eps,diff,label),h=rational(shift+eps,diff,label);
    if(compare(l,h)>0)[l,h]=[h,l];
    if(compare(l,lo)>0)lo=l;
    if(compare(h,hi)<0)hi=h;
    if(compare(lo,hi)>0)return {ok:false,lo,hi};
  }
  return {ok:true,lo,hi};
}
const percent=r=>(100*Number(r.n)/Number(r.d)).toFixed(2)+'%';
function paint(){
  const selection=byId('sample').value;
  const physical=selection.startsWith('powder')?mineralData.physical[Number(selection.slice(6))]:null;
  const obs=selection==='mix'?mineralData.mix:physical?physical.spectrum:mineralData.tests[Number(selection)];
  const mode=byId('bands').value;
  const indices=mineralData.wl.map((_,i)=>i).filter(i=>obs[i]!==null && (mode==='all'||(mode==='one'?[2.2]:[1.4,2.17,2.2]).includes(mineralData.wl[i])));
  const eps=BigInt(byId('eps').value), fits=pairs.map(([a,b])=>bounds(a,b,obs,indices,eps));
  const count=fits.filter(s=>s.ok).length;
  byId('count').textContent=count+' of '+pairs.length+' candidate pairs fit '+indices.length+(indices.length===1?' wavelength.':' wavelengths.');
  const k=Number(byId('pair').value),[a,b]=pairs[k],r=fits[k],first=mineralNames[a],second=mineralNames[b];
  byId('first').textContent=first;byId('second').textContent=second;
  byId('proof').textContent=r.flat?'Excluded. At '+r.flat+' both references give the same reading, outside the allowed error.':r.ok?'Possible. The share of '+first+' can range from '+percent(r.lo)+' to '+percent(r.hi)+'. The remaining share is '+second+'.':'Excluded. '+r.lo.at+' requires at least '+percent(r.lo)+' '+first+', while '+r.hi.at+' allows at most '+percent(r.hi)+'.';
  for(let j=0;j<pairs.length;j++){const [u,v]=pairs[j];byId('pair').options[j].text=mineralNames[u]+' + '+mineralNames[v]+' · '+(fits[j].ok?'fits':'excluded')}
  const line=(arr,color,dash)=>({points:mineralData.wl.map((wl,i)=>[wl,arr[i]===null?NaN:arr[i]/1e6]),color,dash,maxGap:.015});
  renderScientificPlot(byId('spectrum'),{xMin:.4,xMax:2.5,yMin:0,yMax:1,xTicks:[.4,.8,1.2,1.6,2,2.5],yTicks:[0,.25,.5,.75,1],xLabel:'Wavelength (µm)',yLabel:'Reflectance',description:'Observed reflectance and the two proposed mineral spectra versus wavelength.',lines:[line(mineralData.refs[a],'#00675e'),line(mineralData.refs[b],'#99511d','5 3'),line(obs,'#182c2b')],markers:indices.length<=3?indices.map(i=>[mineralData.wl[i],obs[i]/1e6]):[]});
  const lead=physical?'USGS physical powder blend, identified by weight: '+physical.label+'. ':'';
  byId('caption').textContent=lead+(mode==='all'?'Every plotted shared wavelength contributes a bound. Gaps mark omitted channels.':'Dots mark the observations used for this calculation. Other wavelengths are shown for context.');
}
for(const id of ['pair','sample','bands','eps'])byId(id).addEventListener('change',paint);
paint();redrawOnWidthChange(document.querySelector('main'),paint);
