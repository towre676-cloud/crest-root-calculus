"""List elements that cross the edge of a narrow viewport."""
import argparse
from pathlib import Path
from playwright.sync_api import sync_playwright

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--chromium")
    args = parser.parse_args()
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(executable_path=args.chromium)
        page = browser.new_page(viewport={"width": 390, "height": 900})
        page.goto(Path(__file__).resolve().with_name("index.html").as_uri())
        print(page.evaluate("""() => ({
          pageWidth: document.documentElement.scrollWidth,
          overflowing: [...document.querySelectorAll('body *')].filter(e =>
              !e.closest('#partsWrap') && e.getBoundingClientRect().right > innerWidth+1
          ).map(e=>e.tagName+'#'+e.id)
        })"""))
        browser.close()
