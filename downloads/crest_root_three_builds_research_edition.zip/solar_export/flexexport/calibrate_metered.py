"""Calibrate two offers on one metered year, then freeze both and evaluate a later year."""

import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from .audit import CONDITIONS, Offer, finite_design
from .metered import Metered, counts_to_durations
from .stress import evaluate


def calibrate(source, prior_path, later_paths):
    model = Offer.read(source)
    paths = [Path(prior_path)] + [Path(p) for p in later_paths]
    signatures = [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
    if len(set(signatures)) != len(signatures):
        raise ValueError("The calibration and evaluation files are identical.")
    series = [Metered(model, p) for p in paths]
    prior = series[0]
    metadata = [json.loads(p.with_suffix(".json").read_text()) for p in paths]
    cohorts = {m.get("cohort_sha256") for m in metadata}
    if len(cohorts) != 1 or None in cohorts:
        raise ValueError(
            "Supply profile provenance with identical ordered cohort fingerprints."
        )
    if any(
        a["last_local_date"] >= b["first_local_date"]
        for a, b in zip(metadata, metadata[1:])
    ):
        raise ValueError("All input years must be chronological and disjoint.")
    prior.seed = metadata[0]["first_local_date"]
    hours = np.arange(len(prior.sun))
    ladder = np.linspace(1, 0, 17).tolist()
    scale, design = finite_design(
        model, [prior], hours, ladder, conditions=CONDITIONS[:1]
    )
    fixed_scale, fixed_design = finite_design(
        model, [prior], hours, ladder, conditions=CONDITIONS[:1], static=True
    )
    flex = model.flexible * scale[:, :, None]
    fixed = model.fixed * fixed_scale[:, :, None]
    exams = {}
    for year, meta in zip(series, metadata):
        result = evaluate(
            model, year, CONDITIONS[0], np.arange(len(year.sun)), flex, fixed
        )
        for value in result.values():
            counts_to_durations(value, year.interval_hours)
        exams[meta["first_local_date"]] = result
    return {
        "schema_version": 1,
        "source_receipt": Path(source).name,
        "source_sha256": hashlib.sha256(Path(source).read_bytes()).hexdigest(),
        "calibration_file_sha256": signatures[0],
        "evaluation_file_sha256": signatures[1:],
        "profile_provenance": [
            {
                key: value
                for key, value in period.items()
                if key not in ("selected_ids", "day_dates")
            }
            for period in metadata
        ],
        "conditions": ["nominal"],
        "design": design,
        "static_design": fixed_design,
        "revised_caps_kw": flex.tolist(),
        "revised_fixed_kw": fixed[0, 0].tolist(),
        "evaluation": exams,
    }


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("source", type=Path)
    p.add_argument("calibration_profile", type=Path)
    p.add_argument("evaluation_profiles", type=Path, nargs="+")
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    if a.output.resolve() in {
        f.resolve() for f in (a.source, a.calibration_profile, *a.evaluation_profiles)
    }:
        p.error("Output must differ from inputs.")
    out = calibrate(a.source, a.calibration_profile, a.evaluation_profiles)
    a.output.write_text(json.dumps(out, indent=1, allow_nan=False) + "\n")
    for name, plans in out["evaluation"].items():
        for plan in ("supplied", "fixed", "revised", "revised_fixed"):
            r = plans[plan]
            print(
                name,
                plan,
                r["export_worsened_hours"],
                "export-worsened hours,",
                round(r["curtailed_kwh"]),
                "curtailed kWh",
            )
