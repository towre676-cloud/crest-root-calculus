"""Reference spectral library.

Two sources:
  * load_usgs_splib07(paths): reads USGS Spectral Library v7 ASCII files (one reflectance column,
    wavelengths in a separate file, -1.23e34 = deleted channel) and resamples to a common grid.
  * builtin_proxy(): a synthetic SWIR/VNIR library built from the published diagnostic absorption
    positions of common alteration minerals (continuum x product of Gaussian absorptions).  It is a
    stand-in for testing the selection logic, NOT a substitute for measured spectra.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass

GRID = np.round(np.arange(0.40, 2.501, 0.01), 3)   # micrometres

# (centre um, depth, width um) ; positions from standard SWIR mineral-identification tables
FEATURES = {
    "kaolinite":       [(1.395,.18,.012),(1.414,.20,.012),(2.165,.30,.018),(2.207,.40,.020)],
    "dickite":         [(1.382,.20,.012),(1.414,.15,.012),(2.178,.38,.018),(2.206,.34,.020)],
    "alunite":         [(1.435,.20,.018),(1.762,.22,.020),(2.165,.38,.025),(2.32,.12,.030)],
    "muscovite":       [(1.408,.18,.015),(2.200,.42,.022),(2.350,.20,.025),(2.44,.15,.030)],
    "montmorillonite": [(1.412,.25,.020),(1.910,.40,.035),(2.208,.30,.025)],
    "pyrophyllite":    [(1.395,.22,.008),(2.166,.40,.010)],
    "chlorite":        [(0.92,.10,.10),(2.250,.25,.025),(2.330,.32,.030)],
    "epidote":         [(1.03,.08,.10),(1.55,.10,.030),(2.255,.28,.025),(2.340,.30,.030)],
    "calcite":         [(1.875,.08,.040),(1.995,.10,.040),(2.155,.10,.040),(2.340,.45,.035)],
    "dolomite":        [(1.86,.08,.040),(1.98,.10,.040),(2.140,.10,.040),(2.320,.45,.035)],
    "jarosite":        [(0.43,.30,.03),(0.91,.30,.10),(1.468,.25,.020),(1.850,.18,.030),(2.265,.35,.025)],
    "goethite":        [(0.48,.45,.06),(0.92,.30,.12)],
    "hematite":        [(0.53,.55,.06),(0.86,.25,.09)],
    "gypsum":          [(1.445,.30,.020),(1.490,.30,.020),(1.750,.20,.020),(1.945,.45,.035),(2.215,.15,.025)],
    "quartz":          [],
}
ALBEDO = {"hematite":.35,"goethite":.40,"jarosite":.55,"chlorite":.45,"epidote":.45,"quartz":.85}

@dataclass
class Library:
    names: list
    wl: np.ndarray
    R: np.ndarray       # (n_wl, n_min) reflectance

    def subset(self, names):
        idx = [self.names.index(n) for n in names]
        return Library(list(names), self.wl, self.R[:, idx])

def builtin_proxy(wl=GRID) -> Library:
    cols = []
    for name, feats in FEATURES.items():
        cont = ALBEDO.get(name, .75) * (1 - 0.08*np.exp(-(wl-0.4)/0.25))
        absorb = np.ones_like(wl)
        for c, d, w in feats:
            absorb *= 1 - d*np.exp(-0.5*((wl-c)/w)**2)
        cols.append(cont*absorb)
    return Library(list(FEATURES), wl, np.array(cols).T)

def load_usgs_splib07(wavelength_file, spectra: dict, wl=GRID) -> Library:
    """spectra: {mineral_name: path_to_splib07_ascii}. Both files have a one-line header."""
    if not spectra:
        raise ValueError("Supply at least one named reference spectrum.")
    w = np.loadtxt(wavelength_file, skiprows=1)
    raw = [np.loadtxt(path, skiprows=1) for path in spectra.values()]
    grid, matrix = _resample_common(w, raw, wl)
    return Library(list(spectra), grid, matrix)


def _resample_common(w, columns, wl):
    """Retain a grid point only when its interpolation brackets are valid in every column."""
    wl = np.asarray(wl, dtype=float)
    for axis in (w, wl):
        if axis.ndim != 1 or len(axis) == 0 or not np.isfinite(axis).all() or np.any(np.diff(axis) <= 0):
            raise ValueError("Wavelengths must be a finite increasing vector.")
    if len(w) < 2:
        raise ValueError("A USGS spectrum needs at least two wavelength channels.")
    hi = np.clip(np.searchsorted(w, wl), 0, len(w) - 1)
    lo = np.where(w[hi] == wl, hi, np.maximum(hi - 1, 0))
    good = (wl >= w[0]) & (wl <= w[-1])
    for raw in columns:
        if raw.shape != w.shape:
            raise ValueError("Spectrum length differs from the wavelength file.")
        valid = np.isfinite(raw) & (raw > -1)
        good &= valid[lo] & valid[hi]
    if not good.any():
        raise ValueError("No requested wavelength has valid data in every reference spectrum.")
    return wl[good], np.column_stack([np.interp(wl[good], w, raw) for raw in columns])


def measured_specimens():
    """Load the two disjoint sets of Beckman specimens on a shared valid grid.

    Columns with a deleted or out-of-range bracketing channel in any specimen
    are excluded from both matrices. No missing interval is filled across.
    """
    import json
    from pathlib import Path

    root = Path(__file__).resolve().parent.parent / "data" / "usgs_v7"
    manifest = json.loads((root / "manifest.json").read_text())
    wavelengths = np.loadtxt(root / manifest["wavelengths"], skiprows=1)
    names = list(manifest["specimens"])
    raw = [np.loadtxt(root / manifest["specimens"][name][role], skiprows=1)
           for role in ("reference", "challenge") for name in names]
    grid, samples = _resample_common(wavelengths, raw, GRID)
    # The exact tool uses the same published six-decimal table as these arrays.
    matrices = np.hsplit(samples.round(6), 2)
    return tuple(Library(names.copy(), grid.copy(), matrix) for matrix in matrices)



def load_measured_reference():
    """Fifteen USGS laboratory specimens, distinct from the challenge specimens."""
    return measured_specimens()[0]
