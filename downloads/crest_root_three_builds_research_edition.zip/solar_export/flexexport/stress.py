"""Replay the input receipt and qualify a revised offer on independent synthetic years."""

import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import numpy as np
from .audit import CONDITIONS, Offer, WeatherYear, finite_design, report
from .calendar import SUN_HOURS


def replay(receipt, model):
    """Compare displayed original unlimited counts to independent AC on the original 127 days.
    The compatibility metric deliberately uses the legacy solar hours and aggregate thresholds.
    """
    weather = WeatherYear(model, receipt.get("profile_seed", 0))
    days = receipt["days"]
    peak_load, peak_solar = sorted(days["peak_load"]), sorted(days["peak_surplus"])
    remainder = np.array(sorted(set(range(365)) - set(peak_load) - set(peak_solar)))
    rng = np.random.default_rng(receipt.get("profile_seed", 0) + 100)
    rng.shuffle(remainder)
    random_days = sorted(remainder[days["train"] :])
    sets = {
        "test_peak_load": peak_load,
        "test_peak_surplus": peak_solar,
        "test_random": random_days,
    }
    data = {}
    for name, group in sets.items():
        h = np.array(
            [
                24 * d + t
                for d in group
                for t in SUN_HOURS
                if weather.profiles["pv_unit"][d, t] > 0
            ]
        )
        base, _, _ = weather.run(CONDITIONS[0], h, mode="new_without_pv")
        variants = {}
        for label, offer in (
            ("unlimited_export", None),
            ("static_cap", model.fixed),
            ("flexible_offer", model.flexible),
        ):
            f, _, _ = weather.run(CONDITIONS[0], h, offer)
            hot = (
                f.loading[:, 1:].max(1)
                > np.maximum(base.loading[:, 1:].max(1), model.limits.thermal) + 0.5
            )
            hot |= (
                f.loading[:, 0]
                > np.maximum(base.loading[:, 0], model.limits.thermal) + 0.5
            )
            count = np.count_nonzero(
                (f.voltage.max(1) > model.limits.upper + 1e-9) | hot
            )
            variants[label] = {
                "reference_hours": receipt["evaluation"][name][label][
                    "violation_hours"
                ],
                "independent_hours": int(count),
                "independent_vmax": float(f.voltage.max()),
            }
        data[name] = variants
    return data


def evaluate(model, weather, cond, hours, revised, revised_fixed):
    base, _, _ = weather.run(cond, hours, mode="no_new_homes")
    zero, _, _ = weather.run(cond, hours, np.zeros_like(model.flexible))
    current = report(base, model.limits, hours, model.grid, clock=weather.clock)
    output = {"existing_homes_only": current}
    gen_off, _, _ = weather.run(cond, hours, mode="new_without_pv")
    output["candidate_homes_without_pv"] = report(
        gen_off, model.limits, hours, model.grid, absent=base, clock=weather.clock
    )
    output["zero_export"] = report(
        zero, model.limits, hours, model.grid, absent=base, clock=weather.clock
    )
    for name, caps in (
        ("unlimited", None),
        ("fixed", model.fixed),
        ("supplied", model.flexible),
        ("revised_fixed", revised_fixed),
        ("revised", revised),
    ):
        state, lost, pv = weather.run(cond, hours, caps)
        r = report(
            state, model.limits, hours, model.grid, zero, base, clock=weather.clock
        )
        loss_by_home = lost.sum(0)
        r.update(
            new_pv_available_kwh=float(pv.sum() * weather.interval_hours),
            curtailed_kwh=float(loss_by_home.sum() * weather.interval_hours),
            curtailed_pct=100 * float(lost.sum() / pv.sum()),
            worst_home_curtailed_pct=100 * float(np.max(loss_by_home / pv.sum(0))),
        )
        output[name] = r
    return output


def experiment(path, train_seeds, test_seeds):
    if not train_seeds or not test_seeds or set(train_seeds) & set(test_seeds):
        raise ValueError("Provide nonempty, disjoint training and evaluation seeds.")
    if any(len(seeds) != len(set(seeds)) for seeds in (train_seeds, test_seeds)):
        raise ValueError("Each seed group must contain distinct years.")
    src = Path(path)
    raw = src.read_bytes()
    receipt = json.loads(raw)
    original_seed = receipt.get("profile_seed", 0)
    if original_seed in test_seeds:
        raise ValueError(
            "Evaluation must also exclude the source receipt's profile year."
        )
    model = Offer.read(path)
    hours = np.arange(8760)
    ladder = [
        1.0,
        0.9375,
        0.875,
        0.8125,
        0.75,
        0.6875,
        0.625,
        0.5625,
        0.5,
        0.4375,
        0.375,
        0.3125,
        0.25,
        0.1875,
        0.125,
        0.0625,
        0.0,
    ]
    training = [WeatherYear(model, s) for s in train_seeds]
    scale, design = finite_design(model, training, hours, ladder)
    static_scale, static_design = finite_design(
        model, training, hours, ladder, static=True
    )
    revised = model.flexible * scale[:, :, None]
    revised_fixed = model.fixed * static_scale[:, :, None]
    evaluations = {}
    for seed in test_seeds:
        weather = WeatherYear(model, seed)
        evaluations[str(seed)] = {
            c.name: evaluate(model, weather, c, hours, revised, revised_fixed)
            for c in CONDITIONS
        }
    return {
        "schema_version": 1,
        "source_receipt": src.name,
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "n_new": model.flexible.shape[-1],
        "n_existing": model.n_existing,
        "training_seeds": train_seeds,
        "evaluation_seeds": test_seeds,
        "limits": asdict(model.limits),
        "candidate_conditions": [asdict(c) for c in CONDITIONS],
        "legacy_replay": replay(receipt, model),
        "design": design,
        "static_design": static_design,
        "revised_caps_kw": revised.tolist(),
        "revised_fixed_kw": revised_fixed[0, 0].tolist(),
        "evaluation": evaluations,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("receipt", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--train-seeds", type=int, nargs="+", default=[31, 47, 71])
    parser.add_argument("--test-seeds", type=int, nargs="+", default=[113, 127])
    args = parser.parse_args()
    if args.receipt.resolve() == args.output.resolve():
        parser.error("The output must differ from the input receipt.")
    res = experiment(args.receipt, args.train_seeds, args.test_seeds)
    args.output.write_text(json.dumps(res, indent=1, allow_nan=False) + "\n")
    print(
        "seed condition          supplied -> revised export-worsened hours | all revised violation hours | revised PV lost"
    )
    for seed, cases in res["evaluation"].items():
        for condition, result in cases.items():
            a, b = result["supplied"], result["revised"]
            print(
                f"{seed:>4} {condition:18} {a['export_worsened_hours']:4} -> {b['export_worsened_hours']:4}"
                f" | {b['absolute_violation_hours']:4} | {b['curtailed_pct']:6.2f}%"
            )
    print("Full asset/time witnesses and caps written to", args.output)


if __name__ == "__main__":
    main()
