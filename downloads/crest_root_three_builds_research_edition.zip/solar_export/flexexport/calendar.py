import numpy as np

SEASON = np.array(
    [0] * 59 + [1] * 92 + [2] * 92 + [3] * 91 + [0] * 31
)  # DJF, MAM, JJA, SON by day of year
SEASON_NAMES = ["winter", "spring", "summer", "autumn"]
SUN_HOURS = range(6, 20)
