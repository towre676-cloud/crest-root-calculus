TILLAMOOK CROSSING V3

Extract all files. On Windows double-click Open-Workbench.cmd.
On any desktop open v3/workbench.html in a browser; no server/network is needed.

The same reference assembly drives every study. Read v3/README.md and v3/integration-review.md.
This is research software, not a bridge design approval, controller or public-use authorization.

With Python 3.11+: python -B v3/verify_release.py
Exact core checks use the standard library. Optional GIS replay needs GDAL/GEOS;
JavaScript execution review needs Node and does not verify real browser/mobile rendering.

The manifest checks file identity only. Keep v2 and v3 together; v3 imports pinned v2 dependencies.
