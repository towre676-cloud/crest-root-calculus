from pathlib import Path
import numpy as np
import pytest
from scipy.special import xlogy

from geoassay.policy import Planner, SearchLimit
from geoassay.cli import prepare, read_scans, policy_report
from geoassay import builtin_proxy, Site


def decision_fixture():
    # Samples detect left/right pair, model A alone, model C alone respectively.
    clues = [[0, 0, 1, 1], [0, 1, 1, 1], [1, 1, 0, 1]]
    return Planner(np.full(4, .25), np.arange(4), [np.eye(2)[v] for v in clues])


def test_adaptive_strict_gain_and_deterministic_witness():
    p = decision_fixture()
    r = p.solve(2)
    np.testing.assert_allclose(r["fixed"]["entropy_nats"], np.log(2)/2, atol=1e-13)
    assert r["adaptive"]["sample"] == 0
    assert r["adaptive"]["entropy_nats"] == 0
    assert [b["next"]["sample"] for b in r["adaptive"]["branches"]] == [1, 2]
    assert sum(b["probability"] for b in r["adaptive"]["branches"]) == 1


def test_budget_prices_stopping_and_limit():
    p = decision_fixture()
    assert p.solve(0)["adaptive"]["sample"] is None
    assert p.solve(2, costs=[4, 3, 3])["fixed"]["samples"] == []
    assert p.solve(2, costs=[4, 1, 1])["fixed"]["samples"] == [1, 2]
    assert p.solve(2, excluded=[0])["adaptive"]["sample"] != 0
    with pytest.raises(SearchLimit):
        p.solve(2, max_leaves=5)
    with pytest.raises(ValueError):
        p.solve(-1)
    with pytest.raises(ValueError):
        p.solve(2, costs=[0, 1, 1])


def test_three_steps_matches_independent_scalar_tree():
    rng = np.random.default_rng(4)
    prior = rng.dirichlet(np.ones(4))
    labels = [0, 1, 1, 2]
    kernels = [rng.dirichlet([2,1,1], size=4) for _ in range(4)]
    p = Planner(prior, labels, kernels)
    def value(observed, left):
        joint = np.array([prior[h] * np.prod([kernels[i][h, a] for i, a in observed]) for h in range(4)])
        prob = joint.sum()
        primary = np.bincount(labels, weights=joint) / prob
        choices = [-prob * xlogy(primary, primary).sum()]
        if left:
            for i in set(range(4)) - {i for i, a in observed}:
                choices.append(sum(value(observed + [(i, a)], left-1) for a in range(3)))
        return min(choices)
    out = p.solve(3)
    np.testing.assert_allclose(out["adaptive"]["entropy_nats"], value([], 3), atol=1e-13)
    assert out["adaptive"]["entropy_nats"] <= out["fixed"]["entropy_nats"] + 1e-12


def test_expected_entropy_includes_seventh_outcome_and_bayes_updates_agree():
    lib = builtin_proxy()
    names = lib.names[:7]
    P = [.4, .2, .1, .08, .08, .07, .07]
    S = [{"id": "A", "zone": "intermediate", "hyps": [
        {"minerals": (m,), "p": w} for m,w in zip(names, P)], "scan_mass_retained": 1}]
    site = Site(S, names)
    p = Planner.from_site(site)
    A, probs = site.outcome_dist(0,{})
    after = []
    for a, pa in zip(A,probs):
        posterior = site.posterior({0:a})
        after.append(-pa*xlogy(posterior, posterior).sum())
    np.testing.assert_allclose(site.expected_entropy([0]), sum(after), atol=1e-13)
    assert abs(site.expected_entropy([0], max_outcomes=6)-sum(after)) > 1e-6
    with pytest.raises(ValueError, match="reference"):
        policy_report(site, 1, known={"A":["unknown"]}, accept_unlisted=True)
    outside = {"A": names[:2]}
    with pytest.raises(ValueError, match="outside"):
        policy_report(site, 1, known=outside)
    resumed = policy_report(site, 1, known=outside, accept_unlisted=True)
    assert resumed["observations_outside_scan_support"] == ["A"]
    np.testing.assert_allclose(list(resumed["site_posterior"].values()), site.posterior({0: tuple(names[:2])}))
    assert policy_report(site, 1, known={"A":[names[0]]})["fixed"]["samples"] == []


def test_scan_coverage_and_zero_remaining_budget():
    wl, cols = read_scans(Path(__file__).resolve().parents[1] / "example_scans.csv")
    with pytest.raises(ValueError, match="span"):
        prepare(wl[1:], {k: v[1:] for k,v in cols.items()}, .045, builtin_proxy())
    p = decision_fixture()
    np.testing.assert_allclose(p.solve(0)["initial_entropy_nats"], np.log(4))


def test_report_branches_and_posteriors_replay_at_every_depth():
    lib = builtin_proxy()
    names = lib.names[:4]
    S = [{"id": str(i), "zone": z, "hyps": [{"minerals": (m,), "p": .25} for m in names],
          "scan_mass_retained": 1} for i,z in enumerate(("distal", "intermediate", "proximal"))]
    site = Site(S, names)
    r = policy_report(site, 2)
    def check(node, observed):
        np.testing.assert_allclose(node["primary_posterior"], site.posterior(observed), atol=1e-13)
        if node["sample"] is None:
            return
        i = int(node["sample"])
        branches = node["branches"]
        assert abs(sum(b["probability"] for b in branches)-1) < 1e-12
        np.testing.assert_allclose(node["entropy_nats"],
                                   sum(b["probability"]*b["next"]["entropy_nats"] for b in branches))
        for b in branches:
            check(b["next"], {**observed, i: b["outcome"]})
    check(r["adaptive"], {})


def test_brightness_offset_is_unconstrained():
    from geoassay.unmix import fit_subset
    lib = builtin_proxy()
    for offset in [-1.2,.7]:
        y=lib.R[:, [0,1]] @ np.array([.6,.4]) + offset
        x,rss=fit_subset(lib, (0,1), y)
        np.testing.assert_allclose(x,[.6,.4], atol=1e-10)
        assert rss < 1e-18
