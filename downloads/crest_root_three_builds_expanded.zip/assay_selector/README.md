# GeoAssay — choose a sample and follow the result

You have eight scanned rocks and two lab credits. **Which rock should go first? Would its result change where you spend the second credit?** Double-click [policy.html](policy.html), select a possible mineral mixture, and choose **Use this result**. You can go back and try a different branch. The percentages beside a mixture predict a lab result under the site model. The bars estimate the primary geological system after the results you selected.

To try a different question, open [mixtures.html](mixtures.html). It shows how adding measured wavelength bands can rule out two-mineral mixtures. That experiment uses USGS reference specimens. The eight-scan policy example uses synthetic proxy spectra so it remains comparable with the first release.

## The eight-rock example

Both methods get two credits, and each assay costs one credit.

| Method | First decision | Expected uncertainty remaining |
| --- | --- | ---: |
| Original six-outcome scoring rule | Send S04 and S08 together | 0.630793 nats when evaluated with all retained outcomes |
| Best fixed batch | Send S07 and S08 together | 0.628461 nats |
| Best sequential policy | Send S07, read the lab result, then decide | 0.627848 nats |

These are model predictions, starting from 0.689038 nats. Lower values mean the system labels are easier to distinguish. S07 has twenty possible lab results in this model. Depending on which appears, the next assay is **S08** (85.64% of the modeled probability), **S04** (13.48%), or **S06** (0.88%). The gain from waiting on this example is small. A site where every sample must ship together can use the fixed batch. The downloadable [policy tree](example_policy.json) contains every positive-probability branch of the selected policy, the corresponding primary-system probabilities and the search counts.

## Run your own scans

Open a terminal in `assay_selector`. Install NumPy and SciPy with `python -m pip install numpy scipy`. The commands work on a downloaded, extracted copy. The following commands create new files in the current directory.

```bash
python -m geoassay.cli policy example_scans.csv --budget 2 --sigma .045 --html my-policy.html > my-policy.json
python -m geoassay.cli policy example_scans.csv --sigma .045 --budget 1 --known S07=muscovite+pyrophyllite > next-assay.json
python -m geoassay.cli policy example_scans.csv --sigma .045 --budget 3 --cost S07=2 > priced-policy.json
python -m geoassay.cli plan example_scans.csv --budget 3 --sigma .045 > fixed-batch.json
```

For a field scan, use the bundled measured USGS library with `--reference measured`, or supply `--usgs-wl wavelength.txt --usgs kaolinite=specimen1.txt dickite=specimen2.txt` for a custom reference. The default is the synthetic proxy. A CSV starts with `wavelength_um`, then one column per sample, such as `S01@distal`, `S02@intermediate`, and `S03@proximal`. Use increasing wavelengths in micrometres and finite reflectance values covering the reference grid. The noise parameter `--sigma` uses those reflectance units. Measured spectra supply reference shapes. The zone priors, site labels and lab-outcome model still require local field validation.

Credits are positive integers. Unpriced samples cost one. Set a whole-number scale appropriate to the lab or project budget. With `--known`, `--budget` is the **remaining** budget. Existing results are never charged again. If a lab returns an assemblage outside a scan's shortlist, try `--keep 0` to retain all fitted assemblages. A confirmed lab result can explicitly replace that sample's scan with `--known S07=... --accept-unlisted`; the report names every such exception. Unknown mineral names require a revised reference and site model.

## Exactly what is optimized

A hidden site hypothesis identifies the primary system, a possible overprinting system and a blend weight. Each hypothesis assigns a likelihood to the candidate assemblages in each sample's zone. Site inference combines these likelihoods with the spectra. The scan fits use nonnegative mineral amplitudes and an unrestricted brightness offset. Normalized BIC-style scores approximate scan evidence. The fitting routine enumerates mineral subsets of size at most three and discards fits with negligible component coefficients.

After conditioning on all scans, let *h* index the remaining site hypotheses and *p(h)* their probabilities. For sample *i*, the outcome kernel *Kᵢ(h,a)* gives the chance the lab reports assemblage *a* under hypothesis *h*. The outcome probability is *q(a) = Σₕ p(h)Kᵢ(h,a)*. Observing *a* updates each hypothesis weight to *p(h)Kᵢ(h,a)/q(a)*. The objective is the Shannon entropy of the primary system after summing over its overprinting variants. A nat is one unit of information when logarithms use base *e*.

The fixed search evaluates every affordable subset once. The sequential search compares stopping with every affordable next assay. For each assay, it averages the best remaining decisions over **every positive-probability lab result**. One assay is allowed per sample. Costs are fixed and results are assumed error-free. The full search evaluates this recurrence in floating point and breaks ties within 10⁻¹³ nats. The work counter includes the fixed and adaptive searches. If `--max-leaves` would be exceeded, the command stops and identifies the budget or size change required; it does not label a partial search optimal.

The original code capped the outcomes at six **at each branch** and renormalized them, which could change the winning batch. The updated default uses all outcomes on the retained per-scan support. By default there are up to twenty per scan, and the reported scan mass retained is measured before conditioning on site evidence. Selecting `--keep 0` removes this top-count cutoff, but keeps the fitted mixture model and its physical assumptions. In large problems the separate `plan` command uses greedy batch selection after 2,000 possible fixed batches and reports which search it used.

## What happened on 100 new synthetic sites?

The seed was 841092. Each site had eight scans, a true 25% overprint, scan noise σ = 0.05, twenty retained outcomes per scan and two assay credits. Every method saw the same sites, scans and modeled priors. The primary-system labels below come from the generator. The random baseline selects two samples without replacement.

| Method | Correct primary labels / 100 | Mean probability assigned to true primary | Mean assays used |
| --- | ---: | ---: | ---: |
| Best fixed under the retained model | 91 | 0.8265 | 2.00 |
| Sequential, stop after an unsupported lab result | 91 | 0.8252 | 1.85 |
| Sequential, replace unsupported scan with confirmed result and replan | 90 | 0.8219 | 2.00 |
| Original six-outcome rule | 91 | 0.8212 | 2.00 |
| Most ambiguous scans | 89 | 0.8009 | 2.00 |
| Random samples | 91 | 0.8160 | 2.00 |

The predicted sequential advantage averaged **0.000104 nats**. On 15 sites, the first actual lab mixture fell outside the predicted shortlist. On these sites the stop policy counted the first assay and issued no second recommendation. Its paired mean true-label probability difference from the fixed batch was −0.00133 with standard error 0.00327. This benchmark gives no accuracy advantage for waiting. A compact four-system counterexample in the [validation receipt](validation_policy.json) gives an independent positive control. Four equally likely target labels A, B, C, D can be queried by “AB or CD?”, “A or the rest?”, and “C or the rest?”. After the first split, the second test can isolate A or C as appropriate. Sequential testing identifies all four labels. Every fixed pair leaves one indistinguishable pair, giving expected residual entropy (ln 2)/2.

```bash
python -m pip install pytest
python -m pytest -q
python validate_policy.py > my-validation.json
python measured_benchmark.py
```

`validate_policy.py` compares the same labeled cases across all six strategies. The original `validation_receipt*.json` and `example_plan.json` are historical outputs of the earlier six-outcome rule. The original confidence-count diagnostic used an entropy proxy; a fresh run of `validate.py` counts the actual event “wrong winning label with posterior above 0.9.” Preserve the input release to reproduce historical code verbatim.

## Four physical powder mixtures put the affine model to a harder test

A real spectrometer can measure a mixture differently from a weighted average of two pure spectra. This benchmark uses **four actual lab preparations**, with proportions independently documented by USGS. They are every GDS200–299 absolute-reflectance Beckman entry in Chapter S of the v7 release. The illustrated 60:40 kaolinite/dickite curve elsewhere in this package was constructed arithmetically. Here the instrument observed the mixed grains. USGS also distributes calculated areal mixtures under AMX identifiers; none enters this four-sample comparison.

For every sample, `physical_benchmark.py` tests all 105 pairs of the same fifteen pure references. A linear program minimizes the largest absolute reflectance error across 188–204 valid bands. The independent rational interval checker answers whether each pair can fit *all* bands within ±0.005 on the six-decimal input table.

| USGS specimen | Documented powder fractions by weight | Rank of actual pair / 105 | Smallest worst-band error for actual pair |
| --- | --- | ---: | ---: |
| GDS212 | 80% calcite, 20% montmorillonite | 5 | 0.111367 |
| GDS213 | 80% calcite, 20% kaolinite | 1 | 0.036237 |
| GDS222 | 50% alunite, 50% pyrophyllite | 1 | 0.103612 |
| GDS240 | 2% goethite, 98% quartz | 6 | 0.220965 |

**All 105 pairs fail the ±0.005 tolerance on each physical mixture.** The tight affine model fails even on the two specimens where it ranks the component names first. For GDS222 the best affine coefficient for alunite is 0.230, while the laboratory weighed 0.500. Absorption, scattering, grain size and differences between reference specimens can affect optical behavior. These measurements group those effects together. An empty feasible set is evidence against this particular optical model and tolerance; the underlying minerals remain present. [Source data, weight labels, study cohort and checksums](data/physical_mixtures/manifest.json) · [Complete experimental results](data/physical_benchmark.json)

![Measured reflectance for a 50:50 alunite and pyrophyllite powder compared with its best affine optical fit. The residual leaves the ±0.005 tolerance.](data/gds222-physical.svg)

**Pure specimens answer a different question.** On the same fifteen separate challenge specimens used in the earlier benchmark, raw spectral angle selects the correct mineral for 4/15 with proxy references and 5/15 with measured references. Dividing every spectrum by its upper continuum and comparing the resulting absorption depths changes these to **9/15** and **14/15**. The measured-reference version places all fifteen within its top three. Its single top-choice error is muscovite, ranked third behind a leading chlorite match. We used one upper hull over the entire common 204-band grid for every spectrum, with no tuned windows. These are laboratory specimen retrieval results, not tests on mine sites or assay spending. [Continuum-removal method](https://doi.org/10.1029/JB089iB07p06329)

```bash
python physical_benchmark.py
python physical_benchmark.py --identify data/reference_challenges.csv --sample kaolinite
```

Replace that CSV and column name to rank your own positive-reflectance scan against the measured pure references. Candidate cosine scores measure optical similarity. A rock containing multiple minerals can have a close match to the wrong pure mineral.
