"""All two-reference areal mixtures consistent with a reflectance table.

Each retained band supplies one closed rational interval for the proportion of
the first reference. Their intersection is the complete feasible set in this
model. An empty intersection has a witness of at most two bounds. CLI inputs
are measured reflectances (0-1), with wavelength in micrometres.
"""
import argparse
import csv
import itertools
import json
from fractions import Fraction
from pathlib import Path

from .library import load_measured_reference


def interval_for_pair(readings, tolerance):
    """Each row is (wavelength label, first reference, second reference, reading)."""
    eps = Fraction(tolerance)
    if eps < 0:
        raise ValueError("Tolerance must be nonnegative.")
    lower, upper = Fraction(0), Fraction(1)
    low_at, high_at = "fraction >= 0", "fraction <= 1"
    for label, first, second, observed in readings:
        first, second, observed = map(Fraction, (first, second, observed))
        slope = first - second
        if not slope:
            if abs(observed - second) > eps:
                return {"possible": False, "flat_band": label}
            continue
        left, right = sorted(((observed - eps - second) / slope,
                              (observed + eps - second) / slope))
        if left > lower:
            lower, low_at = left, label
        if right < upper:
            upper, high_at = right, label
        if lower > upper:
            break
    return {"possible": lower <= upper, "lower": str(lower), "upper": str(upper),
            "lower_from": low_at, "upper_from": high_at}


def wavelength_indices(lib, observations):
    label_to_index = {Fraction(f"{x:.3f}"): i for i, x in enumerate(lib.wl)}
    selected = []
    for band, reading in observations.items():
        if band not in label_to_index:
            raise ValueError(f"Wavelength {float(band):g} is absent from the shared USGS grid.")
        selected.append((label_to_index[band], str(float(band)), Fraction(reading)))
    if not selected:
        raise ValueError("Supply at least one measured wavelength.")
    return selected


def all_pairs(lib, observations, tolerance):
    selected = wavelength_indices(lib, observations)
    table = [[Fraction(f"{value:.6f}") for value in lib.R[i]] for i, _, _ in selected]
    results = []
    for a, b in itertools.combinations(range(len(lib.names)), 2):
        rows = ((label, table[k][a], table[k][b], observed)
                for k, (_, label, observed) in enumerate(selected))
        fit = interval_for_pair(rows, tolerance)
        results.append({"first": lib.names[a], "second": lib.names[b], **fit})
    return results


def read_observations(path, column, bands=None):
    with Path(path).open(newline='', encoding='utf-8-sig') as handle:
        data = csv.DictReader(handle)
        if not data.fieldnames or data.fieldnames[0] != "wavelength_um" or column not in data.fieldnames[1:]:
            raise ValueError("Use a CSV headed wavelength_um and a named sample column.")
        values = {}
        for row in data:
            band = Fraction(row["wavelength_um"])
            if bands is not None and band not in bands:
                continue
            if band in values:
                raise ValueError("Duplicate scan wavelength: " + str(float(band)))
            values[band] = Fraction(row[column])
    if bands is not None and set(values) != bands:
        raise ValueError("Some requested wavelengths are missing from the scan.")
    return values


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("csv", type=Path)
    ap.add_argument("--column", required=True)
    ap.add_argument("--error", type=Fraction, required=True, help="Absolute per-band error, e.g. 0.02")
    ap.add_argument("--bands", help="Optional comma-separated wavelengths in micrometres")
    ap.add_argument("--all", action="store_true", help="Include short exclusion witnesses for rejected pairs")
    args = ap.parse_args()
    try:
        bands = {Fraction(t) for t in args.bands.split(",")} if args.bands else None
        obs = read_observations(args.csv, args.column, bands)
        pairs = all_pairs(load_measured_reference(), obs, args.error)
    except (OSError, ValueError, ZeroDivisionError) as exc:
        ap.error(str(exc))
    fits = [p for p in pairs if p["possible"]]
    print(json.dumps({"model": "two reference spectra; linear areal mixture; no additive offset",
                      "band_count": len(obs), "error": str(args.error), "pairs_checked": len(pairs),
                      "pairs_possible": len(fits), "results": pairs if args.all else fits}, indent=2))


if __name__ == "__main__":
    main()
