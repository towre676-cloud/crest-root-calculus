"""Builds an example site (8 scans), writes example_scans.csv, runs the planner, saves example_plan.json."""
import csv, json, numpy as np
from geoassay import builtin_proxy
from geoassay.cli import plan
lib = builtin_proxy(); rng = np.random.default_rng(11); M = lib.names
truth = [("distal",{"montmorillonite":.6,"chlorite":.4}),("distal",{"kaolinite":.5,"quartz":.5}),
         ("intermediate",{"kaolinite":.6,"montmorillonite":.4}),("intermediate",{"dickite":.5,"quartz":.5}),
         ("intermediate",{"muscovite":.5,"kaolinite":.5}),("proximal",{"alunite":.5,"quartz":.5}),
         ("proximal",{"pyrophyllite":.4,"muscovite":.6}),("proximal",{"jarosite":.4,"kaolinite":.6})]
cols = {}
for k,(z,mix) in enumerate(truth):
    y = sum(f*lib.R[:, M.index(m)] for m,f in mix.items()) + rng.normal(0, .045, len(lib.wl))
    cols[f"S{k+1:02d}@{z}"] = y
with open("example_scans.csv","w",newline="") as f:
    w = csv.writer(f); w.writerow(["wavelength_um", *cols]); [w.writerow([lib.wl[i], *[round(float(c[i]),5) for c in cols.values()]]) for i in range(len(lib.wl))]
out = plan(lib.wl, cols, 3, 0.045, lib); out["truth_for_checking"] = {f"S{k+1:02d}": mix for k,(z,mix) in enumerate(truth)}
json.dump(out, open("example_plan.json","w"), indent=1)
print("site posterior:", {k: round(v,3) for k,v in out["site_posterior"].items()})
print("send to lab:", out["send_to_lab"], " entropy", round(out["entropy_now_nats"],3), "->", round(out["expected_entropy_after_nats"],3))
for s in out["samples"]:
    print(s["id"], s["zone"], " | ".join(f"{'+'.join(f['minerals'])} ({f['p']:.2f})" for f in s["fits"][:3]))
