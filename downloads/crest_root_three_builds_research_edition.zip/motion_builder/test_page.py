"""Check the actual offline UI. Use --chromium to select a local Chromium executable."""
import argparse
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--chromium")
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=args.chromium, args=["--no-sandbox"])
        page = browser.new_page(viewport={"width": 1280, "height": 1000}, offline=True)
        errors = []
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.goto((HERE / "index.html").as_uri())
        receipt = page.evaluate((HERE / "browser_scenario.js").read_text(encoding="utf-8"))
        widths = [1280, 390, 320]
        for width in widths:
            page.set_viewport_size({"width": width, "height": 900})
            assert page.evaluate("document.documentElement.scrollWidth <= innerWidth"), width
        for button, suffix in [("saveSvg", ".svg"), ("saveJson", ".json")]:
            with page.expect_download() as event:
                page.locator("#" + button).click()
            assert event.value.suggested_filename.endswith(suffix)
        assert not errors, errors
        receipt["viewportWidths"] = widths
        browser.close()
    if args.receipt:
        args.receipt.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
