"""Replay a measured portfolio on the synthetic feeder, using already-designed cap tables.

Input NPZ schema and the separation of measured vs simulated quantities are in README.md.
With half-hour readings, violation-interval counts can be converted to duration with dt=0.5.
"""

import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from .audit import CONDITIONS, Offer, WeatherYear
from .stress import evaluate


class Metered(WeatherYear):
    def __init__(self, model, path):
        self.model = model
        self.n_existing = model.n_existing
        self.rated = np.array([h["pv_kw"] for h in model.grid.homes])
        with np.load(path, allow_pickle=False) as data:
            self.demand = np.asarray(data["load_kw"], float)
            self.sun = np.asarray(data["pv_unit"], float)
            self.season = np.array(data["season"])
            self.hour = np.array(data["hour"])
            self.interval_hours = float(np.asarray(data["interval_hours"]).item())
        if (
            self.demand.ndim != 2
            or self.demand.shape != self.sun.shape
            or self.demand.shape[1] != len(model.grid.homes)
            or not self.demand.shape[0]
        ):
            raise ValueError(
                "Expected matching nonempty (intervals, all feeder homes) arrays."
            )
        if (
            not np.isfinite(self.demand).all()
            or not np.isfinite(self.sun).all()
            or self.demand.min() < 0
            or self.sun.min() < 0
        ):
            raise ValueError(
                "All gross load and solar availability values must be finite and nonnegative."
            )
        n = len(self.sun)
        if (
            self.season.shape != (n,)
            or self.hour.shape != (n,)
            or self.season.dtype.kind not in "iu"
            or self.hour.dtype.kind not in "iu"
            or not np.isin(self.season, range(4)).all()
            or not np.isin(self.hour, range(24)).all()
        ):
            raise ValueError(
                "Expected integer season and hour labels for every interval."
            )
        if self.interval_hours not in (1.0, 0.5, 0.25) or not np.array_equal(
            self.hour, np.floor(np.arange(n) * self.interval_hours).astype(int) % 24
        ):
            raise ValueError(
                "Expected regular hour, half-hour or quarter-hour intervals starting at midnight."
            )
        # Orientation is already embedded in metered kW/kWp.
        meta_path = Path(path).with_suffix(".json")
        metadata = json.loads(meta_path.read_text()) if meta_path.exists() else {}
        self.dates = metadata.get("day_dates", [])
        if self.dates and len(self.dates) != int(
            np.ceil(len(self.sun) * self.interval_hours / 24)
        ):
            raise ValueError(
                "The date metadata disagree with the number of observed days."
            )

    def clock(self, t):
        when = super().clock(t)
        if self.dates:
            when["date"] = self.dates[when["day_index"]]
        return when


def counts_to_durations(item, dt):
    # The shared synthetic report counts observations; input intervals require explicit units.
    for key in list(item):
        if key.endswith("_hours") or key == "hours":
            count = item.pop(key)
            new_key = key[:-5] + "intervals" if key.endswith("_hours") else "intervals"
            item[new_key] = count
            item[key] = count * dt


def run(source, design, profile, use_stress=False):
    archived = json.loads(Path(design).read_text())
    if (
        archived["source_sha256"]
        != hashlib.sha256(Path(source).read_bytes()).hexdigest()
    ):
        raise ValueError("The stress design and source receipt do not match.")
    model = Offer.read(source)
    year = Metered(model, profile)
    yearscale = np.asarray(archived["design"]["scales"])
    flex = np.asarray(archived["revised_caps_kw"])
    fixed = np.broadcast_to(np.asarray(archived["revised_fixed_kw"]), model.fixed.shape)
    if (
        flex.shape != model.flexible.shape
        or yearscale.shape != (4, 24)
        or not np.allclose(
            flex, model.flexible * yearscale[:, :, None], rtol=0, atol=1e-12
        )
    ):
        raise ValueError("Invalid revised flexible cap table.")
    static_scale = np.asarray(archived["static_design"]["scales"])
    if static_scale.shape != (4, 24) or not np.allclose(
        fixed, model.fixed * static_scale[:, :, None], rtol=0, atol=1e-12
    ):
        raise ValueError("Invalid revised static cap table.")
    cases = CONDITIONS if use_stress else CONDITIONS[:1]
    scen = {}
    ids = np.arange(len(year.sun))
    for case in cases:
        result = evaluate(model, year, case, ids, flex, fixed)
        for value in result.values():
            counts_to_durations(value, year.interval_hours)
        scen[case.name] = result
    return {
        "schema_version": 1,
        "source_sha256": archived["source_sha256"],
        "profile_array_sha256": hashlib.sha256(Path(profile).read_bytes()).hexdigest(),
        "design_sha256": hashlib.sha256(Path(design).read_bytes()).hexdigest(),
        "n_existing": model.n_existing,
        "n_new": model.flexible.shape[-1],
        "interval_hours": year.interval_hours,
        "intervals": len(year.sun),
        "available_pv_per_kwp_values_above_one_clipped": int((year.sun > 1).sum()),
        "evaluation": scen,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("design", type=Path)
    parser.add_argument("profile", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--stress",
        action="store_true",
        help="also perturb the metered traces with the synthetic stress multipliers",
    )
    args = parser.parse_args()
    if args.output.resolve() in {
        p.resolve() for p in (args.source, args.design, args.profile)
    }:
        parser.error("Output must differ from the input files.")
    result = run(args.source, args.design, args.profile, args.stress)
    args.output.write_text(json.dumps(result, indent=1, allow_nan=False) + "\n")
    for name, sc in result["evaluation"].items():
        for label, value in sc.items():
            print(
                name,
                label,
                "absolute violation hours",
                value["absolute_violation_hours"],
                "export-worsened hours",
                value.get("export_worsened_hours", "–"),
                "curtailed kWh",
                round(value.get("curtailed_kwh", 0)),
            )
